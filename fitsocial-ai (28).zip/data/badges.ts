
import { BadgeNFT } from '../types';

const rarityColors = {
    Common: '6B7280',     // gray-500
    Uncommon: '10B981',   // green-500
    Rare: '3B82F6',       // blue-500
    Epic: '8B5CF6',       // violet-500
    Legendary: 'F59E0B',  // amber-500
};

const createBadge = (badge: Omit<BadgeNFT, 'imageUrl'> & { icon: string }): BadgeNFT => {
    const color = rarityColors[badge.rarity];
    const encodedIcon = encodeURIComponent(badge.icon);
    return {
        ...badge,
        imageUrl: `https://placehold.co/500x500/${color}/FFFFFF?text=${encodedIcon}&font=inter`,
    };
};

export const badgeData: BadgeNFT[] = [
    // --- Milestones Category ---
    createBadge({ id: 'm001', title: 'First Steps', description: 'Log your first 1,000 steps in a single day.', icon: '👟', rarity: 'Common', category: 'Milestones', floorPrice: 10, condition: { type: 'stepsInDay', value: 1000 } }),
    createBadge({ id: 'm002', title: 'Daily Walker', description: 'Log 10,000 steps in a single day.', icon: '🚶‍♂️', rarity: 'Common', category: 'Milestones', floorPrice: 25, condition: { type: 'stepsInDay', value: 10000 } }),
    createBadge({ id: 'm003', title: 'Power Walker', description: 'Log 20,000 steps in a single day.', icon: '🏃‍♂️', rarity: 'Uncommon', category: 'Milestones', floorPrice: 75, condition: { type: 'stepsInDay', value: 20000 } }),
    createBadge({ id: 'm004', title: 'Step Mogul', description: 'Accumulate a total of 100,000 steps.', icon: '⛰️', rarity: 'Uncommon', category: 'Milestones', floorPrice: 100, condition: { type: 'totalSteps', value: 100000 } }),
    createBadge({ id: 'm005', title: 'Millionaire Stepper', description: 'Accumulate a total of 1,000,000 steps.', icon: '👑', rarity: 'Rare', category: 'Milestones', floorPrice: 500, condition: { type: 'totalSteps', value: 1000000 } }),
    createBadge({ id: 'm006', title: 'First 5k', description: 'Log a distance of 5km or more in a single activity.', icon: '🏅', rarity: 'Common', category: 'Milestones', floorPrice: 30, condition: { type: 'distanceInDay', value: 5 } }),
    createBadge({ id: 'm007', title: '10k Finisher', description: 'Log a distance of 10km or more in a single activity.', icon: '🎖️', rarity: 'Uncommon', category: 'Milestones', floorPrice: 100, condition: { type: 'distanceInDay', value: 10 } }),
    createBadge({ id: 'm008', title: 'Half Marathoner', description: 'Log a distance of 21.1km or more in a single activity.', icon: '🏆', rarity: 'Rare', category: 'Milestones', floorPrice: 300, condition: { type: 'distanceInDay', value: 21.1 } }),
    createBadge({ id: 'm009', title: 'Marathon Runner', description: 'Log a distance of 42.2km or more in a single activity.', icon: '🥇', rarity: 'Epic', category: 'Milestones', floorPrice: 1000, condition: { type: 'distanceInDay', value: 42.2 } }),
    createBadge({ id: 'm010', title: 'Globe Trotter', description: 'Accumulate a total distance of 1,000km.', icon: '🌍', rarity: 'Epic', category: 'Milestones', floorPrice: 1500, condition: { type: 'totalDistance', value: 1000 } }),
    createBadge({ id: 'm011', title: 'First Workout', description: 'Log your very first proof of workout.', icon: '💪', rarity: 'Common', category: 'Milestones', floorPrice: 10, condition: { type: 'powCount', value: 1 } }),
    createBadge({ id: 'm012', title: 'Workout Warrior', description: 'Log 10 proofs of workout.', icon: '⚔️', rarity: 'Common', category: 'Milestones', floorPrice: 40, condition: { type: 'powCount', value: 10 } }),
    createBadge({ id: 'm013', title: 'Gym Rat', description: 'Log 50 proofs of workout.', icon: '🏋️', rarity: 'Uncommon', category: 'Milestones', floorPrice: 150, condition: { type: 'powCount', value: 50 } }),
    createBadge({ id: 'm014', title: 'Fitness Fiend', description: 'Log 100 proofs of workout.', icon: '👹', rarity: 'Rare', category: 'Milestones', floorPrice: 400, condition: { type: 'powCount', value: 100 } }),
    createBadge({ id: 'm015', title: 'Centurion', description: 'Log 250 proofs of workout.', icon: '💯', rarity: 'Epic', category: 'Milestones', floorPrice: 1200, condition: { type: 'powCount', value: 250 } }),
    
    // --- Consistency Category ---
    createBadge({ id: 'c001', title: '3-Day Streak', description: 'Use the app and log activity for 3 consecutive days.', icon: '🔥', rarity: 'Common', category: 'Consistency', floorPrice: 20, condition: { type: 'activityStreak', value: 3 } }),
    createBadge({ id: 'c002', title: 'Weekly Warrior', description: 'Log activity for 7 consecutive days.', icon: '🗓️', rarity: 'Uncommon', category: 'Consistency', floorPrice: 80, condition: { type: 'activityStreak', value: 7 } }),
    createBadge({ id: 'c003', title: 'Fortnight Fighter', description: 'Log activity for 14 consecutive days.', icon: '✨', rarity: 'Uncommon', category: 'Consistency', floorPrice: 200, condition: { type: 'activityStreak', value: 14 } }),
    createBadge({ id: 'c004', title: 'Monthly Maintainer', description: 'Log activity for 30 consecutive days.', icon: ' M ', rarity: 'Rare', category: 'Consistency', floorPrice: 600, condition: { type: 'activityStreak', value: 30 } }),
    createBadge({ id: 'c005', title: 'Habit Hacker', description: 'Log activity for 100 consecutive days.', icon: ' H ', rarity: 'Epic', category: 'Consistency', floorPrice: 2000, condition: { type: 'activityStreak', value: 100 } }),
    createBadge({ id: 'c006', title: 'Unstoppable Force', description: 'Log activity for 365 consecutive days.', icon: '♾️', rarity: 'Legendary', category: 'Consistency', floorPrice: 10000, condition: { type: 'activityStreak', value: 365 } }),
    createBadge({ id: 'c007', title: 'Hydration Hero', description: 'Log 10 glasses of water in a single day.', icon: '💧', rarity: 'Common', category: 'Consistency', floorPrice: 15, condition: { type: 'waterInDay', value: 10 } }),
    createBadge({ id: 'c008', title: 'Perfect Sleeper', description: 'Log 8 hours of sleep in a single day.', icon: '😴', rarity: 'Common', category: 'Consistency', floorPrice: 15, condition: { type: 'sleepInDay', value: 8 } }),
    createBadge({ id: 'c009', title: 'Meal Logger', description: 'Log a meal for the first time.', icon: '🍎', rarity: 'Common', category: 'Consistency', floorPrice: 10, condition: { type: 'mealLogs', value: 1 } }),
    createBadge({ id: 'c010', title: 'Consistent Eater', description: 'Log meals for 7 days in a row.', icon: '🥗', rarity: 'Uncommon', category: 'Consistency', floorPrice: 90, condition: { type: 'mealLogStreak', value: 7 } }),

    // --- Social Category ---
    createBadge({ id: 's001', title: 'Social Butterfly', description: 'Get your first 10 followers.', icon: '🦋', rarity: 'Common', category: 'Social', floorPrice: 20, condition: { type: 'followerCount', value: 10 } }),
    createBadge({ id: 's002', title: 'Community Pillar', description: 'Reach 100 followers.', icon: '🏛️', rarity: 'Uncommon', category: 'Social', floorPrice: 120, condition: { type: 'followerCount', value: 100 } }),
    createBadge({ id: 's003', title: 'Influencer', description: 'Reach 1,000 followers.', icon: '🌐', rarity: 'Rare', category: 'Social', floorPrice: 500, condition: { type: 'followerCount', value: 1000 } }),
    createBadge({ id: 's004', title: 'FitSocial Famous', description: 'Reach 10,000 followers.', icon: '🌟', rarity: 'Epic', category: 'Social', floorPrice: 2500, condition: { type: 'followerCount', value: 10000 } }),
    createBadge({ id: 's005', title: 'Tastemaker', description: 'Follow 50 other users.', icon: '🤝', rarity: 'Common', category: 'Social', floorPrice: 20, condition: { type: 'followingCount', value: 50 } }),
    createBadge({ id: 's006', title: 'Heartfelt', description: 'Receive 100 likes across all your content.', icon: '❤️', rarity: 'Common', category: 'Social', floorPrice: 30, condition: { type: 'totalLikesReceived', value: 100 } }),
    createBadge({ id: 's007', title: 'Much Loved', description: 'Receive 1,000 likes across all your content.', icon: '💖', rarity: 'Uncommon', category: 'Social', floorPrice: 150, condition: { type: 'totalLikesReceived', value: 1000 } }),
    createBadge({ id: 's008', title: 'Viral Sensation', description: 'Receive 10,000 likes across all your content.', icon: '📈', rarity: 'Rare', category: 'Social', floorPrice: 600, condition: { type: 'totalLikesReceived', value: 10000 } }),
    createBadge({ id: 's009', title: 'Chatterbox', description: 'Leave 50 comments on other users\' content.', icon: '💬', rarity: 'Common', category: 'Social', floorPrice: 25, condition: { type: 'commentsMade', value: 50 } }),
    createBadge({ id: 's010', title: 'Challenge Accepted', description: 'Accept and complete a stake challenge.', icon: '🏆', rarity: 'Uncommon', category: 'Social', floorPrice: 100, condition: { type: 'challengeCompleted', value: 1 } }),

    // --- Content Category ---
    createBadge({ id: 'cc001', title: 'First Post', description: 'Share your first post.', icon: '🖼️', rarity: 'Common', category: 'Content', floorPrice: 10, condition: { type: 'postCount', value: 1 } }),
    createBadge({ id: 'cc002', title: 'Content Creator', description: 'Share 10 posts.', icon: '✍️', rarity: 'Common', category: 'Content', floorPrice: 50, condition: { type: 'postCount', value: 10 } }),
    createBadge({ id: 'cc003', title: 'Reel Rookie', description: 'Share your first reel.', icon: '🎬', rarity: 'Common', category: 'Content', floorPrice: 15, condition: { type: 'reelCount', value: 1 } }),
    createBadge({ id: 'cc004', title: 'Reel Director', description: 'Share 10 reels.', icon: '🎥', rarity: 'Uncommon', category: 'Content', floorPrice: 75, condition: { type: 'reelCount', value: 10 } }),
    createBadge({ id: 'cc005', title: 'Storyteller', description: 'Share your first story.', icon: '📖', rarity: 'Common', category: 'Content', floorPrice: 5, condition: { type: 'storyCount', value: 1 } }),
    createBadge({ id: 'cc006', title: 'Routine Architect', description: 'Create and share your first workout routine.', icon: '🏗️', rarity: 'Uncommon', category: 'Content', floorPrice: 100, condition: { type: 'routineCount', value: 1 } }),
    createBadge({ id: 'cc007', title: 'Top Routine', description: 'Have one of your routines saved by 50 other users.', icon: '⭐', rarity: 'Rare', category: 'Content', floorPrice: 400, condition: { type: 'routineSaves', value: 50 } }),
    createBadge({ id: 'cc008', title: 'Verified', description: 'Get your first Proof of Workout verified by AI.', icon: '✅', rarity: 'Uncommon', category: 'Content', floorPrice: 50, condition: { type: 'verifiedPowCount', value: 1 } }),
    createBadge({ id: 'cc009', title: 'Highlight Reel', description: 'Create your first story highlight.', icon: '✨', rarity: 'Common', category: 'Content', floorPrice: 20, condition: { type: 'highlightCount', value: 1 } }),
    createBadge({ id: 'cc010', title: 'Challenge Creator', description: 'Create your first public challenge.', icon: '📝', rarity: 'Uncommon', category: 'Content', floorPrice: 60, condition: { type: 'challengeCreated', value: 1 } }),
    
    // --- PRO Category ---
    createBadge({ id: 'p001', title: 'AI Coach User', description: 'Start your first conversation with the AI Coach.', icon: '🤖', rarity: 'Common', category: 'PRO', floorPrice: 10, condition: { type: 'usedAiCoach', value: 1 } }),
    createBadge({ id: 'p002', title: 'Image Wizard', description: 'Generate an image using AI.', icon: '🎨', rarity: 'Uncommon', category: 'PRO', floorPrice: 50, condition: { type: 'aiImageGenerated', value: 1 } }),
    createBadge({ id: 'p003', title: 'Video Virtuoso', description: 'Generate a video using AI.', icon: '📹', rarity: 'Rare', category: 'PRO', floorPrice: 200, condition: { type: 'aiVideoGenerated', value: 1 } }),
    createBadge({ id: 'p004', title: 'Smart Eater', description: 'Analyze a meal using AI Nutrition Analysis.', icon: '🔬', rarity: 'Uncommon', category: 'PRO', floorPrice: 40, condition: { type: 'aiMealAnalyzed', value: 1 } }),
    createBadge({ id: 'p005', title: 'AI Planner', description: 'Generate a workout plan with AI.', icon: '📋', rarity: 'Uncommon', category: 'PRO', floorPrice: 70, condition: { type: 'aiPlanGenerated', value: 1 } }),
    createBadge({ id: 'p006', title: 'Form Perfect', description: 'Use the Holographic Form Assistant for the first time.', icon: '🤸', rarity: 'Rare', category: 'PRO', floorPrice: 150, condition: { type: 'usedFormAssistant', value: 1 } }),
    createBadge({ id: 'p007', title: 'Ghost Runner', description: 'Complete a run using the GPS Ghost Run mode.', icon: '👻', rarity: 'Rare', category: 'PRO', floorPrice: 180, condition: { type: 'usedGhostRun', value: 1 } }),
    createBadge({ id: 'p008', title: 'Neural Navigator', description: 'Check your stats with the Neural Link.', icon: '🧠', rarity: 'Epic', category: 'PRO', floorPrice: 500, condition: { type: 'usedNeuralLink', value: 1 } }),
    createBadge({ id: 'p009', title: 'Quantum Reader', description: 'Check your stats with the Quantum HRV.', icon: '💙', rarity: 'Epic', category: 'PRO', floorPrice: 500, condition: { type: 'usedQuantumHrv', value: 1 } }),
    createBadge({ id: 'p010', title: 'Live Participant', description: 'Join your first Meta-Gym live class.', icon: '🧘', rarity: 'Rare', category: 'PRO', floorPrice: 120, condition: { type: 'joinedLiveClass', value: 1 } }),
    
    // --- Economy Category ---
    createBadge({ id: 'e001', title: 'First Earnings', description: 'Earn your first $FIT tokens from a quest.', icon: '💰', rarity: 'Common', category: 'Economy', floorPrice: 10, condition: { type: 'fitTokenEarned', value: 1 } }),
    createBadge({ id: 'e002', title: 'Token Tycoon', description: 'Accumulate a total of 10,000 $FIT.', icon: '💸', rarity: 'Uncommon', category: 'Economy', floorPrice: 100, condition: { type: 'fitTokenBalance', value: 10000 } }),
    createBadge({ id: 'e003', title: 'High Roller', description: 'Accumulate a total of 100,000 $FIT.', icon: '💎', rarity: 'Rare', category: 'Economy', floorPrice: 500, condition: { type: 'fitTokenBalance', value: 100000 } }),
    createBadge({ id: 'e004', title: 'Staker', description: 'Stake $FIT in a challenge for the first time.', icon: '🔒', rarity: 'Uncommon', category: 'Economy', floorPrice: 80, condition: { type: 'stakedFit', value: 1 } }),
    createBadge({ id: 'e005', title: 'Collector', description: 'Own 5 or more different NFTs.', icon: '🖼️', rarity: 'Uncommon', category: 'Economy', floorPrice: 150, condition: { type: 'nftCount', value: 5 } }),
    createBadge({ id: 'e006', title: 'Rare Hunter', description: 'Own at least one "Rare" or higher NFT.', icon: '🎯', rarity: 'Rare', category: 'Economy', floorPrice: 300, condition: { type: 'hasRareNft', value: 1 } }),
    createBadge({ id: 'e007', title: 'Epic Collector', description: 'Own at least one "Epic" NFT.', icon: '✨', rarity: 'Epic', category: 'Economy', floorPrice: 1000, condition: { type: 'hasEpicNft', value: 1 } }),
    createBadge({ id: 'e008', title: 'Legendary', description: 'Own a "Legendary" NFT.', icon: '🦄', rarity: 'Legendary', category: 'Economy', floorPrice: 5000, condition: { type: 'hasLegendaryNft', value: 1 } }),
    createBadge({ id: 'e009', title: 'First Sale', description: 'Successfully sell an NFT on the marketplace.', icon: '📈', rarity: 'Rare', category: 'Economy', floorPrice: 250, condition: { type: 'nftSoldCount', value: 1 } }),
    createBadge({ id: 'e010', title: 'Merchant', description: 'Sell 10 NFTs on the marketplace.', icon: '🏦', rarity: 'Epic', category: 'Economy', floorPrice: 900, condition: { type: 'nftSoldCount', value: 10 } }),
    
    // Add 100 more filler badges to reach 150 total
    // These will be tiered versions of existing badges to create a sense of progression.
    ...Array.from({ length: 20 }, (_, i) => createBadge({ id: `m_extra_${i}`, title: `Step Milestone ${i + 1}`, description: `Reach ${((i + 1) * 50000).toLocaleString()} total steps.`, icon: '👟', rarity: i < 5 ? 'Common' : i < 15 ? 'Uncommon' : 'Rare', category: 'Milestones', floorPrice: 20 + i * 20, condition: { type: 'totalSteps', value: (i + 1) * 50000 } })),
    ...Array.from({ length: 20 }, (_, i) => createBadge({ id: `d_extra_${i}`, title: `Distance Milestone ${i + 1}`, description: `Cover ${((i + 1) * 50).toLocaleString()} total km.`, icon: '🏃‍♂️', rarity: i < 5 ? 'Common' : i < 15 ? 'Uncommon' : 'Rare', category: 'Milestones', floorPrice: 30 + i * 25, condition: { type: 'totalDistance', value: (i + 1) * 50 } })),
    ...Array.from({ length: 10 }, (_, i) => createBadge({ id: `c_extra_${i}`, title: `Hydration Streak ${i + 1}`, description: `Log 8+ glasses of water for ${i + 2} days in a row.`, icon: '💧', rarity: i < 3 ? 'Common' : 'Uncommon', category: 'Consistency', floorPrice: 15 + i * 10, condition: { type: 'hydrationStreak', value: i + 2 } })),
    ...Array.from({ length: 10 }, (_, i) => createBadge({ id: `s_extra_f_${i}`, title: `Follower Goal ${i + 1}`, description: `Reach ${200 + i * 100} followers.`, icon: '👥', rarity: 'Uncommon', category: 'Social', floorPrice: 150 + i * 50, condition: { type: 'followerCount', value: 200 + i * 100 } })),
    ...Array.from({ length: 10 }, (_, i) => createBadge({ id: `s_extra_l_${i}`, title: `Likes Milestone ${i + 1}`, description: `Receive ${2000 + i * 1000} total likes.`, icon: '❤️', rarity: 'Uncommon', category: 'Social', floorPrice: 120 + i * 40, condition: { type: 'totalLikesReceived', value: 2000 + i * 1000 } })),
    ...Array.from({ length: 10 }, (_, i) => createBadge({ id: `cc_extra_p_${i}`, title: `Publisher ${i + 1}`, description: `Share a total of ${20 + i * 10} posts.`, icon: '✍️', rarity: 'Uncommon', category: 'Content', floorPrice: 60 + i * 20, condition: { type: 'postCount', value: 20 + i * 10 } })),
    ...Array.from({ length: 10 }, (_, i) => createBadge({ id: `cc_extra_r_${i}`, title: `Filmmaker ${i + 1}`, description: `Share a total of ${20 + i * 5} reels.`, icon: '🎥', rarity: 'Uncommon', category: 'Content', floorPrice: 80 + i * 25, condition: { type: 'reelCount', value: 20 + i * 5 } })),
    ...Array.from({ length: 10 }, (_, i) => createBadge({ id: `e_extra_t_${i}`, title: `Token Hoarder ${i + 1}`, description: `Hold ${20000 + i * 10000} $FIT in your wallet.`, icon: '💰', rarity: i < 5 ? 'Uncommon' : 'Rare', category: 'Economy', floorPrice: 150 + i * 75, condition: { type: 'fitTokenBalance', value: 20000 + i * 10000 } })),
];
