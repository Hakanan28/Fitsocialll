import React from 'react';
import { ModalType } from '../../types';
import { useTranslation } from '../../hooks/i18n';

interface HeaderProps {
    openModal: (modal: ModalType) => void;
    unreadCount: number;
}

const Header: React.FC<HeaderProps> = ({ openModal, unreadCount }) => {
    const { t } = useTranslation();
    return (
        <header className="sticky top-0 z-10 bg-[#1E1E1E] border-b border-[#333] shadow-lg shadow-black/50 w-full">
            <div className="flex justify-between items-center p-4 max-w-screen-lg mx-auto">
                <div className="flex items-center space-x-2">
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-green-400">
                       <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2Z" stroke="currentColor" strokeWidth="1.5"/>
                       <path d="M15.5 15.5C15.5 14.12 14.38 13 13 13H10C8.62 13 7.5 11.88 7.5 10.5C7.5 9.12 8.62 8 10 8H13C14.38 8 15.5 6.88 15.5 5.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                    <h1 className="text-2xl font-extrabold bg-clip-text text-transparent bg-gradient-to-r from-green-400 to-teal-300 tracking-tight">
                        FitSocial
                    </h1>
                </div>
                <div className="flex space-x-4">
                    {/* FIX: Cast result of t() to string for aria-label */}
                    <button onClick={() => openModal(ModalType.CreatePost)} aria-label={t('header.createPost') as string} className="text-gray-300 hover:text-green-400 transition-all transform hover:scale-110">
                        <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-plus-square"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M8 12h8"/><path d="M12 8v8"/></svg>
                    </button>
                    {/* FIX: Cast result of t() to string for aria-label */}
                    <button onClick={() => openModal(ModalType.Notifications)} aria-label={t('header.notifications') as string} className="relative text-gray-300 hover:text-green-400 transition-all transform hover:scale-110">
                        {unreadCount > 0 && (
                             <span className="absolute top-0 right-0 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-[#1E1E1E]"></span>
                        )}
                        <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-bell"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>
                    </button>
                    {/* FIX: Changed onClick to open GroupChatModal which now serves as the unified messages modal */}
                    <button onClick={() => openModal(ModalType.GroupChat)} aria-label={t('dms.messages') as string} className="text-gray-300 hover:text-green-400 transition-all transform hover:scale-110">
                        <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-message-circle"><path d="M7.9 20C4.5 16.6 3 12.5 3 9.5 3 5.4 6.4 2 10.5 2S18 5.4 18 9.5c0 3-1.5 7.1-4.9 10.5h.1Z"/><path d="M12 13a2 2 0 0 0-2 2v0a2 2 0 0 0 2 2v0a2 2 0 0 0-2-2Z"/><path d="M7 22h10"/></svg>
                    </button>
                </div>
            </div>
        </header>
    );
};

export default Header;