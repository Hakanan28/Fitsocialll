
import React, { useState, useRef, useEffect } from 'react';
import { UserProfile, Comment, ModalType } from '../../types';
import { findUser } from '../../data/users';

interface CommentsOverlayProps {
    isOpen: boolean;
    onClose: () => void;
    comments: Comment[];
    currentUser: UserProfile;
    users: UserProfile[];
    onAddComment: (text: string) => void;
    title?: string;
    openModal?: (modal: ModalType, data?: any) => void;
}

const CommentsOverlay: React.FC<CommentsOverlayProps> = ({ isOpen, onClose, comments, currentUser, users, onAddComment, title = "Comments", openModal }) => {
    const [newComment, setNewComment] = useState('');
    const commentsEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        commentsEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        if (isOpen) {
            scrollToBottom();
        }
    }, [comments, isOpen]);

    const handlePostComment = (e: React.FormEvent) => {
        e.preventDefault();
        if (newComment.trim()) {
            onAddComment(newComment.trim());
            setNewComment('');
        }
    };

    if (!isOpen) return null;

    return (
        <div className="absolute inset-0 z-[60] flex flex-col justify-end animate-fadeIn pointer-events-none">
            {/* Dimmed Background (Click to close) */}
            <div className="absolute inset-0 bg-black/40 pointer-events-auto" onClick={onClose}></div>
            
            {/* Content Sheet */}
            <div className="relative bg-[#1E1E1E] w-full h-[65%] rounded-t-3xl shadow-2xl flex flex-col pointer-events-auto border-t border-white/10 animate-slideInUp">
                {/* Handle Bar */}
                <div className="w-full flex justify-center pt-3 pb-1 cursor-pointer" onClick={onClose}>
                    <div className="w-12 h-1.5 bg-gray-600 rounded-full"></div>
                </div>

                <header className="flex-shrink-0 px-4 py-2 text-center relative border-b border-white/5">
                    <h3 className="text-sm font-bold text-white">{title} <span className="text-gray-500 text-xs">({comments.length})</span></h3>
                    <button onClick={onClose} className="absolute top-1/2 -translate-y-1/2 right-4 text-gray-400 hover:text-white text-xl">&times;</button>
                </header>

                <div className="flex-grow p-4 space-y-4 overflow-y-auto scrollbar-hide">
                    {comments.map((comment) => {
                        const user = findUser(comment.user, users) || (comment.user === currentUser.username ? currentUser : null);
                        const handleViewProfile = (e: React.MouseEvent) => {
                            e.stopPropagation();
                            if (user && openModal) {
                                openModal(ModalType.Profile, user);
                            }
                        };
                        return (
                             <div key={comment.id} className="flex items-start space-x-3">
                                <img 
                                    src={user?.avatarImage || `https://placehold.co/100x100/333/FFF?text=${comment.user.charAt(0)}`} 
                                    alt={comment.user} 
                                    className="w-8 h-8 rounded-full object-cover border border-white/10 cursor-pointer"
                                    onClick={handleViewProfile}
                                />
                                <div className="flex-1">
                                    <p className="text-sm text-white">
                                        <span 
                                            className="font-bold mr-2 text-xs cursor-pointer hover:underline"
                                            onClick={handleViewProfile}
                                        >
                                            {comment.user}
                                        </span>
                                        <span className="text-gray-300 text-xs leading-relaxed">{comment.text}</span>
                                    </p>
                                </div>
                            </div>
                        )
                    })}
                    {comments.length === 0 && (
                        <div className="flex flex-col items-center justify-center h-full text-gray-500 space-y-2">
                            <span className="text-2xl">💬</span>
                            <p className="text-xs">No comments yet. Start the conversation!</p>
                        </div>
                    )}
                    <div ref={commentsEndRef} />
                </div>

                <footer className="flex-shrink-0 p-3 pb-safe bg-[#1E1E1E] border-t border-white/5">
                    <form onSubmit={handlePostComment} className="flex space-x-2 items-center">
                        <img src={currentUser.avatarImage} alt="You" className="w-8 h-8 rounded-full object-cover border border-white/10" />
                        <input
                            type="text"
                            value={newComment}
                            onChange={(e) => setNewComment(e.target.value)}
                            placeholder="Add a comment..."
                            className="flex-1 bg-gray-800 text-xs rounded-full px-4 py-2.5 border border-transparent focus:outline-none focus:ring-1 focus:ring-green-500 text-white placeholder-gray-500"
                            autoFocus
                        />
                        <button type="submit" className="text-green-500 font-bold text-xs hover:text-green-400 disabled:text-gray-600 transition-colors px-2" disabled={!newComment.trim()}>Post</button>
                    </form>
                </footer>
            </div>
        </div>
    );
};

export default CommentsOverlay;
