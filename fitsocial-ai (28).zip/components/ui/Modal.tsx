
import React from 'react';

interface ModalProps {
    children: React.ReactNode;
    closeModal: () => void;
    title: string;
    show: boolean;
}

const Modal: React.FC<ModalProps> = ({ children, closeModal, title, show }) => {
    if (!show) return null;

    const handleOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
        if (e.target === e.currentTarget) {
            closeModal();
        }
    };

    return (
        <div 
            className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-4 animate-fadeIn"
            onClick={handleOverlayClick}
        >
            <div className="bg-gradient-to-br from-[#1f2937] to-[#111827] border border-gray-700 w-full max-w-md p-6 rounded-2xl shadow-2xl shadow-black/50 animate-slideIn flex flex-col max-h-[90vh]">
                <header className="flex justify-between items-center pb-4 border-b border-gray-600 flex-shrink-0">
                    <h3 className="text-xl font-bold text-white">{title}</h3>
                    <button onClick={closeModal} className="text-gray-400 hover:text-white transition-all transform hover:rotate-90">&times;</button>
                </header>
                <div className="flex-grow mt-4 overflow-y-auto">
                    {children}
                </div>
            </div>
        </div>
    );
};

// Add CSS keyframes to your main CSS or index.html style block if not already present
/*
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
@keyframes slideIn { from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
*/

export default Modal;