
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { generateVideo, getVideoOperationStatus } from '../../services/geminiService';
import Modal from '../ui/Modal';
import { ModalType } from '../../types';

interface AiReelGeneratorModalProps {
    closeModal: () => void;
    onVideoGenerated: (url: string) => void;
}

const loadingMessages = [
    "Scanning viral trends...",
    "Generating vertical composition...",
    "Applying cinematic color grade...",
    "Rendering at 9:16 aspect ratio...",
    "Polishing final pixels...",
];

const AiReelGeneratorModal: React.FC<AiReelGeneratorModalProps> = ({ closeModal, onVideoGenerated }) => {
    const [prompt, setPrompt] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [apiKeySelected, setApiKeySelected] = useState(false);
    const [loadingMessage, setLoadingMessage] = useState(loadingMessages[0]);
    
    const intervalRef = useRef<number | null>(null);

    const checkApiKey = useCallback(async () => {
        if (window.aistudio && await window.aistudio.hasSelectedApiKey()) {
            setApiKeySelected(true);
        } else {
            setApiKeySelected(false);
        }
    }, []);

    useEffect(() => {
        checkApiKey();
    }, [checkApiKey]);

    useEffect(() => {
        if (isLoading) {
            intervalRef.current = window.setInterval(() => {
                setLoadingMessage(prev => {
                    const currentIndex = loadingMessages.indexOf(prev);
                    return loadingMessages[(currentIndex + 1) % loadingMessages.length];
                });
            }, 3000);
        } else {
            if(intervalRef.current) clearInterval(intervalRef.current);
        }
        return () => {
            if(intervalRef.current) clearInterval(intervalRef.current);
        };
    }, [isLoading]);

    const handleGenerate = async () => {
        if (!prompt.trim() || !apiKeySelected) return;

        setIsLoading(true);
        setError(null);

        try {
            let operation = await generateVideo(prompt, '9:16');
            
            while (!operation.done) {
                await new Promise(resolve => setTimeout(resolve, 10000));
                try {
                    operation = await getVideoOperationStatus(operation);
                } catch (e: any) {
                    if (e.message?.includes("Requested entity was not found.")) {
                       setError("API Key error. Please re-select your key.");
                       setApiKeySelected(false);
                       setIsLoading(false);
                       return;
                    }
                    throw e;
                }
            }

            const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
            if (downloadLink) {
                const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
                const blob = await response.blob();
                const url = URL.createObjectURL(blob);
                onVideoGenerated(url);
            } else {
                setError("Video generation failed. No video URI returned.");
            }
        } catch (err) {
            console.error(err);
            setError("An error occurred during video generation.");
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleSelectKey = async () => {
        if(window.aistudio) {
            await window.aistudio.openSelectKey();
            setApiKeySelected(true);
            setError(null);
        }
    };

    return (
        <Modal title="🚀 Viral Reel Engine" closeModal={closeModal} show={true}>
            <div className="relative z-10 flex flex-col gap-6">
                 {/* Background Gradient */}
                 <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-indigo-600/10 rounded-full blur-[80px] pointer-events-none"></div>

                {!apiKeySelected ? (
                    <div className="bg-indigo-900/20 border border-indigo-500/30 p-6 rounded-2xl text-center backdrop-blur-sm">
                         <p className="text-indigo-200 font-bold mb-2">API Access Required</p>
                         <button onClick={handleSelectKey} className="bg-indigo-500 text-white font-bold py-2 px-6 rounded-lg hover:bg-indigo-400 transition-all transform hover:scale-105 shadow-lg shadow-indigo-500/20">
                            Select API Key
                        </button>
                    </div>
                ) : (
                    <>
                        <div className="space-y-2">
                             <label className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest ml-1">Creative Brief</label>
                             <div className="relative">
                                <textarea
                                    value={prompt}
                                    onChange={(e) => setPrompt(e.target.value)}
                                    placeholder="e.g., A futuristic gym workout in 4K, energetic editing, neon lighting, vertical format"
                                    className="w-full h-36 p-4 bg-[#0a0a0a] text-white rounded-xl border border-white/10 focus:border-indigo-500/50 focus:ring-0 transition-all resize-none placeholder-gray-600 text-sm leading-relaxed"
                                    disabled={isLoading}
                                />
                                <div className="absolute bottom-3 right-3 flex items-center gap-1 text-[10px] text-gray-500 border border-white/5 px-2 py-1 rounded bg-black/50">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M9 3v18"/></svg>
                                    9:16 LOCKED
                                </div>
                             </div>
                        </div>

                        <button
                            onClick={handleGenerate}
                            disabled={isLoading || !prompt.trim()}
                            className="group relative w-full py-4 rounded-xl font-bold text-white overflow-hidden disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-indigo-900/30"
                        >
                            <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-600 bg-[length:200%_auto] animate-gradient-x"></div>
                            <div className="relative flex items-center justify-center gap-2">
                                {isLoading ? (
                                    <>
                                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                                        <span className="tracking-wider text-sm uppercase">Synthesizing...</span>
                                    </>
                                ) : (
                                    <>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="m22 8-6 4 6 4V8Z"/><rect width="14" height="12" x="2" y="6" rx="2" ry="2"/></svg>
                                        <span className="tracking-wider text-sm uppercase">Generate Reel</span>
                                    </>
                                )}
                            </div>
                        </button>
                    </>
                )}
                
                {isLoading && (
                    <div className="mt-2 text-center">
                        <p className="text-indigo-300 font-mono text-xs animate-pulse">{loadingMessage}</p>
                    </div>
                )}

                {error && (
                    <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-300 text-xs text-center">
                        {error}
                    </div>
                )}
            </div>
        </Modal>
    );
};

export default AiReelGeneratorModal;
