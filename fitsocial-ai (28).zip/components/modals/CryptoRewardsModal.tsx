
import React, { useEffect } from 'react';
import Modal from '../ui/Modal';

interface CryptoRewardsModalProps {
    closeModal: () => void;
    fitTokenBalance: number; // Balance BEFORE reward
    onClaim: (amount: number) => void;
    data: {
        amount: number;
        reason: string;
    };
}

const CryptoRewardsModal: React.FC<CryptoRewardsModalProps> = ({ closeModal, fitTokenBalance, onClaim, data }) => {
    const { amount, reason } = data;

    useEffect(() => {
        // Claim the reward once when the modal opens
        if (amount > 0) {
            onClaim(amount);
        }
    }, [amount, onClaim]);
    
    return (
        <Modal title="💰 Crypto Reward Claimed!" closeModal={closeModal} show={true}>
            <div className="text-center">
                <span className="text-5xl">🎉</span>
                <p className="text-md text-gray-300 my-4">{reason}</p>
                <div className="space-y-3 bg-gray-800 p-4 rounded-xl">
                    <div className="flex justify-between items-center">
                        <span className="text-gray-400">Reward Claimed:</span>
                        <span className="text-xl font-bold text-green-400">+{amount} $FIT</span>
                    </div>
                     <div className="flex justify-between items-center">
                        <span className="text-gray-400">New Wallet Balance:</span>
                        <span className="text-2xl font-extrabold text-yellow-500">{(fitTokenBalance + amount).toLocaleString()} $FIT</span>
                    </div>
                </div>
                <button onClick={closeModal} className="w-full bg-green-500 text-white py-3 rounded-xl font-bold mt-6 shadow-md hover:bg-green-600 transition-colors transform hover:scale-105">Awesome!</button>
            </div>
        </Modal>
    );
};

export default CryptoRewardsModal;
