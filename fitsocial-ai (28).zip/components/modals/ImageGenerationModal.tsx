
import React, { useState } from 'react';
import { generateImage } from '../../services/geminiService';
import Modal from '../ui/Modal';

interface ImageGenerationModalProps {
    closeModal: () => void;
    onImageGenerated?: (imageUrl: string) => void;
}

const ImageGenerationModal: React.FC<ImageGenerationModalProps> = ({ closeModal, onImageGenerated }) => {
    const [prompt, setPrompt] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [imageUrl, setImageUrl] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    const handleGenerate = async () => {
        if (!prompt.trim()) return;

        setIsLoading(true);
        setImageUrl(null);
        setError(null);

        try {
            const url = await generateImage(prompt);
            setImageUrl(url);
        } catch (err) {
            console.error(err);
            const errorMessage = err instanceof Error ? err.message : "An error occurred during image generation.";
            setError(errorMessage);
        } finally {
            setIsLoading(false);
        }
    };

    const handleUseImage = () => {
        if (imageUrl && onImageGenerated) {
            onImageGenerated(imageUrl);
            closeModal();
        }
    };

    return (
        <Modal title="🎨 AI Text-to-Image" closeModal={closeModal} show={true}>
            <div className="relative z-10 flex flex-col gap-6">
                {/* Background Glows */}
                <div className="absolute top-10 left-10 w-32 h-32 bg-purple-500/20 rounded-full blur-[50px] pointer-events-none"></div>
                <div className="absolute bottom-10 right-10 w-32 h-32 bg-blue-500/20 rounded-full blur-[50px] pointer-events-none"></div>

                {/* Input Area */}
                <div className="space-y-2">
                    <label className="text-xs font-bold text-purple-400 uppercase tracking-widest ml-1">Imagine</label>
                    <div className="relative group">
                        <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl blur opacity-30 group-hover:opacity-75 transition duration-500"></div>
                        <textarea
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder="Describe your vision... (e.g., A cyberpunk city with neon rain, cinematic lighting)"
                            className="relative w-full h-32 p-4 bg-[#0a0a0a] text-white rounded-xl border border-white/10 focus:border-purple-500/50 focus:ring-0 transition-all resize-none placeholder-gray-600 text-sm leading-relaxed"
                            disabled={isLoading}
                        />
                        <div className="absolute bottom-3 right-3 text-[10px] text-gray-600 bg-black/50 px-2 py-1 rounded-md border border-white/5">
                            Gemini 2.5 Flash Image
                        </div>
                    </div>
                </div>

                {/* Action Button */}
                {!imageUrl && (
                    <button
                        onClick={handleGenerate}
                        disabled={isLoading || !prompt.trim()}
                        className="group relative w-full py-4 rounded-xl font-bold text-white overflow-hidden disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-purple-900/20"
                    >
                        <div className="absolute inset-0 bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-600 bg-[length:200%_auto] animate-gradient-x"></div>
                        <div className="relative flex items-center justify-center gap-2">
                            {isLoading ? (
                                <>
                                    <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                    </svg>
                                    <span className="tracking-wider text-sm">DREAMING...</span>
                                </>
                            ) : (
                                <>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/><path d="M19 3v4"/><path d="M21 5h-4"/></svg>
                                    <span className="tracking-wider text-sm">GENERATE ART</span>
                                </>
                            )}
                        </div>
                    </button>
                )}

                {/* Error State */}
                {error && (
                    <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-xl flex items-center gap-3 text-red-200 text-xs animate-fadeIn">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>
                        {error}
                    </div>
                )}

                {/* Result State */}
                {imageUrl && (
                    <div className="space-y-4 animate-fadeIn">
                        <div className="relative rounded-2xl overflow-hidden border border-white/10 group shadow-2xl">
                            <img src={imageUrl} alt={prompt} className="w-full h-auto object-cover" />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                                <p className="text-white text-xs line-clamp-2 font-medium">{prompt}</p>
                            </div>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-3">
                            <button
                                onClick={() => { setImageUrl(null); }}
                                className="py-3 rounded-xl bg-white/5 hover:bg-white/10 text-white text-xs font-bold border border-white/5 transition-colors"
                            >
                                Discard
                            </button>
                            <button
                                onClick={handleUseImage}
                                className="py-3 rounded-xl bg-green-500 hover:bg-green-600 text-white text-xs font-bold shadow-lg shadow-green-900/30 transition-all transform hover:scale-105"
                            >
                                Use This Art
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </Modal>
    );
};

export default ImageGenerationModal;
