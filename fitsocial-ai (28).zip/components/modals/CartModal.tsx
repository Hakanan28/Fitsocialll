
import React from 'react';
import Modal from '../ui/Modal';
import { CartItem } from '../../types';

interface CartModalProps {
    closeModal: () => void;
    cart: CartItem[];
    updateQuantity: (id: string, delta: number) => void;
    removeFromCart: (id: string) => void;
}

const CartModal: React.FC<CartModalProps> = ({ closeModal, cart, updateQuantity, removeFromCart }) => {
    const subtotal = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
    const shipping = subtotal > 50 ? 0 : 10; // Free shipping over $50 mock logic
    const total = subtotal + shipping;

    const handleCheckout = () => {
        alert("Checkout flow initiated! (Payment integration needed)");
        closeModal();
    };

    return (
        <Modal title="Your Cart" closeModal={closeModal} show={true}>
            <div className="flex flex-col h-full max-h-[70vh]">
                {cart.length === 0 ? (
                    <div className="flex flex-col items-center justify-center flex-1 py-12 text-center text-gray-500">
                        <span className="text-6xl mb-4 opacity-50">🛒</span>
                        <h3 className="text-lg font-bold text-white mb-1">Your cart is empty</h3>
                        <p className="text-sm">Looks like you haven't added any gear yet.</p>
                        <button onClick={closeModal} className="mt-6 px-6 py-2 bg-white text-black rounded-full font-bold text-sm hover:bg-gray-200">
                            Continue Shopping
                        </button>
                    </div>
                ) : (
                    <>
                        {/* Cart Items List */}
                        <div className="flex-1 overflow-y-auto space-y-4 p-1">
                            {cart.map((item) => (
                                <div key={item.id} className="flex gap-4 bg-[#1E1E1E] p-3 rounded-xl border border-white/5 relative group">
                                    {/* Image */}
                                    <div className="w-20 h-20 bg-white rounded-lg overflow-hidden flex-shrink-0">
                                        <img src={item.product.image} alt={item.product.title} className="w-full h-full object-cover" />
                                    </div>
                                    
                                    {/* Details */}
                                    <div className="flex-1 flex flex-col justify-between">
                                        <div>
                                            <div className="flex justify-between items-start">
                                                <h4 className="text-sm font-bold text-white line-clamp-2 pr-6">{item.product.title}</h4>
                                                <button 
                                                    onClick={() => removeFromCart(item.id)} 
                                                    className="text-gray-500 hover:text-red-500 p-1 absolute top-2 right-2"
                                                >
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                                                </button>
                                            </div>
                                            <p className="text-[10px] text-gray-400 mt-1">Sold by {item.product.seller.username}</p>
                                            {item.selectedVariant && <p className="text-[10px] text-blue-400 font-bold mt-0.5">Variant: {item.selectedVariant}</p>}
                                        </div>

                                        <div className="flex justify-between items-end mt-2">
                                            <p className="text-md font-black text-white">{item.product.currency}{item.product.price.toFixed(2)}</p>
                                            
                                            {/* Qty Control */}
                                            <div className="flex items-center bg-black rounded-lg border border-gray-700 h-8">
                                                <button onClick={() => updateQuantity(item.id, -1)} className="w-8 h-full text-gray-400 hover:text-white hover:bg-gray-800 rounded-l-lg transition-colors">-</button>
                                                <span className="w-8 text-center text-xs font-bold text-white">{item.quantity}</span>
                                                <button onClick={() => updateQuantity(item.id, 1)} className="w-8 h-full text-gray-400 hover:text-white hover:bg-gray-800 rounded-r-lg transition-colors">+</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>

                        {/* Order Summary */}
                        <div className="mt-6 pt-4 border-t border-white/10 space-y-3 bg-[#151515] p-4 rounded-2xl">
                            <div className="flex justify-between text-sm text-gray-400">
                                <span>Subtotal</span>
                                <span>${subtotal.toFixed(2)}</span>
                            </div>
                            <div className="flex justify-between text-sm text-gray-400">
                                <span>Shipping</span>
                                <span>{shipping === 0 ? <span className="text-green-400">Free</span> : `$${shipping.toFixed(2)}`}</span>
                            </div>
                            <div className="flex justify-between items-center pt-3 border-t border-white/10">
                                <span className="font-bold text-white">Total</span>
                                <span className="text-xl font-black text-white">${total.toFixed(2)}</span>
                            </div>
                            
                            <button onClick={handleCheckout} className="w-full bg-white text-black font-black py-4 rounded-xl text-lg shadow-lg hover:bg-gray-200 transition-transform active:scale-95 mt-4 uppercase tracking-wide">
                                Checkout
                            </button>
                        </div>
                    </>
                )}
            </div>
        </Modal>
    );
};

export default CartModal;
