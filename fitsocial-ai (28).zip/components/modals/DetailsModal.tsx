import React from 'react';
import Modal from '../ui/Modal';
import { Challenge } from '../../types';

interface DetailsModalProps {
    closeModal: () => void;
    type: 'Program' | 'Routine' | 'Group' | 'Coach' | 'Challenge';
    data: any;
}

const DetailsModal: React.FC<DetailsModalProps> = ({ closeModal, type, data }) => {
    if (!data) return null;

    if (type === 'Challenge') {
        const challenge: Challenge = data;
        const { onJoin } = data;
        return (
            <Modal title={challenge.isAiChallenge ? `✨ ${challenge.title}` : challenge.title} closeModal={closeModal} show={true}>
                <div className="space-y-4">
                    <p className="text-md text-gray-300">{challenge.description}</p>
                    <div className="p-3 bg-gray-800 rounded-lg space-y-2">
                        <div className="flex justify-between text-sm"><span className="text-gray-400">Goal:</span> <span className="font-bold text-white">{challenge.goal}</span></div>
                        <div className="flex justify-between text-sm"><span className="text-gray-400">Duration:</span> <span className="font-bold text-white">{challenge.duration} {challenge.duration > 1 ? 'days' : 'day'}</span></div>
                        <div className="flex justify-between text-sm items-center"><span className="text-gray-400">Created by:</span> <div className="flex items-center gap-2"><img src={challenge.creator.avatarImage} alt={challenge.creator.username} className="w-5 h-5 rounded-full" /><span className="font-bold text-white">{challenge.creator.username}</span></div></div>
                        {challenge.prizePool > 0 && <div className="flex justify-between text-sm"><span className="text-gray-400">Prize Pool:</span> <span className="font-bold text-yellow-400">{challenge.prizePool.toLocaleString()} $FIT</span></div>}
                    </div>
                    <div>
                        <h4 className="text-sm font-bold text-gray-300 mb-2">Participants ({challenge.participants.length})</h4>
                        <div className="flex flex-wrap gap-2">
                            {challenge.participants.map(p => (
                                <img key={p.username} src={p.avatarImage} alt={p.username} title={p.username} className="w-9 h-9 rounded-full ring-2 ring-gray-600" />
                            ))}
                        </div>
                    </div>
                    
                    <button
                        onClick={() => onJoin(challenge.id)}
                        className="w-full bg-green-500 text-white py-2 rounded-xl font-bold mt-6 hover:bg-green-600 transition-colors transform hover:scale-105"
                    >
                        Join Challenge
                    </button>
                </div>
            </Modal>
        )
    }

    return (
        <Modal title={`${type} Details`} closeModal={closeModal} show={true}>
            <div className="space-y-4">
                <h2 className="text-2xl font-bold text-green-400">{data.title}</h2>
                <p className="text-md text-gray-300">{data.description}</p>
                {type === 'Routine' && data.exercises && (
                    <div>
                        <h3 className="text-lg font-semibold text-white mt-4 mb-2">Exercises:</h3>
                        <ul className="list-disc list-inside space-y-1 text-gray-300">
                            {data.exercises.map((ex: string, i: number) => <li key={i}>{ex}</li>)}
                        </ul>
                    </div>
                )}
                <button
                    onClick={closeModal}
                    className="w-full bg-gray-600 text-white py-2 rounded-xl font-bold mt-6 hover:bg-gray-700 transition-colors transform hover:scale-105"
                >
                    Close
                </button>
            </div>
        </Modal>
    );
};

export default DetailsModal;