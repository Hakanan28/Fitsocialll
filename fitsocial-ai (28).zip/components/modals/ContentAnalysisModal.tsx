
import React, { useState, useEffect, useRef } from 'react';
import { analyzeContent } from '../../services/geminiService';
import Modal from '../ui/Modal';

interface ContentAnalysisModalProps {
    closeModal: () => void;
    modalData?: { mediaFile?: File };
}

const ContentAnalysisModal: React.FC<ContentAnalysisModalProps> = ({ closeModal, modalData }) => {
    const [userQuery, setUserQuery] = useState('');
    const [file, setFile] = useState<File | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [result, setResult] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [preview, setPreview] = useState<string | null>(null);
    const [progress, setProgress] = useState(0);
    const scrollRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (modalData?.mediaFile) {
            handleFileSelection(modalData.mediaFile);
        }
    }, [modalData]);

    useEffect(() => {
        if (result && scrollRef.current) {
            scrollRef.current.scrollIntoView({ behavior: 'smooth' });
        }
    }, [result]);

    // Simulate scanning progress
    useEffect(() => {
        let interval: number;
        if (isLoading) {
            setProgress(0);
            interval = window.setInterval(() => {
                setProgress(prev => {
                    if (prev >= 95) return 95;
                    return prev + Math.random() * 5;
                });
            }, 500);
        } else {
            setProgress(100);
        }
        return () => clearInterval(interval);
    }, [isLoading]);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFile = e.target.files?.[0];
        if (selectedFile) {
            handleFileSelection(selectedFile);
        }
    };

    const handleFileSelection = (selectedFile: File) => {
        // Browser base64 limit check (roughly 500MB is risky, strictly keeping it safe for demo)
        if (selectedFile.size > 200 * 1024 * 1024) {
             setError("Warning: Large file detected. Browser may freeze during processing. For long videos, ensure you have a stable connection.");
        } else {
            setError(null);
        }

        setFile(selectedFile);
        setResult(null);
        
        const reader = new FileReader();
        reader.onloadend = () => {
            setPreview(reader.result as string);
        };
        reader.readAsDataURL(selectedFile);
    };
    
    const fileToBase64 = (file: File): Promise<string> => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => {
                const result = reader.result as string;
                // Remove Data URL prefix to get raw base64
                const base64 = result.split(',')[1];
                resolve(base64);
            };
            reader.onerror = error => reject(error);
        });
    };

    const handleAnalyze = async () => {
        if (!file) return;

        setIsLoading(true);
        setResult(null);
        setError(null);

        try {
            const base64Data = await fileToBase64(file);
            
            // Powerful Prompt Engineering for Long-Form Content
            const mediaType = file.type.startsWith('video') ? 'video' : 'image';
            const detailedPrompt = `
            **ROLE:** You are an elite AI Vision Analyst PRO.
            
            **TASK:** Perform a DEEP DIVE, FRAME-BY-FRAME (if video) or PIXEL-PERFECT (if image) analysis of the provided content. 
            
            **CRITICAL INSTRUCTION:** The user demands a **VERY LONG**, **EXTREMELY DETAILED**, and **COMPREHENSIVE** report. Do not summarize briefly. Expand on every detail.
            
            **USER QUERY:** "${userQuery || 'Analyze everything visible in this media.'}"

            **REQUIRED OUTPUT STRUCTURE (Use Markdown):**

            ## 1. 📋 Executive Intelligence Report
            (Provide a rich 3-4 paragraph overview. Describe the narrative arc, the subject's intent, and the overall "vibe" of the content with high-level vocabulary.)

            ## 2. 🔬 Frame-by-Frame / Visual Breakdown
            ${mediaType === 'video' ? 
            '(Since this is a video, provide a chronological breakdown. E.g., "0:00-0:10: Initial setup...", "0:10-0:30: Main action...". Describe movements, transitions, and pacing in granular detail.)' : 
            '(Scan the image from top-left to bottom-right. Describe every object, texture, lighting nuance, and background element. Miss nothing.)'}

            ## 3. 🎬 Technical Cinematography Analysis
            *   **Lighting:** (e.g., Natural, Studio, High-key, Low-key, Color Temperature)
            *   **Camera Work:** (e.g., Static, Handheld, Drone, Angles, Focal Length estimates)
            *   **Composition:** (e.g., Rule of Thirds, Symmetry, Depth of Field)

            ## 4. 🏋️‍♂️ Domain Specific Deep-Dive (Fitness/Activity)
            (Analyze the biomechanics, form, equipment quality, and intensity level. If not fitness, analyze the primary activity with expert domain knowledge.)

            ## 5. 🧠 Behavioral & Psychological Profiling
            *   Analyze the subject's micro-expressions, body language, and emotional state.
            *   What does this content say about the creator's personality or goal?

            ## 6. 💡 Hidden Anomalies & Easter Eggs
            *   List 5+ specific details that 99% of viewers would miss.
            *   Predict what might happen next or what happened just before this.

            **LANGUAGE:** Respond in the language of the User Query (or English if neutral). If the user asks in Turkish, reply in Turkish.
            `;

            const analysis = await analyzeContent(detailedPrompt, base64Data, file.type);
            setResult(analysis);
        } catch (err) {
            console.error(err);
            let errorMessage = "An error occurred during content analysis.";
            if (err instanceof Error) {
                if (err.message.includes("413")) {
                    errorMessage = "File is too large for direct browser processing. Please use a smaller file.";
                } else {
                    errorMessage = err.message;
                }
            }
            setError(errorMessage);
        } finally {
            setIsLoading(false);
        }
    };

    const renderMarkdown = (text: string) => {
        return text.split('\n').map((line, i) => {
            if (line.startsWith('## ')) return <h3 key={i} className="text-lg font-bold text-amber-400 mt-6 mb-3 border-b border-amber-500/30 pb-1">{line.replace('## ', '')}</h3>;
            if (line.startsWith('* ')) return <li key={i} className="text-gray-300 ml-4 list-disc mb-1">{line.replace('* ', '')}</li>;
            if (line.trim() === '') return <br key={i} />;
            return <p key={i} className="text-gray-300 mb-2 leading-relaxed">{line}</p>;
        });
    };

    return (
        <Modal title="👁️ VISION ANALYTICS PRO" closeModal={closeModal} show={true}>
            <div className="relative z-10 flex flex-col gap-5 max-h-[80vh]">
                {/* Top Scanner Line Animation */}
                <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-amber-500 to-transparent opacity-70 animate-pulse"></div>

                {/* Media Upload/Preview Area */}
                 <div className="w-full relative group shrink-0">
                    {preview ? (
                        <div className="relative w-full h-56 rounded-xl overflow-hidden border border-amber-500/30 bg-black shadow-[0_0_15px_rgba(245,158,11,0.1)]">
                             {/* Scanning overlay effect when loading */}
                             {isLoading && (
                                 <>
                                    <div className="absolute inset-0 bg-amber-500/10 z-20"></div>
                                    <div className="absolute top-0 left-0 w-full h-1 bg-amber-400 shadow-[0_0_20px_#f59e0b] z-30 animate-scan-vertical"></div>
                                    <div className="absolute inset-0 flex items-center justify-center z-40">
                                        <div className="bg-black/80 text-amber-500 font-mono text-xs px-4 py-2 rounded border border-amber-500/50 backdrop-blur-md flex flex-col items-center gap-1">
                                            <span className="font-bold tracking-widest">NEURAL SCANNING</span>
                                            <span className="text-[10px] opacity-80">{Math.round(progress)}% COMPLETE</span>
                                        </div>
                                    </div>
                                 </>
                             )}
                             
                             {file?.type.startsWith('image/') ? (
                                 <img src={preview} alt="Preview" className="w-full h-full object-contain opacity-90" />
                            ) : (
                                 <video src={preview} controls className="w-full h-full object-contain opacity-90" />
                            )}
                             
                             {!isLoading && (
                                <label className="absolute top-2 right-2 cursor-pointer bg-black/60 hover:bg-amber-600 text-white p-2 rounded-lg backdrop-blur-md transition-colors border border-white/10 z-30 group">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/></svg>
                                    <input type="file" accept="image/*,video/*" onChange={handleFileChange} className="hidden" disabled={isLoading}/>
                                </label>
                             )}
                        </div>
                    ) : (
                        <label className="w-full h-48 rounded-xl border-2 border-dashed border-amber-500/30 bg-amber-950/10 flex flex-col items-center justify-center cursor-pointer hover:border-amber-500 hover:bg-amber-900/20 transition-all group">
                            <div className="w-16 h-16 rounded-full bg-amber-900/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform border border-amber-500/20 group-hover:border-amber-500/50">
                                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="text-amber-500"><rect width="18" height="18" x="3" y="3" rx="2"/><circle cx="12" cy="12" r="3"/><path d="M12 5v2"/><path d="M12 17v2"/><path d="M5 12h2"/><path d="M17 12h2"/></svg>
                            </div>
                            <span className="text-sm font-bold text-amber-500/80 uppercase tracking-widest">Upload Media Source</span>
                            <span className="text-[10px] text-amber-500/50 mt-1">Support for Long Videos & High-Res Images</span>
                            <input type="file" accept="image/*,video/*" onChange={handleFileChange} className="hidden" />
                        </label>
                    )}
                </div>

                {/* Controls Area */}
                <div className="shrink-0 space-y-3">
                    <div className="relative">
                         <input
                            type="text"
                            value={userQuery}
                            onChange={(e) => setUserQuery(e.target.value)}
                            placeholder="Specific focus? (e.g., 'Analyze Form', 'Detect Emotions')"
                            className="w-full p-4 pr-24 bg-[#0a0a0a] text-white rounded-xl border border-amber-900/50 focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 transition-all placeholder-gray-600 text-sm font-mono"
                            disabled={isLoading}
                        />
                        <button
                            onClick={handleAnalyze}
                            disabled={isLoading || !file}
                            className="absolute right-2 top-2 bottom-2 bg-gradient-to-r from-amber-600 to-orange-700 hover:from-amber-500 hover:to-orange-600 text-black px-4 rounded-lg font-extrabold text-xs shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 tracking-wider"
                        >
                            {isLoading ? <div className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin"></div> : <span>ANALYZE PRO</span>}
                        </button>
                    </div>
                </div>

                {/* Results Area - Scrollable */}
                <div className="flex-1 min-h-[150px] bg-[#050505] border border-amber-900/30 rounded-xl p-4 overflow-y-auto shadow-inner relative scrollbar-thin scrollbar-thumb-amber-900 scrollbar-track-black" ref={scrollRef}>
                    {isLoading ? (
                        <div className="flex flex-col items-center justify-center h-full text-amber-500/50 space-y-4">
                            <div className="flex gap-1 h-8 items-end">
                                <div className="w-1 bg-amber-500 animate-[bounce_1s_infinite_0ms] h-[40%]"></div>
                                <div className="w-1 bg-amber-500 animate-[bounce_1s_infinite_100ms] h-[70%]"></div>
                                <div className="w-1 bg-amber-500 animate-[bounce_1s_infinite_200ms] h-[100%]"></div>
                                <div className="w-1 bg-amber-500 animate-[bounce_1s_infinite_300ms] h-[60%]"></div>
                                <div className="w-1 bg-amber-500 animate-[bounce_1s_infinite_400ms] h-[30%]"></div>
                            </div>
                            <p className="text-xs font-mono animate-pulse text-center">
                                EXTRACTING FRAMES...<br/>
                                ANALYZING PIXELS...<br/>
                                GENERATING DEEP REPORT...
                            </p>
                        </div>
                    ) : result ? (
                         <div className="animate-fadeIn pb-4">
                            <div className="flex items-center gap-2 mb-4 border-b border-amber-900/30 pb-2 sticky top-0 bg-[#050505]/95 backdrop-blur z-10">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-amber-500"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" x2="8" y1="13" y2="13"/><line x1="16" x2="8" y1="17" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
                                <span className="text-xs font-black text-amber-500 uppercase tracking-widest">Full Analysis Report</span>
                            </div>
                            <div className="prose prose-invert prose-sm max-w-none font-sans">
                                {renderMarkdown(result)}
                            </div>
                        </div>
                    ) : error ? (
                         <div className="h-full flex flex-col items-center justify-center text-center p-4">
                            <div className="w-12 h-12 rounded-full bg-red-900/20 border border-red-500/50 flex items-center justify-center mb-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-red-500"><line x1="18" x2="6" y1="6" y2="18"/><line x1="6" x2="18" y1="6" y2="18"/></svg>
                            </div>
                            <p className="text-red-400 text-xs font-bold uppercase">System Error</p>
                            <p className="text-red-300/60 text-[10px] mt-2 max-w-xs">{error}</p>
                         </div>
                    ) : (
                         <div className="flex flex-col items-center justify-center h-full text-gray-700">
                             <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" className="mb-3 opacity-20"><path d="M2 12h20"/><path d="M2 12l5-5"/><path d="M2 12l5 5"/></svg>
                             <span className="text-[10px] font-mono opacity-40 tracking-widest uppercase">Awaiting Input Stream</span>
                         </div>
                    )}
                </div>
            </div>
            <style>{`
                @keyframes scan-vertical {
                    0% { top: 0%; }
                    50% { top: 100%; }
                    100% { top: 0%; }
                }
                .animate-scan-vertical {
                    animation: scan-vertical 2s linear infinite;
                }
            `}</style>
        </Modal>
    );
};

export default ContentAnalysisModal;
