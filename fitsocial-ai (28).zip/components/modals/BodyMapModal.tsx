import React from 'react';

interface BodyMapModalProps {
    closeModal: () => void;
    fitTokenBalance: number;
    setFitTokenBalance: React.Dispatch<React.SetStateAction<number>>;
}

const BodyMapModal: React.FC<BodyMapModalProps> = ({ closeModal }) => {
    return (
        <div className="fixed inset-0 bg-black/90 z-[150] flex flex-col animate-fadeIn">
            <header className="flex-shrink-0 flex justify-between items-center p-4 border-b border-yellow-700 bg-[#0A0A0A] shadow-lg shadow-yellow-900/50">
                <h2 className="text-xl font-bold text-yellow-400" style={{textShadow: '0 0 5px #FBBF24'}}>🔥 3D Body Map</h2>
                <button onClick={closeModal} className="text-red-500 font-bold hover:text-red-400 transition-colors">Close</button>
            </header>
            <main className="flex-1 flex flex-col items-center justify-center text-center overflow-hidden p-4">
                <div className="w-full h-full bg-gray-900 rounded-xl flex flex-col items-center justify-center border-2 border-dashed border-yellow-700">
                     <span className="text-5xl mb-4">🚧</span>
                    <h3 className="text-2xl font-bold text-yellow-400">Under Reconstruction</h3>
                    <p className="text-gray-400 mt-2 max-w-sm">
                        The 3D Body Map feature is temporarily unavailable while we perform some upgrades. It will be back soon!
                    </p>
                </div>
            </main>
        </div>
    );
};

export default BodyMapModal;