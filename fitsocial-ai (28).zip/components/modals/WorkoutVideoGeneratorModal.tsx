
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { generateVideo, getVideoOperationStatus } from '../../services/geminiService';
import Modal from '../ui/Modal';

interface WorkoutVideoGeneratorModalProps {
    closeModal: () => void;
}

const loadingMessages = [
    "Warming up the AI personal trainer...",
    "Filming the perfect form...",
    "Editing the demonstration clip...",
    "This can take a few minutes, hang tight!",
    "Adding finishing touches to the video...",
];

const WorkoutVideoGeneratorModal: React.FC<WorkoutVideoGeneratorModalProps> = ({ closeModal }) => {
    const [exerciseName, setExerciseName] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [videoUrl, setVideoUrl] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [apiKeySelected, setApiKeySelected] = useState(false);
    const [loadingMessage, setLoadingMessage] = useState(loadingMessages[0]);
    
    const intervalRef = useRef<number | null>(null);

    const checkApiKey = useCallback(async () => {
        if (window.aistudio && await window.aistudio.hasSelectedApiKey()) {
            setApiKeySelected(true);
        } else {
            setApiKeySelected(false);
        }
    }, []);

    useEffect(() => {
        checkApiKey();
    }, [checkApiKey]);

    useEffect(() => {
        if (isLoading) {
            intervalRef.current = window.setInterval(() => {
                setLoadingMessage(prev => {
                    const currentIndex = loadingMessages.indexOf(prev);
                    return loadingMessages[(currentIndex + 1) % loadingMessages.length];
                });
            }, 3000);
        } else {
            if(intervalRef.current) clearInterval(intervalRef.current);
        }
        return () => {
            if(intervalRef.current) clearInterval(intervalRef.current);
        };
    }, [isLoading]);

    const handleGenerate = async () => {
        if (!exerciseName.trim() || !apiKeySelected) return;

        setIsLoading(true);
        setVideoUrl(null);
        setError(null);

        const prompt = `A clear, high-quality, short video of a person demonstrating how to do ${exerciseName} correctly. Front view, plain white background, fitness attire.`;
        const aspectRatio = '9:16'; // Portrait for workout clips

        try {
            let operation = await generateVideo(prompt, aspectRatio);
            
            while (!operation.done) {
                await new Promise(resolve => setTimeout(resolve, 10000)); // Poll every 10 seconds
                try {
                    operation = await getVideoOperationStatus(operation);
                } catch (e: any) {
                    if (e.message?.includes("Requested entity was not found.")) {
                       setError("API Key error. Please re-select your key.");
                       setApiKeySelected(false);
                       setIsLoading(false);
                       return;
                    }
                    throw e;
                }
            }

            const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
            if (downloadLink) {
                const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
                const blob = await response.blob();
                const url = URL.createObjectURL(blob);
                setVideoUrl(url);
            } else {
                setError("Video generation failed. No video URI returned.");
            }
        } catch (err) {
            console.error(err);
            setError("An error occurred during video generation.");
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleSelectKey = async () => {
        if(window.aistudio) {
            await window.aistudio.openSelectKey();
            setApiKeySelected(true);
            setError(null);
        }
    };

    return (
        <Modal title="AI Workout Video Generator" closeModal={closeModal} show={true}>
            {!apiKeySelected && (
                <div className="bg-yellow-900/50 border border-yellow-600 p-4 rounded-lg text-center">
                    <p className="text-yellow-300 mb-3">Please select an API key to use the video generation feature.</p>
                    <button onClick={handleSelectKey} className="bg-yellow-500 text-black font-bold py-2 px-4 rounded-lg hover:bg-yellow-400 transition-all transform hover:scale-105">
                        Select API Key
                    </button>
                    <p className="text-xs text-yellow-400 mt-2">Note: Video generation may incur costs. See <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="underline">billing details</a>.</p>
                </div>
            )}

            <div className="space-y-4 mt-4">
                <input
                    type="text"
                    value={exerciseName}
                    onChange={(e) => setExerciseName(e.target.value)}
                    placeholder="e.g., Dumbbell Bicep Curls"
                    className="w-full p-3 bg-gray-800 text-white rounded-xl border border-gray-600 focus:border-red-500 focus:ring-0 transition"
                    disabled={isLoading || !apiKeySelected}
                />
                <button
                    onClick={handleGenerate}
                    disabled={isLoading || !exerciseName.trim() || !apiKeySelected}
                    className="w-full bg-red-500 text-white font-bold py-3 rounded-xl hover:bg-red-600 transition-all transform hover:scale-105 disabled:bg-gray-500 disabled:cursor-not-allowed"
                >
                    {isLoading ? 'Generating Clip...' : 'Generate Exercise Clip'}
                </button>
            </div>
            
            {isLoading && (
                <div className="mt-4 text-center">
                    <div className="w-8 h-8 border-4 border-t-red-400 border-gray-600 rounded-full animate-spin mx-auto"></div>
                    <p className="text-red-300 mt-2 animate-pulse">{loadingMessage}</p>
                </div>
            )}
            {error && <p className="mt-4 text-red-400 text-center">{error}</p>}
            {videoUrl && (
                <div className="mt-4">
                    <h4 className="font-bold text-white mb-2">Generated Video:</h4>
                    <video src={videoUrl} controls autoPlay loop className="w-full rounded-lg" />
                </div>
            )}
        </Modal>
    );
};

export default WorkoutVideoGeneratorModal;
