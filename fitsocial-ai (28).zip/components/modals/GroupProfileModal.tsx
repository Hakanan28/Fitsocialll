
import React from 'react';
import { UserProfile, Group, ModalType } from '../../types';
import GroupInfoModal from './GroupInfoModal';

interface GroupProfileModalProps {
    closeModal: () => void;
    currentUser: UserProfile;
    fitTokenBalance: number; // Unused in new layout but kept for interface stability
    groups: Group[]; // Unused here, data is derived in GroupInfoModal for user
    openModal: (modal: ModalType, data?: any) => void;
    setCurrentPage?: any;
}

const GroupProfileModal: React.FC<GroupProfileModalProps> = ({ closeModal, currentUser, openModal }) => {
    return (
        <div className="fixed inset-0 bg-black/90 z-[600] flex items-center justify-center p-4 animate-fadeIn" onClick={closeModal}>
            <div 
                className="bg-[#1a1c23] w-full max-w-md rounded-3xl shadow-2xl flex flex-col max-h-[85vh] border border-slate-700/50 overflow-hidden relative"
                onClick={e => e.stopPropagation()}
            >
                {/* Reuse the standard Chat Info design for consistency */}
                <GroupInfoModal 
                    data={currentUser} 
                    currentUser={currentUser} 
                    onBack={closeModal} 
                    onViewProfile={(u) => openModal(ModalType.Profile, u)}
                    onViewMainProfile={(u) => { closeModal(); openModal(ModalType.Profile, u); }}
                />
            </div>
        </div>
    );
};

export default GroupProfileModal;
