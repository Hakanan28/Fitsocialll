
import React, { useEffect, useRef, useState } from 'react';
import { GearItem, NFT, ModalType, Review, CartItem } from '../../types';
import { allUsers } from '../../data/users';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { initialNftData } from '../../data/nfts';

interface ProductDetailModalProps {
    closeModal: () => void;
    item: GearItem | NFT;
    openModal: (modal: ModalType, data?: any) => void;
    isPreview?: boolean;
    customDesign?: { background?: string; themeColor?: string; fontStyle?: string } | null;
    customLayout?: any;
    onAddToCart?: (item: GearItem, quantity: number, variant?: string) => void;
    onReviewSubmit?: (itemId: string, review: Review) => void;
}

const CountdownTimer = () => {
    const calculateTimeLeft = () => {
        const difference = +new Date("2025-10-26T23:59:59") - +new Date();
        let timeLeft: { [key: string]: number } = {};
        if (difference > 0) {
            timeLeft = {
                hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
                minutes: Math.floor((difference / 1000 / 60) % 60),
                seconds: Math.floor((difference / 1000) % 60)
            };
        }
        return timeLeft;
    };

    const [timeLeft, setTimeLeft] = useState(calculateTimeLeft());
    useEffect(() => {
        const timer = setTimeout(() => { setTimeLeft(calculateTimeLeft()); }, 1000);
        return () => clearTimeout(timer);
    });

    return (
        <span className="text-2xl font-black text-white tracking-wider">
            {String(timeLeft.hours).padStart(2, '0')}:
            {String(timeLeft.minutes).padStart(2, '0')}:
            {String(timeLeft.seconds).padStart(2, '0')}
        </span>
    );
}

const ProductDetailModal: React.FC<ProductDetailModalProps> = ({ closeModal, item, openModal, isPreview = false, onAddToCart, onReviewSubmit }) => {
    // Gear State
    const [selectedImage, setSelectedImage] = useState(0);
    const [quantity, setQuantity] = useState(1);
    const [selectedVariant, setSelectedVariant] = useState<string>('Default');
    const [activeTab, setActiveTab] = useState<'desc' | 'specs' | 'reviews'>('desc');
    const [expandedSection, setExpandedSection] = useState<string | null>(null); // For Mobile Accordion
    
    // Review State
    const [reviewRating, setReviewRating] = useState(5);
    const [reviewText, setReviewText] = useState('');
    const [reviewMedia, setReviewMedia] = useState<string[]>([]);
    const [filterRating, setFilterRating] = useState<number | 'all'>('all');
    const mediaInputRef = useRef<HTMLInputElement>(null);

    // NFT State
    const chartRef = useRef<HTMLCanvasElement>(null);
    const chartInstance = useRef<any>(null);
    const canvasRef = useRef<HTMLDivElement>(null);

    if (!item) return null;

    const isGear = 'category' in item && item.category !== undefined;

    // --- GEAR (PHYSICAL PRODUCT) VIEW ---
    if (isGear) {
        const gearItem = item as GearItem;
        const mockImages = [gearItem.image, 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&w=600&q=80', 'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&w=600&q=80'];
        
        // Calculate Review Stats
        const allReviews = gearItem.reviews || [];
        const totalReviews = allReviews.length;
        const averageRating = totalReviews > 0 ? allReviews.reduce((acc, r) => acc + r.rating, 0) / totalReviews : 0;
        
        const ratingCounts = [5, 4, 3, 2, 1].map(stars => ({
            stars,
            count: allReviews.filter(r => r.rating === stars).length,
            percent: totalReviews > 0 ? (allReviews.filter(r => r.rating === stars).length / totalReviews) * 100 : 0
        }));

        const displayedReviews = filterRating === 'all' ? allReviews : allReviews.filter(r => r.rating === filterRating);

        const discount = 15;
        const oldPrice = gearItem.price * 1.15;
        const variants = ["S", "M", "L", "XL"];
        const colors = ["#1F2937", "#DC2626", "#2563EB"];
        
        const toggleAccordion = (section: string) => {
            setExpandedSection(expandedSection === section ? null : section);
        };

        const handleAddToCartAction = () => {
            if (onAddToCart) {
                onAddToCart(gearItem, quantity, selectedVariant);
                // Optional: closeModal();
            }
        };

        const handleSubmitReview = () => {
            if (onReviewSubmit && reviewText.trim()) {
                const newReview: Review = {
                    id: Date.now(),
                    user: 'You', // Current user name
                    rating: reviewRating,
                    comment: reviewText,
                    timestamp: Date.now(),
                    date: new Date().toLocaleDateString(),
                    avatarImage: 'https://placehold.co/100x100/10B981/FFFFFF?text=ME', // Placeholder for current user avatar
                    title: 'Verified Purchase',
                    images: reviewMedia
                };
                onReviewSubmit(gearItem.id, newReview);
                setReviewText('');
                setReviewMedia([]);
                setReviewRating(5);
                alert('Review submitted!');
            }
        };

        const handleReviewMediaUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
            if (e.target.files && e.target.files[0]) {
                const file = e.target.files[0];
                const reader = new FileReader();
                reader.onloadend = () => {
                    setReviewMedia(prev => [...prev, reader.result as string]);
                };
                reader.readAsDataURL(file);
            }
        };

        return (
            <div className={`fixed inset-0 bg-[#0F1115] z-[300] animate-fadeIn font-sans overflow-y-auto ${isPreview ? 'relative' : ''}`}>
                
                {/* --- MOBILE HEADER (Sticky) --- */}
                <div className="md:hidden sticky top-0 z-50 bg-[#0F1115]/95 backdrop-blur-md border-b border-white/5 px-4 py-3 flex justify-between items-center">
                    <button onClick={closeModal} className="p-2 -ml-2 text-white hover:bg-white/10 rounded-full">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                    </button>
                    <div className="flex gap-3">
                        <button className="p-2 text-white hover:bg-white/10 rounded-full"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg></button>
                        <button className="p-2 text-white hover:bg-white/10 rounded-full"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg></button>
                    </div>
                </div>

                {/* --- DESKTOP HEADER --- */}
                <header className="hidden md:flex justify-between items-center px-8 py-4 border-b border-white/10 bg-[#0F1115] sticky top-0 z-50">
                    <div className="flex items-center gap-2 text-gray-400 text-sm">
                        <span className="hover:text-white cursor-pointer">Market</span>
                        <span>/</span>
                        <span className="hover:text-white cursor-pointer">{gearItem.category}</span>
                        <span>/</span>
                        <span className="text-white font-semibold truncate max-w-[200px]">{gearItem.title}</span>
                    </div>
                    <button onClick={closeModal} className="text-gray-400 hover:text-white text-2xl">&times;</button>
                </header>

                <div className="max-w-[1400px] mx-auto md:p-8 pb-32 md:pb-10">
                    <div className="flex flex-col md:flex-row gap-8">
                        
                        {/* --- LEFT COLUMN: IMAGES --- */}
                        <div className="w-full md:w-[45%] flex flex-col md:flex-row gap-4">
                            {/* Desktop Vertical Thumbs */}
                            <div className="hidden md:flex flex-col gap-3 order-1 md:order-1">
                                {mockImages.map((img, idx) => (
                                    <div 
                                        key={idx} 
                                        onMouseEnter={() => setSelectedImage(idx)}
                                        className={`w-16 h-16 rounded-lg border-2 cursor-pointer overflow-hidden transition-all ${selectedImage === idx ? 'border-orange-500 shadow-[0_0_10px_rgba(249,115,22,0.3)]' : 'border-gray-700 hover:border-gray-500'}`}
                                    >
                                        <img src={img} className="w-full h-full object-cover" alt="" />
                                    </div>
                                ))}
                            </div>
                            
                            {/* Main Image Area */}
                            <div className="relative w-full aspect-square md:aspect-auto md:h-[600px] bg-white rounded-none md:rounded-2xl overflow-hidden order-2 md:order-2 group">
                                {/* Mobile Carousel */}
                                <div className="flex md:hidden w-full h-full overflow-x-auto snap-x snap-mandatory scrollbar-hide">
                                    {mockImages.map((img, idx) => (
                                        <img key={idx} src={img} className="w-full h-full flex-shrink-0 object-cover snap-center" alt="" />
                                    ))}
                                </div>
                                {/* Desktop Zoom Image */}
                                <img src={mockImages[selectedImage]} className="hidden md:block w-full h-full object-contain p-4 group-hover:scale-110 transition-transform duration-500" alt={gearItem.title} />
                                
                                <div className="absolute top-4 left-4 bg-red-600 text-white text-xs font-bold px-3 py-1 rounded-md shadow-lg">-{discount}%</div>
                                
                                {/* Mobile Dots */}
                                <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2 md:hidden">
                                    {mockImages.map((_, idx) => (
                                        <div key={idx} className={`w-2 h-2 rounded-full shadow-sm ${idx === 0 ? 'bg-white' : 'bg-white/50'}`}></div>
                                    ))}
                                </div>
                            </div>
                        </div>

                        {/* --- MIDDLE COLUMN: DETAILS --- */}
                        <div className="w-full md:w-[35%] px-4 md:px-0 space-y-5">
                            <div>
                                <h1 className="text-2xl md:text-3xl font-bold text-white leading-tight">{gearItem.title}</h1>
                                <div className="flex items-center gap-2 mt-2">
                                    <div className="flex text-yellow-400 text-sm">
                                        {[1,2,3,4,5].map(i => <span key={i}>{i <= Math.round(averageRating) ? '★' : '☆'}</span>)}
                                    </div>
                                    <span className="text-blue-400 text-sm hover:underline cursor-pointer font-medium">{totalReviews} ratings</span>
                                    <span className="text-gray-600">|</span>
                                    <span className="text-gray-400 text-sm">1k+ bought in past month</span>
                                </div>
                            </div>

                            <div className="border-t border-b border-white/5 py-4">
                                <div className="flex items-baseline gap-3">
                                    <span className="text-3xl font-light text-red-500">-{discount}%</span>
                                    <span className="text-4xl font-bold text-white">{gearItem.currency}{gearItem.price.toFixed(2)}</span>
                                </div>
                                <p className="text-gray-500 text-sm mt-1">List Price: <span className="line-through">{gearItem.currency}{oldPrice.toFixed(2)}</span></p>
                            </div>

                            {/* Variants */}
                            <div className="space-y-4">
                                <div>
                                    <p className="text-sm text-gray-400 font-bold mb-2 uppercase tracking-wide">Color: <span className="text-white">Midnight Black</span></p>
                                    <div className="flex gap-3">
                                        {colors.map((c, i) => (
                                            <button key={i} className={`w-10 h-10 rounded-full border-2 flex items-center justify-center ${i===0 ? 'border-orange-500 ring-2 ring-orange-500/30' : 'border-transparent hover:border-gray-500'}`} style={{backgroundColor: c}}>
                                                {i===0 && <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3"><path d="M20 6L9 17l-5-5"/></svg>}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                                <div>
                                    <p className="text-sm text-gray-400 font-bold mb-2 uppercase tracking-wide">Size</p>
                                    <div className="flex flex-wrap gap-2">
                                        {variants.map((s, i) => (
                                            <button key={i} onClick={() => setSelectedVariant(s)} className={`px-4 py-2 rounded-lg border font-bold text-sm transition-all ${selectedVariant === s ? 'bg-orange-100 border-orange-500 text-orange-700' : 'bg-[#1a1d24] border-gray-700 text-gray-300 hover:border-gray-500'}`}>
                                                {s}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            </div>

                            {/* Key Features (Bullets) */}
                            <div className="space-y-2">
                                <h4 className="text-sm font-bold text-white">About this item</h4>
                                <ul className="list-disc list-inside text-sm text-gray-300 space-y-1 marker:text-gray-500">
                                    <li>Professional grade quality materials for maximum durability.</li>
                                    <li>Designed for high-performance athletes and casual users alike.</li>
                                    <li>Lightweight composite construction with reinforced stitching.</li>
                                    <li>Includes 2-year manufacturer warranty and support.</li>
                                </ul>
                            </div>
                            
                            {/* Mobile Accordions for Details */}
                            <div className="md:hidden space-y-2 border-t border-white/5 pt-4">
                                {['Description', 'Specifications'].map((section) => (
                                    <div key={section} className="border-b border-white/5">
                                        <button onClick={() => toggleAccordion(section)} className="w-full py-3 flex justify-between items-center text-white font-bold text-sm">
                                            {section}
                                            <svg className={`w-5 h-5 transition-transform ${expandedSection === section ? 'rotate-180' : ''}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M6 9l6 6 6-6"/></svg>
                                        </button>
                                        {expandedSection === section && (
                                            <div className="pb-4 text-sm text-gray-400 animate-fadeIn">
                                                {section === 'Description' && gearItem.description}
                                                {section === 'Specifications' && (
                                                    <div className="space-y-1">
                                                        {gearItem.specs?.map((s,i) => <div key={i} className="flex justify-between"><span className="text-gray-500">{s.key}</span><span className="text-white">{s.value}</span></div>)}
                                                    </div>
                                                )}
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* --- RIGHT COLUMN: BUY BOX (Desktop Sticky) --- */}
                        <div className="hidden md:block w-[20%]">
                            <div className="border border-gray-700 bg-[#15171E] p-5 rounded-xl shadow-xl sticky top-24">
                                <div className="text-3xl font-bold text-white mb-2">{gearItem.currency}{gearItem.price.toFixed(2)}</div>
                                <div className="text-sm text-gray-400 mb-4">
                                    <span className="text-blue-400">Free Returns</span>
                                    <span className="mx-2">•</span>
                                    <span className="text-blue-400">Free Delivery</span>
                                </div>
                                <div className="text-sm font-bold text-green-500 mb-4">In Stock</div>
                                
                                <div className="flex items-center justify-between bg-[#0F1115] border border-gray-700 rounded-lg p-1 mb-4">
                                    <button onClick={() => setQuantity(Math.max(1, quantity-1))} className="w-8 h-8 flex items-center justify-center text-gray-400 hover:bg-gray-700 rounded">-</button>
                                    <span className="text-white font-bold">{quantity}</span>
                                    <button onClick={() => setQuantity(quantity+1)} className="w-8 h-8 flex items-center justify-center text-gray-400 hover:bg-gray-700 rounded">+</button>
                                </div>

                                <div className="space-y-3">
                                    <button onClick={handleAddToCartAction} className="w-full bg-yellow-400 hover:bg-yellow-500 text-black font-bold py-3 rounded-full shadow-lg transition-transform active:scale-95">
                                        Add to Cart
                                    </button>
                                    <button className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 rounded-full shadow-lg transition-transform active:scale-95">
                                        Buy Now
                                    </button>
                                </div>

                                <div className="mt-6 text-xs text-gray-400 space-y-2">
                                    <div className="flex justify-between"><span>Ships from</span><span className="text-white">FitSocial</span></div>
                                    <div className="flex justify-between"><span>Sold by</span><span className="text-blue-400 cursor-pointer hover:underline">{gearItem.seller.username}</span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    {/* Desktop Tabs Section (Details + Reviews) */}
                    <div className="mt-12">
                        <div className="border-b border-gray-700 flex gap-8 overflow-x-auto">
                            {['desc', 'specs', 'reviews'].map((t) => (
                                <button 
                                    key={t}
                                    onClick={() => setActiveTab(t as any)}
                                    className={`pb-4 text-sm font-bold uppercase tracking-wide transition-colors border-b-2 whitespace-nowrap ${activeTab === t ? 'border-orange-500 text-orange-500' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
                                >
                                    {t === 'desc' ? 'Description' : t === 'specs' ? 'Specifications' : 'Customer Reviews'}
                                </button>
                            ))}
                        </div>
                        <div className="py-8 animate-fadeIn min-h-[300px]">
                            {activeTab === 'desc' && (
                                <div className="text-gray-300 leading-relaxed max-w-4xl">
                                    <p className="mb-4">{gearItem.description}</p>
                                    <p>Experience elite performance with the new series. Engineered for durability and comfort, it stands up to the toughest workouts. The ergonomic design ensures optimal usability, while premium materials provide a sleek aesthetic.</p>
                                </div>
                            )}
                            {activeTab === 'specs' && (
                                <div className="max-w-2xl">
                                    <table className="w-full text-sm text-left text-gray-400">
                                        <tbody>
                                            {gearItem.specs?.map((s, i) => (
                                                <tr key={i} className="border-b border-gray-800">
                                                    <th className="py-3 font-medium text-gray-200 bg-[#15171E] px-4 w-1/3">{s.key}</th>
                                                    <td className="py-3 px-4">{s.value}</td>
                                                </tr>
                                            ))}
                                            <tr className="border-b border-gray-800"><th className="py-3 font-medium text-gray-200 bg-[#15171E] px-4">Weight</th><td className="py-3 px-4">{gearItem.logistics?.weight}</td></tr>
                                            <tr className="border-b border-gray-800"><th className="py-3 font-medium text-gray-200 bg-[#15171E] px-4">Dimensions</th><td className="py-3 px-4">{gearItem.logistics?.dimensions}</td></tr>
                                        </tbody>
                                    </table>
                                </div>
                            )}
                            
                            {/* --- REVIEWS SECTION --- */}
                            {activeTab === 'reviews' && (
                                <div className="flex flex-col md:flex-row gap-8">
                                    {/* Reviews Summary Side */}
                                    <div className="md:w-1/3 space-y-6">
                                        <h3 className="text-xl font-bold text-white">Customer Reviews</h3>
                                        <div className="flex items-center gap-4">
                                            <div className="flex text-yellow-400 text-xl">
                                                 {[1,2,3,4,5].map(i => <span key={i}>{i <= Math.round(averageRating) ? '★' : '☆'}</span>)}
                                            </div>
                                            <span className="text-white font-bold text-lg">{averageRating.toFixed(1)} out of 5</span>
                                        </div>
                                        <p className="text-gray-400 text-sm">{totalReviews} global ratings</p>
                                        
                                        {/* Rating Distribution Bars */}
                                        <div className="space-y-2">
                                            {ratingCounts.map((stat) => (
                                                <button 
                                                    key={stat.stars} 
                                                    onClick={() => setFilterRating(filterRating === stat.stars ? 'all' : stat.stars)}
                                                    className={`w-full flex items-center gap-3 text-xs group ${filterRating === stat.stars ? 'opacity-100' : filterRating === 'all' ? 'opacity-100' : 'opacity-50'}`}
                                                >
                                                    <span className="w-12 text-white font-medium whitespace-nowrap hover:underline">{stat.stars} star</span>
                                                    <div className="flex-1 h-3 bg-gray-700 rounded-full overflow-hidden">
                                                        <div 
                                                            className={`h-full transition-all duration-500 ${filterRating === stat.stars ? 'bg-orange-400' : 'bg-yellow-400 group-hover:bg-orange-400'}`} 
                                                            style={{width: `${stat.percent}%`}}
                                                        ></div>
                                                    </div>
                                                    <span className="w-8 text-right text-gray-400">{Math.round(stat.percent)}%</span>
                                                </button>
                                            ))}
                                        </div>
                                        
                                        {/* Write a Review Block */}
                                        <div className="bg-[#15171E] p-4 rounded-xl border border-gray-700 mt-6">
                                            <h4 className="text-white font-bold mb-2">Write a Review</h4>
                                            <div className="flex gap-1 text-2xl mb-3 text-gray-600">
                                                {[1,2,3,4,5].map(star => (
                                                    <button key={star} onClick={() => setReviewRating(star)} className={`hover:scale-110 transition-transform ${star <= reviewRating ? 'text-yellow-400' : ''}`}>★</button>
                                                ))}
                                            </div>
                                            <textarea 
                                                value={reviewText}
                                                onChange={(e) => setReviewText(e.target.value)}
                                                className="w-full bg-black border border-gray-700 rounded-lg p-2 text-sm text-white focus:border-orange-500 outline-none mb-2"
                                                placeholder="Share your thoughts..."
                                                rows={3}
                                            />
                                            
                                            {/* Media Upload */}
                                            <div className="flex items-center justify-between">
                                                <div className="flex items-center gap-2">
                                                    <button onClick={() => mediaInputRef.current?.click()} className="text-gray-400 hover:text-white flex items-center gap-1 text-xs bg-gray-800 px-2 py-1 rounded border border-gray-700">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M20.4 14.5L16 10 4 20"/></svg>
                                                        Add Photo
                                                    </button>
                                                    {reviewMedia.length > 0 && <span className="text-xs text-green-400">{reviewMedia.length} added</span>}
                                                </div>
                                                <button onClick={handleSubmitReview} disabled={!reviewText.trim()} className="bg-orange-600 text-white text-xs font-bold px-4 py-2 rounded-lg hover:bg-orange-500 disabled:opacity-50 disabled:cursor-not-allowed">Submit</button>
                                            </div>
                                            <input type="file" ref={mediaInputRef} onChange={handleReviewMediaUpload} accept="image/*" className="hidden" />
                                        </div>
                                    </div>

                                    {/* Reviews Feed Side */}
                                    <div className="md:w-2/3 space-y-6">
                                        <div className="flex justify-between items-center">
                                            <h4 className="text-white font-bold">{displayedReviews.length} Reviews</h4>
                                            {filterRating !== 'all' && (
                                                <button onClick={() => setFilterRating('all')} className="text-xs text-blue-400 hover:text-white">Clear Filter</button>
                                            )}
                                        </div>
                                        
                                        {displayedReviews.length === 0 ? (
                                            <div className="text-center py-12 text-gray-500 border border-dashed border-gray-700 rounded-xl">
                                                No reviews match your filter.
                                            </div>
                                        ) : (
                                            displayedReviews.map(r => (
                                                <div key={r.id} className="border-b border-gray-800 pb-6 animate-fadeIn">
                                                    <div className="flex items-center gap-2 mb-2">
                                                        <img src={r.avatarImage || "https://placehold.co/100x100/333/FFF?text=U"} className="w-8 h-8 rounded-full border border-gray-700" alt={r.user}/>
                                                        <span className="text-sm font-bold text-white">{r.user}</span>
                                                        <span className="text-xs text-gray-500 ml-auto">{new Date(r.timestamp).toLocaleDateString()}</span>
                                                    </div>
                                                    <div className="flex items-center gap-2 mb-2">
                                                        <div className="flex text-yellow-400 text-xs">
                                                            {[1,2,3,4,5].map(i => <span key={i}>{i <= r.rating ? '★' : '☆'}</span>)}
                                                        </div>
                                                        {r.title && <span className="text-white font-bold text-sm">{r.title}</span>}
                                                        <span className="text-[10px] text-green-400 font-bold px-1.5 py-0.5 bg-green-900/30 rounded border border-green-500/30">Verified Purchase</span>
                                                    </div>
                                                    <p className="text-sm text-gray-300 mb-3 leading-relaxed">{r.comment}</p>
                                                    {r.images && r.images.length > 0 && (
                                                        <div className="flex gap-2 overflow-x-auto pb-2">
                                                            {r.images.map((img, idx) => (
                                                                <img key={idx} src={img} className="w-20 h-20 object-cover rounded-lg border border-gray-700 cursor-pointer hover:border-white transition-colors" alt="Review attachment" />
                                                            ))}
                                                        </div>
                                                    )}
                                                    <div className="flex items-center gap-4 mt-2">
                                                        <button className="text-xs text-gray-500 hover:text-white flex items-center gap-1">Helpful</button>
                                                        <button className="text-xs text-gray-500 hover:text-white">Report</button>
                                                    </div>
                                                </div>
                                            ))
                                        )}
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                {/* --- MOBILE STICKY FOOTER --- */}
                <div className="md:hidden fixed bottom-0 left-0 right-0 bg-[#15171E] border-t border-white/10 p-3 px-4 flex items-center gap-3 pb-safe z-50 shadow-2xl">
                     <div className="flex flex-col">
                         <span className="text-xs text-gray-400 font-bold uppercase">Total</span>
                         <span className="text-xl font-bold text-white">{gearItem.currency}{(gearItem.price * quantity).toFixed(2)}</span>
                     </div>
                     <div className="flex items-center bg-gray-800 rounded-lg border border-gray-600 h-10">
                         <button onClick={() => setQuantity(Math.max(1, quantity-1))} className="w-8 h-full text-gray-300 font-bold text-lg">-</button>
                         <span className="w-6 text-center text-white font-bold text-sm">{quantity}</span>
                         <button onClick={() => setQuantity(quantity+1)} className="w-8 h-full text-gray-300 font-bold text-lg">+</button>
                     </div>
                     <button onClick={handleAddToCartAction} className="flex-1 bg-gradient-to-r from-yellow-500 to-orange-600 text-white font-bold h-12 rounded-xl shadow-lg active:scale-95 transition-transform text-sm uppercase tracking-wide">
                         Add to Cart
                     </button>
                </div>
            </div>
        );
    }
    
    // --- NFT (Digital) Detail View ---
    const nftItem = item as NFT;

    useEffect(() => {
        if (!canvasRef.current || !nftItem.imageUrl) return;

        // --- Three.js Setup ---
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
        const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
        renderer.setSize(canvasRef.current.clientWidth, canvasRef.current.clientHeight);
        canvasRef.current.appendChild(renderer.domElement);

        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableZoom = false;
        controls.enablePan = false;

        const textureLoader = new THREE.TextureLoader();
        textureLoader.setCrossOrigin(''); // Handle CORS for imgur links
        
        const texture = textureLoader.load(
            nftItem.imageUrl,
            () => { // onLoad
                const aspectRatio = texture.image ? texture.image.width / texture.image.height : 1;
                const geometry = new THREE.PlaneGeometry(5, 5 / aspectRatio);
                const material = new THREE.MeshBasicMaterial({ map: texture, side: THREE.DoubleSide });
                const plane = new THREE.Mesh(geometry, material);
                scene.add(plane);
                renderer.render(scene, camera); // Initial render
            },
            undefined, // onProgress
            (error) => { // onError
                console.error('An error happened loading the texture:', error);
            }
        );

        camera.position.z = 5;

        const animate = function () {
            requestAnimationFrame(animate);
            controls.update();
            renderer.render(scene, camera);
        };

        animate();

        // Handle resize
        const handleResize = () => {
            if (canvasRef.current) {
                renderer.setSize(canvasRef.current.clientWidth, canvasRef.current.clientHeight);
                camera.aspect = 1;
                camera.updateProjectionMatrix();
            }
        };
        window.addEventListener('resize', handleResize);

        // Cleanup
        return () => {
            window.removeEventListener('resize', handleResize);
            if (canvasRef.current) {
                canvasRef.current.removeChild(renderer.domElement);
            }
            renderer.dispose();
        };

    }, [nftItem.imageUrl]);

    const priceHistory = nftItem.priceHistory.length > 0 ? nftItem.priceHistory : [
        { time: 'TYPE', value: 18 }, { time: 'SX3D', value: 25 }, { time: 'S2180', value: 15 },
        { time: 'G3T.94', value: 22 }, { time: '6D.94', value: 20 }, { time: '1D3310', value: 24 },
    ];

    useEffect(() => {
        if (chartRef.current) {
            if (chartInstance.current) {
                chartInstance.current.destroy();
            }

            const ctx = chartRef.current.getContext('2d');
            if (ctx) {
                const gradient = ctx.createLinearGradient(0, 0, 0, 200);
                gradient.addColorStop(0, 'rgba(139, 92, 246, 0.4)');
                gradient.addColorStop(1, 'rgba(139, 92, 246, 0)');
                
                chartInstance.current = new (window as any).Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: priceHistory.map(p => p.time),
                        datasets: [{
                            data: priceHistory.map(p => p.value),
                            borderColor: '#a78bfa',
                            backgroundColor: gradient,
                            borderWidth: 2,
                            pointRadius: 0,
                            tension: 0.4,
                            fill: true,
                        }]
                    },
                    options: {
                         responsive: true, maintainAspectRatio: false,
                         scales: {
                            y: { display: false, min: 10, max: 30 },
                            x: { 
                                ticks: { color: '#6B7280', font: { size: 10, weight: 'bold' } }, 
                                grid: { color: 'rgba(55, 65, 81, 0.3)', drawBorder: false },
                                border: { display: false }
                            }
                         },
                         plugins: { 
                            legend: { display: false }, 
                            tooltip: { 
                                enabled: true,
                                backgroundColor: '#111827',
                                titleColor: '#fff',
                                bodyColor: '#a78bfa',
                                displayColors: false,
                            } 
                        }
                    }
                });
            }
        }
    }, [nftItem]);
    
    const rootClassName = isPreview
        ? "relative w-full h-full bg-[#0B0C10] font-sans overflow-y-auto"
        : "fixed inset-0 bg-[#0B0C10] z-[300] animate-fadeIn font-sans overflow-y-auto";

    return (
        <div className={rootClassName}>
            {/* Background Grid */}
            <div className="absolute inset-0 z-[-1] overflow-hidden">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_90%_20%,_rgba(139,92,246,0.1)_0%,_transparent_40%)]"></div>
                <div 
                    className="absolute bottom-0 left-0 w-full h-1/2"
                    style={{
                        background: 'linear-gradient(transparent, #0B0C10 80%), radial-gradient(ellipse 80% 50% at 50% 100%, rgba(139, 92, 246, 0.15), transparent)',
                    }}
                ></div>
                <div 
                    className="absolute inset-0 bg-[length:60px_60px]"
                    style={{ backgroundImage: 'linear-gradient(to right, rgba(255,255,255,0.02) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.02) 1px, transparent 1px)' }}
                ></div>
            </div>

            <header className="flex justify-between items-center px-8 py-4 border-b border-white/5 sticky top-0 bg-[#0B0C10]/80 backdrop-blur-xl z-20">
                <div className="flex items-center gap-4">
                    <button onClick={closeModal} className="text-gray-400 hover:text-white transition-colors p-2 rounded-full hover:bg-white/10">
                         <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                    </button>
                    <div className="flex items-center gap-2">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M6.5 12L12 6.5L17.5 12L12 17.5L6.5 12Z" stroke="#38BDF8" strokeWidth="2" strokeLinejoin="round"/>
                            <path d="M12 17.5L17.5 23L23 17.5L17.5 12L12 17.5Z" fill="#818CF8"/>
                        </svg>
                        <h2 className="text-xl font-bold text-white">CRYPTOMINT</h2>
                    </div>
                </div>
                {!isPreview && (
                    <>
                        <div className="hidden lg:flex items-center gap-6 text-sm font-semibold text-gray-400">
                            <a href="#" className="hover:text-white transition-colors">Explore</a>
                            <a href="#" className="hover:text-white transition-colors">Market</a>
                            <a href="#" className="hover:text-white transition-colors">Create</a>
                        </div>
                        <div className="flex items-center gap-4">
                            <button className="bg-[#1F2129] border border-gray-700 text-white font-semibold py-2 px-5 rounded-full hover:bg-gray-800 transition-colors text-sm">
                                Connect Wallet
                            </button>
                            <button className="text-gray-400 hover:text-white transition-colors">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                            </button>
                        </div>
                    </>
                )}
            </header>

            <main className="w-full max-w-7xl mx-auto px-8 py-10 space-y-12">
                <div className="lg:grid lg:grid-cols-10 lg:gap-12 lg:items-start">
                    {/* Left Column */}
                    <section className="lg:col-span-4 relative">
                        <div className="absolute -inset-2 bg-gradient-to-br from-purple-600/30 to-blue-600/30 blur-xl opacity-40 rounded-3xl"></div>
                        <div className="relative bg-[#15171e]/80 p-5 rounded-2xl border border-white/10 backdrop-blur-md shadow-2xl">
                            <div ref={canvasRef} className="aspect-square rounded-xl overflow-hidden bg-black mb-5 cursor-grab active:cursor-grabbing">
                                {/* 3D Canvas will be mounted here */}
                            </div>
                            {!isPreview && (
                                <div className="flex items-center gap-4">
                                    <button className="flex-1 bg-gradient-to-r from-blue-500 to-purple-500 text-white font-bold py-3 rounded-xl hover:opacity-90 transition-opacity shadow-lg">
                                        BUY NOW
                                    </button>
                                    <button className="p-3 rounded-full bg-gray-800 text-gray-400 hover:text-white transition-colors border border-gray-700">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>
                                    </button>
                                     <button onClick={() => openModal(ModalType.SharePost, { content: nftItem })} className="p-3 rounded-full bg-gray-800 text-gray-400 hover:text-white transition-colors border border-gray-700">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="22" x2="11" y1="2" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                                    </button>
                                </div>
                            )}
                        </div>
                    </section>
                    
                    {/* Right Column */}
                    <section className="lg:col-span-6 space-y-8 mt-12 lg:mt-0">
                         <div>
                            <h1 className="text-4xl lg:text-5xl font-black text-white">{nftItem.name}</h1>
                            <p className="text-lg text-slate-400 mt-2">by <span className="text-cyan-400 font-semibold cursor-pointer">@{nftItem.owner.username}</span></p>
                            <p className="text-md text-slate-500 mt-1">OWNER: <span className="text-slate-400 font-semibold cursor-pointer">@cryptkiner</span></p>
                         </div>

                         <div className="flex items-center justify-between">
                             <div>
                                <p className="text-5xl lg:text-6xl font-black text-white">{nftItem.price} <span className="text-4xl text-gray-400">ETH</span></p>
                                <p className="text-sm text-slate-400 mt-2">BEST OFFER {nftItem.bestOffer} ETH</p>
                             </div>
                             {!isPreview && (
                                <button className="bg-gradient-to-r from-blue-500 to-purple-600 text-white font-bold py-4 px-10 rounded-xl hover:opacity-90 transition-opacity shadow-lg shadow-purple-500/20">
                                    MAKE OFFER
                                </button>
                             )}
                         </div>

                         <div className="grid grid-cols-2 gap-4">
                             <div className="bg-[#15171e]/80 p-4 rounded-xl border border-white/10">
                                 <p className="text-[10px] text-gray-400 uppercase font-bold tracking-wider mb-1">Auction Ends In:</p>
                                 <CountdownTimer />
                             </div>
                             <div className="bg-[#15171e]/80 p-4 rounded-xl border border-white/10">
                                 <p className="text-[10px] text-gray-400 uppercase font-bold tracking-wider mb-1">Reserve Price:</p>
                                 <p className="text-2xl font-black text-white">6.0 ETH</p>
                             </div>
                         </div>

                         <div className="grid grid-cols-2 gap-4">
                             <div className="bg-[#15171e]/80 p-4 rounded-xl border border-white/10">
                                 <p className="text-[10px] text-cyan-400 uppercase font-bold tracking-wider mb-2">NEURAL LINK (AI CHAT)</p>
                                 <div className="text-xs space-y-1">
                                    <p><span className="text-blue-400">User:</span> <span className="text-gray-300">What is your origin?</span></p>
                                    <p><span className="text-green-400">AI:</span> <span className="text-gray-300">I am forged from digital fire and code...</span></p>
                                 </div>
                                  <button className="w-full text-right mt-1 text-cyan-400 opacity-50 hover:opacity-100">></button>
                             </div>
                             <div className="bg-[#15171e]/80 p-4 rounded-xl border border-white/10">
                                 <p className="text-[10px] text-green-400 uppercase font-bold tracking-wider mb-2">LIVE STAKING CONSOLE</p>
                                 <p className="text-[10px] text-gray-400 uppercase">YIELD:</p>
                                 <p className="text-2xl font-black text-green-400">+0.0124</p>
                                 <p className="text-[10px] text-gray-500">TOKEN/hr</p>
                             </div>
                         </div>
                    </section>
                </div>

                <div className="grid lg:grid-cols-10 gap-12">
                    <section className="lg:col-span-6">
                         <h3 className="font-bold text-white text-xl mb-4">Description</h3>
                         <div className="h-48">
                             <canvas ref={chartRef}></canvas>
                         </div>
                    </section>
                    <section className="lg:col-span-4">
                        <h3 className="font-bold text-white text-xl mb-4">Recent Bids</h3>
                        <div className="space-y-2">
                            {[
                                { user: { username: 'Dragon', avatar: 'https://placehold.co/100x100/A78BFA/FFFFFF?text=D' }, amount: 5.353, currency: 'ETH' },
                                { user: { username: 'Dragon', avatar: 'https://placehold.co/100x100/3B82F6/FFFFFF?text=D' }, amount: 11.453, currency: 'ETH' },
                                { user: { username: 'Legand', avatar: 'https://placehold.co/100x100/10B981/FFFFFF?text=L' }, amount: 5.316, currency: 'ETH' },
                            ].map((bid, i) => (
                                <div key={i} className="flex items-center justify-between p-3 bg-[#15171e]/50 border border-gray-800 rounded-lg">
                                    <div className="flex items-center gap-3">
                                        <img src={bid.user.avatar} alt={bid.user.username} className="w-8 h-8 rounded-full" />
                                        <span className="font-semibold text-sm text-white">{bid.user.username}</span>
                                    </div>
                                    <span className="font-mono text-sm text-cyan-400">{bid.amount} {bid.currency}</span>
                                </div>
                            ))}
                        </div>
                    </section>
                </div>

                <section>
                    <h3 className="font-bold text-white text-xl mb-4">New Arrivals</h3>
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 gap-6">
                        {[
                            {...initialNftData[3], price: 5.50, owner: {username: '@digitaldreamer'}}, 
                            {...initialNftData[4], price: 2.5, currency: 'ETH'},
                            {...initialNftData[1], price: 5.8, currency: 'ETH'}
                        ].map(nft => (
                            <div key={nft.id} onClick={() => !isPreview && openModal(ModalType.ProductDetail, nft)} className="bg-[#15171e] rounded-2xl overflow-hidden border border-gray-800 cursor-pointer group shadow-lg transition-all hover:-translate-y-1 hover:shadow-purple-900/20">
                                <img src={nft.imageUrl} className="w-full aspect-square object-cover transition-transform group-hover:scale-105"/>
                                <div className="p-4">
                                    <p className="text-xs text-slate-400 truncate">{(nft.owner as any).username}</p>
                                    <p className="text-sm font-bold text-white mt-1">{nft.price} {nft.currency}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </section>

                <section>
                    <h3 className="font-bold text-white text-xl mb-4">Top Creators</h3>
                    <div className="space-y-3">
                        {[allUsers[3], allUsers[1]].map((user, i) => (
                            <div key={user.username} className="flex items-center justify-between p-3 bg-[#15171e]/50 border border-gray-800 rounded-lg">
                                <div className="flex items-center gap-3">
                                    <img src={user.avatarImage} alt={user.username} className="w-10 h-10 rounded-full" />
                                    <div>
                                        <p className="font-semibold text-sm text-white flex items-center gap-1.5">{user.username} {user.isVerified && <svg width="14" height="14" viewBox="0 0 24 24" fill="#38BDF8"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>}</p>
                                        <p className="text-xs text-gray-400">{(user.followers / 1000).toFixed(1)}K Followers</p>
                                    </div>
                                </div>
                                 {i === 0 && <div className="text-xs font-bold bg-blue-600/20 text-blue-300 border border-blue-500/30 px-2 py-1 rounded-md">Onaylı Yaratıcı</div>}
                            </div>
                        ))}
                    </div>
                </section>
            </main>
             {!isPreview && (
                <footer className="flex justify-between items-center px-8 py-6 border-t border-white/5 mt-8">
                    <div className="flex items-center gap-6 text-sm text-gray-500 font-semibold">
                        <a href="#" className="hover:text-white transition-colors">About Us</a>
                        <a href="#" className="hover:text-white transition-colors">Support</a>
                        <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
                    </div>
                    <div className="flex items-center gap-4">
                        <button onClick={() => openModal(ModalType.SharePost, { content: nftItem })} className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white hover:bg-blue-400 transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                        </button>
                    </div>
                </footer>
            )}
        </div>
    );
};

export default ProductDetailModal;
