import React, { useState, useRef, useEffect } from 'react';
import { Story } from '../../types';
import { useTranslation } from '../../hooks/i18n';
import { FILTERS } from '../../utils/filters';

interface StoryEditorModalProps {
    closeModal: () => void;
    handleCreateStory: (storyData: Omit<Story, 'user' | 'avatarImage'>) => void;
    modalData?: { mediaFile?: File };
}

type TextOverlay = {
    id: string;
    text: string;
    color: string;
    position: { x: number; y: number };
};

type Sticker = {
    id: string;
    type: 'mention' | 'music';
    content: any;
    position: { x: number; y: number };
};


const StoryEditorModal: React.FC<StoryEditorModalProps> = ({ closeModal, handleCreateStory, modalData }) => {
    const { t } = useTranslation();
    const [mediaFile] = useState<File | null>(modalData?.mediaFile || null);
    const [mediaPreview] = useState<string | null>(mediaFile ? URL.createObjectURL(mediaFile) : null);
    const [mediaType] = useState<'image' | 'video'>(mediaFile?.type.startsWith('video') ? 'video' : 'image');
    
    // Editor State
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);
    const [caption, setCaption] = useState('');
    const [currentFilterIndex, setCurrentFilterIndex] = useState(0);
    const [showFilterName, setShowFilterName] = useState(false);
    
    // Interactive Elements
    const [isEditingText, setIsEditingText] = useState(false);
    const [currentText, setCurrentText] = useState('');
    const [textColor, setTextColor] = useState('#FFFFFF');
    const [textOverlays, setTextOverlays] = useState<TextOverlay[]>([]);
    
    const [stickers, setStickers] = useState<Sticker[]>([]);

    // Drawing State
    const [isDrawing, setIsDrawing] = useState(false);
    const [drawColor, setDrawColor] = useState('#FFFFFF');
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const isDrawingRef = useRef(false);

    // Dragging State
    const [draggingElement, setDraggingElement] = useState<{ type: 'text' | 'sticker', id: string } | null>(null);
    const dragOffsetRef = useRef({ x: 0, y: 0 });

    const filterNameTimerRef = useRef<number | null>(null);
    const touchStartRef = useRef(0);
    const containerRef = useRef<HTMLDivElement>(null);
    
    // --- Lifecycle and Handlers ---

    useEffect(() => {
        // CRITICAL FIX: Do NOT revoke the object URL here.
        // The parent component (App.tsx) needs this URL to display the story after creation.
        // The URL should be managed by the parent's state lifecycle.
        return () => {
            if (filterNameTimerRef.current) clearTimeout(filterNameTimerRef.current);
        };
    }, []);

    useEffect(() => {
        if (currentFilterIndex > 0) {
            setShowFilterName(true);
            if (filterNameTimerRef.current) clearTimeout(filterNameTimerRef.current);
            filterNameTimerRef.current = window.setTimeout(() => setShowFilterName(false), 1200);
        } else {
             setShowFilterName(false);
             if (filterNameTimerRef.current) clearTimeout(filterNameTimerRef.current);
        }
    }, [currentFilterIndex]);

    const handleSubmit = () => {
        if (!mediaPreview) return;
        handleCreateStory({
            mediaUrl: mediaPreview,
            mediaType: mediaType,
            filter: FILTERS[currentFilterIndex].filter,
            textOverlays: textOverlays as any, 
        });
        closeModal();
    };
    
    // --- Drawing Logic ---
    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const context = canvas.getContext('2d');
        if (!context) return;
    
        const startDrawing = (e: PointerEvent) => {
            if (!isDrawing) return;
            isDrawingRef.current = true;
            context.beginPath();
            context.moveTo(e.offsetX, e.offsetY);
            context.strokeStyle = drawColor;
            context.lineWidth = 5;
            context.lineCap = 'round';
            context.lineJoin = 'round';
        };
    
        const draw = (e: PointerEvent) => {
            if (!isDrawingRef.current) return;
            context.lineTo(e.offsetX, e.offsetY);
            context.stroke();
        };
    
        const stopDrawing = () => {
            isDrawingRef.current = false;
            context.closePath();
        };
    
        canvas.addEventListener('pointerdown', startDrawing);
        canvas.addEventListener('pointermove', draw);
        canvas.addEventListener('pointerup', stopDrawing);
        canvas.addEventListener('pointerleave', stopDrawing);
    
        return () => {
            canvas.removeEventListener('pointerdown', startDrawing);
            canvas.removeEventListener('pointermove', draw);
            canvas.removeEventListener('pointerup', stopDrawing);
            canvas.removeEventListener('pointerleave', stopDrawing);
        };
    }, [isDrawing, drawColor]);
    
    // --- Dragging Logic ---
    const handleDragStart = (e: React.PointerEvent, type: 'text' | 'sticker', id: string) => {
        e.stopPropagation();
        const target = e.currentTarget as HTMLElement;
        const rect = target.getBoundingClientRect();
        
        dragOffsetRef.current = {
            x: e.clientX - rect.left,
            y: e.clientY - rect.top,
        };
        setDraggingElement({ type, id });
    };

    const handleDragMove = (e: React.PointerEvent) => {
        if (!draggingElement) return;
        e.preventDefault();
        e.stopPropagation();
        
        const containerRect = containerRef.current!.getBoundingClientRect();
        const newX = e.clientX - containerRect.left - dragOffsetRef.current.x;
        const newY = e.clientY - containerRect.top - dragOffsetRef.current.y;

        if (draggingElement.type === 'text') {
            setTextOverlays(prev => prev.map(t => t.id === draggingElement.id ? { ...t, position: { x: newX, y: newY } } : t));
        } else if (draggingElement.type === 'sticker') {
            setStickers(prev => prev.map(s => s.id === draggingElement.id ? { ...s, position: { x: newX, y: newY } } : s));
        }
    };

    const handleDragEnd = () => {
        setDraggingElement(null);
    };
    
    // --- Text Logic ---
    const handleAddText = () => {
        if (currentText.trim()) {
            setTextOverlays(prev => [...prev, {
                id: Date.now().toString(),
                text: currentText,
                color: textColor,
                position: { x: 50, y: 100 }
            }]);
        }
        setIsEditingText(false);
        setCurrentText('');
    };
    
    // --- Music & Mention Logic ---
    const addMention = (username: string) => {
        setStickers(prev => [...prev, {
            id: Date.now().toString(),
            type: 'mention',
            content: username,
            position: { x: 50, y: 150 }
        }]);
    }
    
    const addMusic = (song: string) => {
        setStickers(prev => [...prev, {
            id: Date.now().toString(),
            type: 'music',
            content: song,
            position: { x: 50, y: 200 }
        }]);
    }

    // --- Filter Swipe Logic ---
    const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
        touchStartRef.current = e.touches[0].clientX;
    };

    const handleTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
        if(isDrawing || isEditingText) return;
        const endX = e.changedTouches[0].clientX;
        const deltaX = touchStartRef.current - endX;
        const swipeThreshold = 50; 
        if (Math.abs(deltaX) > swipeThreshold) {
            if (deltaX > 0) setCurrentFilterIndex(prev => (prev + 1) % FILTERS.length);
            else setCurrentFilterIndex(prev => (prev - 1 + FILTERS.length) % FILTERS.length);
        }
    };
    
    // --- UI Render Helpers ---
    const TextIcon = () => <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2"><path d="M7 6V4h10v2M12 4v16"/><path d="M10 20h4"/><path d="M16 9h-1.5a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 1 .5-.5H16"/></svg>;
    const StickerIcon = () => <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2"><path d="M12 2l2.35 7.16L22 9.5l-5.85 4.34L18.65 22 12 17.33 5.35 22l2.5-8.16L2 9.5l7.65-.34z M17 8c-1.5-1.5-4-1-4 1s2.5 2.5 4 1z"/></svg>;
    const MusicIcon = () => <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2"><path d="M9 18V5l12-2v13M9 18a3 3 0 100-6 3 3 0 000 6z M21 16a3 3 0 100-6 3 3 0 000 6z"/></svg>;
    const EffectsIcon = () => <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2"><path d="M12 3L9 9l-6 3 6 3 3 6 3-6 6-3-6-3-3-6z"/><path d="M3 21l3-3"/><path d="M18 21l3-3"/></svg>;
    const DrawIcon = () => <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 3a2.828 2.828 0 114 4L7.5 20.5 2 22l1.5-5.5L17 3z"/></svg>;
    const SaveIcon = () => <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg>;
    
    return (
        <div 
            className="fixed inset-0 bg-black z-[200] flex flex-col items-center justify-center animate-fadeIn"
            onPointerMove={handleDragMove}
            onPointerUp={handleDragEnd}
            onPointerLeave={handleDragEnd}
        >
            <div 
                ref={containerRef}
                className="relative w-full h-full bg-gray-900 overflow-hidden"
                onTouchStart={handleTouchStart}
                onTouchEnd={handleTouchEnd}
            >
                {/* Media and Overlays */}
                <div className="relative w-full h-full flex items-center justify-center">
                    {mediaType === 'video' ? (
                        <video src={mediaPreview} className="w-full h-full object-cover" autoPlay loop muted style={{ filter: FILTERS[currentFilterIndex].filter }} />
                    ) : (
                        <img src={mediaPreview} className="w-full h-full object-cover" alt="story content" style={{ filter: FILTERS[currentFilterIndex].filter }} />
                    )}
                    
                    <canvas ref={canvasRef} width={containerRef.current?.clientWidth || window.innerWidth} height={containerRef.current?.clientHeight || window.innerHeight} className="absolute inset-0 z-10" style={{pointerEvents: isDrawing ? 'auto' : 'none'}}></canvas>
                    
                    {textOverlays.map(t => (
                        <div key={t.id} onPointerDown={(e) => handleDragStart(e, 'text', t.id)} style={{ position: 'absolute', left: t.position.x, top: t.position.y, color: t.color, cursor: 'move', touchAction: 'none' }} className="z-20 p-2 text-2xl font-bold drop-shadow-lg">
                            {t.text}
                        </div>
                    ))}
                    
                    {stickers.map(s => (
                         <div key={s.id} onPointerDown={(e) => handleDragStart(e, 'sticker', s.id)} style={{ position: 'absolute', left: s.position.x, top: s.position.y, cursor: 'move', touchAction: 'none' }} className="z-20 p-2 bg-black/50 rounded-lg text-white font-bold text-sm">
                            {s.type === 'mention' && `@${s.content}`}
                            {s.type === 'music' && `🎵 ${s.content}`}
                        </div>
                    ))}
                </div>

                {/* UI Overlays */}
                {!isEditingText && (
                    <>
                        {showFilterName && <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10"><div className="bg-black/60 backdrop-blur-md px-4 py-2 rounded-lg text-white font-bold animate-fadeIn">{FILTERS[currentFilterIndex].name}</div></div>}
                        
                        <button onClick={closeModal} className="absolute top-4 left-4 bg-black/50 p-2 rounded-full backdrop-blur-sm z-20"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><path d="M18 6L6 18M6 6l12 12"/></svg></button>

                        <div className="absolute top-1/2 right-4 -translate-y-1/2 flex flex-col gap-4 z-20">
                            <button onClick={() => setIsEditingText(true)} className="w-12 h-12 bg-black/50 rounded-full backdrop-blur-sm flex items-center justify-center"><TextIcon/></button>
                            <button onClick={() => setIsDrawerOpen(true)} className="w-12 h-12 bg-black/50 rounded-full backdrop-blur-sm flex items-center justify-center"><StickerIcon/></button>
                            <button onClick={() => addMusic('Running Up That Hill')} className="w-12 h-12 bg-black/50 rounded-full backdrop-blur-sm flex items-center justify-center"><MusicIcon/></button>
                            <button onClick={() => setCurrentFilterIndex(0)} className="w-12 h-12 bg-black/50 rounded-full backdrop-blur-sm flex items-center justify-center"><EffectsIcon/></button>
                            <button onClick={() => setIsDrawing(!isDrawing)} className={`w-12 h-12 bg-black/50 rounded-full backdrop-blur-sm flex items-center justify-center transition-colors ${isDrawing ? 'bg-white text-black' : ''}`}><DrawIcon/></button>
                            <button onClick={() => { alert('Save functionality not implemented in this demo.') }} className="w-12 h-12 bg-black/50 rounded-full backdrop-blur-sm flex items-center justify-center"><SaveIcon/></button>
                        </div>
                        
                        {isDrawing && (
                            <div className="absolute top-16 right-20 flex gap-2 p-2 bg-black/50 rounded-full z-20">
                                {['#FFFFFF', '#FF3B30', '#FF9500', '#FFCC00', '#34C759', '#007AFF', '#5856D6'].map(c => <button key={c} onClick={() => setDrawColor(c)} style={{backgroundColor: c}} className={`w-6 h-6 rounded-full border-2 ${drawColor === c ? 'border-white' : 'border-transparent'}`}></button>)}
                            </div>
                        )}
                        
                        <div className="absolute bottom-4 left-4 right-4 flex items-center gap-2 z-20">
                            <input type="text" value={caption} onChange={e => setCaption(e.target.value)} placeholder={t('storyEditor.addCaptionPlaceholder') as string} className="flex-1 bg-black/50 backdrop-blur-sm text-white placeholder-gray-300 px-4 py-3 rounded-full border border-white/20 focus:outline-none focus:border-white" />
                            <button onClick={handleSubmit} className="px-4 py-3 bg-white text-black font-bold rounded-full">Share</button>
                        </div>
                    </>
                )}

                {isEditingText && (
                    <div className="absolute inset-0 bg-black/80 backdrop-blur-md flex flex-col items-center justify-center z-40 p-4">
                        <textarea value={currentText} onChange={e => setCurrentText(e.target.value)} autoFocus className="w-full text-center bg-transparent text-4xl font-bold focus:outline-none text-white" style={{color: textColor}} placeholder="Type something..." />
                        <div className="flex gap-3 mt-4">
                             {['#FFFFFF', '#FF3B30', '#FF9500', '#FFCC00', '#34C759', '#007AFF', '#5856D6'].map(c => <button key={c} onClick={() => setTextColor(c)} style={{backgroundColor: c}} className={`w-8 h-8 rounded-full border-2 ${textColor === c ? 'border-white' : 'border-transparent'}`}></button>)}
                        </div>
                        <button onClick={handleAddText} className="mt-8 bg-white text-black px-6 py-2 rounded-full font-bold">Done</button>
                    </div>
                )}
                
                {isDrawerOpen && (
                     <div className="absolute inset-0 z-30 flex flex-col justify-end" onClick={() => setIsDrawerOpen(false)}>
                        <div className="bg-black/80 backdrop-blur-xl h-[60%] rounded-t-2xl p-4 space-y-4 animate-slideInUp" onClick={e => e.stopPropagation()}>
                            <div className="w-10 h-1 bg-gray-600 rounded-full mx-auto mb-2"></div>
                            <button onClick={() => { const user = prompt("Username to mention:"); if (user) addMention(user); setIsDrawerOpen(false); }} className="w-full text-left p-3 bg-white/10 rounded-lg text-white">@ Mention</button>
                         </div>
                     </div>
                )}
            </div>
        </div>
    );
};

export default StoryEditorModal;