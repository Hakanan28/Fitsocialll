
import React, { useState } from 'react';
import Modal from '../ui/Modal';
import { AiRecipeResponse, DetailedUserProfileData, FoodLogEntry } from '../../types';
import { generateAiKitchenPlan } from '../../services/geminiService';
import { useTranslation, supportedLanguages } from '../../hooks/i18n';

interface AiRecipeModalProps {
    closeModal: () => void;
    userProfileData: DetailedUserProfileData;
    foodLog?: FoodLogEntry[];
}

const AiRecipeModal: React.FC<AiRecipeModalProps> = ({ closeModal, userProfileData, foodLog = [] }) => {
    const { t, language } = useTranslation();
    const [activeTab, setActiveTab] = useState<'pantry' | 'meal_plan'>('pantry');
    const [ingredients, setIngredients] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [result, setResult] = useState<AiRecipeResponse | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [shoppingList, setShoppingList] = useState<string[]>([]);
    const [loggedMealIndices, setLoggedMealIndices] = useState<Set<number>>(new Set());

    const handleGenerate = async () => {
        if (activeTab === 'pantry' && !ingredients.trim()) {
            setError("Please enter some ingredients.");
            return;
        }

        setIsLoading(true);
        setError(null);
        setResult(null);
        setShoppingList([]);
        setLoggedMealIndices(new Set());

        try {
            const languageName = supportedLanguages[language]?.name || 'English';
            const ingredientList = ingredients.split(',').map(i => i.trim()).filter(Boolean);
            
            // Filter logs for today and yesterday
            const todayStr = new Date().toISOString().split('T')[0];
            const todayLogs = foodLog.filter(l => l.date === todayStr);
            
            const d = new Date();
            d.setDate(d.getDate() - 1);
            const yesterdayStr = d.toISOString().split('T')[0];
            const yesterdayLogs = foodLog.filter(l => l.date === yesterdayStr);

            const response = await generateAiKitchenPlan(
                activeTab, 
                userProfileData, 
                ingredientList, 
                languageName,
                todayLogs,
                yesterdayLogs
            );
            setResult(response);

            // If pantry mode, missing items auto-add to potential shopping list
            if (activeTab === 'pantry' && response.meals?.[0]?.missingIngredients) {
                setShoppingList(response.meals[0].missingIngredients);
            }
        } catch (err: any) {
            setError(err.message || "Failed to generate plan.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleLogMeal = (index: number) => {
        // Since this modal doesn't have direct access to update nutrition context (App.tsx logic),
        // we simulate a successful log visually. In a real implementation, onAddMeal prop should be passed here too.
        // For now, we assume the parent ExplorePage handles the main logging logic, and this modal is for viewing.
        // However, if we want to simulate it:
        setLoggedMealIndices(prev => new Set(prev).add(index));
        // alert("Meal Logged!"); // Removed alert per user request
    };

    const toggleShoppingItem = (item: string) => {
        if (shoppingList.includes(item)) {
            setShoppingList(prev => prev.filter(i => i !== item));
        } else {
            setShoppingList(prev => [...prev, item]);
        }
    };

    return (
        <Modal title="🍽️ AI Smart Kitchen" closeModal={closeModal} show={true}>
            <div className="flex p-1 bg-gray-800 rounded-xl font-semibold mb-4">
                <button onClick={() => { setActiveTab('pantry'); setResult(null); }} className={`w-1/2 py-2 rounded-lg transition-colors text-sm ${activeTab === 'pantry' ? 'bg-orange-500 text-white' : 'text-gray-400'}`}>
                    Pantry Chef
                </button>
                <button onClick={() => { setActiveTab('meal_plan'); setResult(null); }} className={`w-1/2 py-2 rounded-lg transition-colors text-sm ${activeTab === 'meal_plan' ? 'bg-green-500 text-white' : 'text-gray-400'}`}>
                    Daily Meal Plan
                </button>
            </div>

            {!result && (
                <div className="space-y-4 animate-fadeIn">
                    {activeTab === 'pantry' ? (
                        <>
                            <label className="text-sm text-gray-300 block">What's in your fridge? (comma separated)</label>
                            <textarea 
                                value={ingredients}
                                onChange={e => setIngredients(e.target.value)}
                                rows={3}
                                placeholder="e.g., eggs, spinach, chicken breast, rice, avocado"
                                className="w-full p-3 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-orange-500 transition-all"
                            />
                        </>
                    ) : (
                        <div className="bg-gray-800 p-4 rounded-xl border border-green-500/30 text-center">
                            <p className="text-gray-200 text-sm mb-2">Generating a full day plan based on your profile:</p>
                            <div className="flex justify-center gap-4 text-xs font-bold text-green-400 uppercase">
                                <span>{userProfileData.somatotype}</span>
                                <span>•</span>
                                <span>{userProfileData.fatDistribution} Shape</span>
                            </div>
                        </div>
                    )}
                    
                    <button 
                        onClick={handleGenerate} 
                        disabled={isLoading}
                        className={`w-full py-3 rounded-xl font-bold shadow-lg transition-transform hover:scale-105 disabled:opacity-50 disabled:transform-none text-white ${activeTab === 'pantry' ? 'bg-orange-500 hover:bg-orange-600' : 'bg-green-500 hover:bg-green-600'}`}
                    >
                        {isLoading ? "Cooking up magic..." : (activeTab === 'pantry' ? "Create Recipe" : "Generate Meal Plan")}
                    </button>
                    {error && <p className="text-red-400 text-sm text-center">{error}</p>}
                </div>
            )}

            {result && (
                <div className="space-y-6 animate-fadeIn max-h-[60vh] overflow-y-auto pr-1">
                    <div className="text-center">
                        <h3 className="text-xl font-bold text-white mb-1">{result.planName}</h3>
                        <p className="text-xs text-gray-400 italic px-2">{result.aiAnalysis}</p>
                    </div>

                    {result.meals?.map((meal, idx) => (
                        <div key={idx} className="bg-[#1E1E1E] rounded-xl overflow-hidden border border-gray-700">
                            <div className="bg-gray-800 p-3 flex justify-between items-center">
                                <span className="font-bold text-white">{meal.type}: {meal.name}</span>
                                <button 
                                    onClick={() => handleLogMeal(idx)} 
                                    disabled={loggedMealIndices.has(idx)}
                                    className={`text-[10px] font-bold px-3 py-1 rounded-full transition-colors ${loggedMealIndices.has(idx) ? 'bg-gray-600 text-gray-300 cursor-default' : 'bg-green-600 text-white hover:bg-green-500'}`}
                                >
                                    {loggedMealIndices.has(idx) ? 'Logged ✓' : 'Log Meal'}
                                </button>
                            </div>
                            <div className="p-3 space-y-3">
                                <div className="grid grid-cols-4 gap-2 text-center text-xs bg-black/30 p-2 rounded-lg">
                                    <div><span className="block text-gray-400">Cal</span><span className="font-bold text-white">{meal.macros.calories}</span></div>
                                    <div><span className="block text-gray-400">Pro</span><span className="font-bold text-blue-400">{meal.macros.protein}g</span></div>
                                    <div><span className="block text-gray-400">Carb</span><span className="font-bold text-orange-400">{meal.macros.carbs}g</span></div>
                                    <div><span className="block text-gray-400">Fat</span><span className="font-bold text-yellow-400">{meal.macros.fat}g</span></div>
                                </div>
                                
                                {/* Extended Macros Section */}
                                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-[10px] bg-black/20 p-2 rounded-lg border border-white/5">
                                    <div><span className="block text-gray-500">Sodium</span><span className="font-bold text-gray-300">{meal.macros.sodium || 0}mg</span></div>
                                    <div><span className="block text-gray-500">Sugar</span><span className="font-bold text-gray-300">{meal.macros.sugar || 0}g</span></div>
                                    <div><span className="block text-gray-500">Fiber</span><span className="font-bold text-gray-300">{meal.macros.fiber || 0}g</span></div>
                                    <div><span className="block text-gray-500">Sat. Fat</span><span className="font-bold text-gray-300">{meal.macros.saturatedFat || 0}g</span></div>
                                </div>

                                <div className="text-xs text-gray-400 text-center">Micro-boost: <span className="text-green-400">{meal.macros.vitamins}</span></div>
                                
                                <div>
                                    <h4 className="text-xs font-bold text-gray-300 uppercase mb-1">Ingredients</h4>
                                    <ul className="space-y-1">
                                        {meal.ingredients?.map((ing, i) => (
                                            <li key={i} className="flex items-center text-sm text-gray-300">
                                                <input type="checkbox" className="mr-2 accent-green-500" defaultChecked={activeTab === 'pantry' && !meal.missingIngredients?.includes(ing)} />
                                                {ing}
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                                
                                {meal.instructions && (
                                    <div>
                                        <h4 className="text-xs font-bold text-gray-300 uppercase mb-1">Instructions</h4>
                                        <ol className="list-decimal list-inside text-sm text-gray-400 space-y-1">
                                            {meal.instructions.map((step, i) => <li key={i}>{step}</li>)}
                                        </ol>
                                    </div>
                                )}
                            </div>
                        </div>
                    ))}

                    {(shoppingList.length > 0 || (activeTab === 'meal_plan')) && (
                         <div className="bg-yellow-900/20 border border-yellow-600 p-4 rounded-xl">
                            <h4 className="text-yellow-400 font-bold mb-2">📝 Shopping List</h4>
                            <p className="text-xs text-gray-400 mb-2">Check items you need to buy:</p>
                            <div className="space-y-1">
                                {(activeTab === 'meal_plan' ? result.meals?.flatMap(m => m.ingredients || []) : shoppingList).map((item, i) => (
                                    // Simple deduping by key
                                    <label key={`${item}-${i}`} className="flex items-center text-sm text-gray-300 cursor-pointer">
                                        <input type="checkbox" className="mr-2 accent-yellow-500" />
                                        {item}
                                    </label>
                                ))}
                            </div>
                         </div>
                    )}

                    <button onClick={() => setResult(null)} className="w-full bg-gray-700 text-white font-bold py-3 rounded-xl hover:bg-gray-600 transition-colors">
                        Start Over
                    </button>
                </div>
            )}
        </Modal>
    );
};

export default AiRecipeModal;
