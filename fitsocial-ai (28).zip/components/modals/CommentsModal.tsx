
import React, { useState, useEffect, useRef } from 'react';
import { findUser } from '../../data/users';
import { UserProfile, Comment, ModalType } from '../../types';

interface CommentsModalProps {
    closeModal: () => void;
    modalData: { id: number | string; author: string; type: 'post' | 'reel' | 'pow' | 'routine' };
    currentUser: UserProfile;
    users: UserProfile[];
    comments: Comment[];
    onAddComment: (mediaId: number | string, commentText: string, mediaType: 'post' | 'reel' | 'pow' | 'routine') => void;
    openModal: (modal: ModalType, data?: any) => void;
}

const CommentsModal: React.FC<CommentsModalProps> = ({ closeModal, modalData, currentUser, users, comments, onAddComment, openModal }) => {
    const [newComment, setNewComment] = useState('');
    const commentsEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        commentsEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        scrollToBottom();
    }, [comments]);

    const handlePostComment = (e: React.FormEvent) => {
        e.preventDefault();
        if (newComment.trim()) {
            onAddComment(modalData.id, newComment.trim(), modalData.type);
            setNewComment('');
        }
    };
    
     const handleOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
        if (e.target === e.currentTarget) {
            closeModal();
        }
    };

    return (
        <div className="fixed inset-0 bg-black/60 z-[300] flex items-end justify-center animate-fadeIn" onClick={handleOverlayClick}>
            <div 
                className="bg-[#1E1E1E] w-full max-w-md h-[70vh] rounded-t-2xl shadow-2xl flex flex-col animate-slideInUp border-t border-white/10" 
                onClick={e => e.stopPropagation()}
            >
                <header className="flex-shrink-0 p-4 border-b border-gray-700 text-center relative">
                    <div className="w-12 h-1 bg-gray-600 rounded-full absolute top-2 left-1/2 transform -translate-x-1/2"></div>
                    <h3 className="text-sm font-bold text-white mt-2">Comments</h3>
                    <button onClick={closeModal} className="absolute top-1/2 -translate-y-1/2 right-4 text-gray-400 hover:text-white text-2xl">&times;</button>
                </header>
                <div className="flex-grow p-4 space-y-4 overflow-y-auto">
                    {comments.map((comment) => {
                        const user = findUser(comment.user, users) || (comment.user === currentUser.username ? currentUser : null);
                        const handleViewProfile = (e: React.MouseEvent) => {
                            e.stopPropagation();
                            if (user && openModal) {
                                closeModal();
                                // Timeout to allow modal to close before opening the next
                                setTimeout(() => openModal(ModalType.Profile, user), 100);
                            }
                        };
                        return (
                             <div key={comment.id} className="flex items-start space-x-3 animate-fadeIn">
                                <img 
                                    src={user?.avatarImage || `https://placehold.co/100x100/333/FFF?text=${comment.user.charAt(0)}`} 
                                    alt={comment.user} 
                                    className="w-8 h-8 rounded-full object-cover border border-white/10 cursor-pointer"
                                    onClick={handleViewProfile}
                                />
                                <div className="flex-1">
                                    <p className="text-sm">
                                        <span 
                                            className="font-bold text-white mr-2 text-xs cursor-pointer hover:underline"
                                            onClick={handleViewProfile}
                                        >
                                            {comment.user}
                                        </span>
                                        <span className="text-gray-300 text-xs">{comment.text}</span>
                                    </p>
                                </div>
                            </div>
                        )
                    })}
                    {comments.length === 0 && (
                        <p className="text-center text-gray-500 py-10 text-sm">No comments yet.</p>
                    )}
                    <div ref={commentsEndRef} />
                </div>
                <footer className="flex-shrink-0 p-3 border-t border-gray-700 bg-[#1E1E1E] pb-8">
                    <form onSubmit={handlePostComment} className="flex space-x-2 items-center">
                        <img src={currentUser.avatarImage} alt="You" className="w-8 h-8 rounded-full object-cover border border-white/10" />
                        <input
                            type="text"
                            value={newComment}
                            onChange={(e) => setNewComment(e.target.value)}
                            placeholder={`Add a comment for ${modalData.author}...`}
                            className="flex-1 bg-gray-800 text-xs rounded-full px-4 py-2.5 border border-transparent focus:outline-none focus:ring-1 focus:ring-green-500 text-white placeholder-gray-500"
                            autoFocus
                        />
                        <button type="submit" className="text-green-500 font-bold text-xs hover:text-green-400 disabled:text-gray-600 transition-colors px-2" disabled={!newComment.trim()}>Post</button>
                    </form>
                </footer>
            </div>
        </div>
    );
};

export default CommentsModal;
