import React from 'react';
import { NFT } from '../../../types';

interface NftDetailModalProps {
    closeModal: () => void;
    nft: NFT;
}

const NftDetailModal: React.FC<NftDetailModalProps> = ({ closeModal, nft }) => {
    if (!nft) return null;

    const handleOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
        if (e.target === e.currentTarget) closeModal();
    };

    return (
        <div className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-4" onClick={handleOverlayClick}>
            <div className="bg-[#1E1E1E] w-full max-w-sm rounded-2xl shadow-2xl flex flex-col animate-slideIn max-h-[90vh]">
                <header className="flex justify-between items-center p-4 border-b border-gray-700">
                    <h3 className="text-xl font-bold text-white truncate">{nft.name}</h3>
                    <button onClick={closeModal} className="text-gray-400 hover:text-white text-2xl">&times;</button>
                </header>

                <div className="flex-grow p-4 space-y-4 overflow-y-auto">
                    <img src={nft.imageUrl} alt={nft.name} className="w-full aspect-square object-cover rounded-xl"/>

                    <div className="p-4 bg-gray-800 rounded-xl">
                        <p className="text-xs text-gray-400">Collection</p>
                        <h4 className="font-bold text-green-400 text-lg">{nft.collection}</h4>
                        {nft.description && (
                            <>
                                <div className="border-t border-gray-700 my-3"></div>
                                <p className="text-sm text-gray-300">{nft.description}</p>
                            </>
                        )}
                    </div>

                    <button 
                        onClick={() => alert('Send NFT flow started (simulated)!')}
                        className="w-full bg-blue-600 text-white font-bold py-3 rounded-xl hover:bg-blue-700 transition-all transform hover:scale-105">
                        Send NFT
                    </button>
                </div>
            </div>
        </div>
    );
};

export default NftDetailModal;