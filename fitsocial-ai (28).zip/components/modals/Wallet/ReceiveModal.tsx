
import React from 'react';
import Modal from '../../ui/Modal';

interface ReceiveModalProps {
    closeModal: () => void;
    onReceiveTransaction?: (amount: number) => void;
}

const ReceiveModal: React.FC<ReceiveModalProps> = ({ closeModal, onReceiveTransaction }) => {
    const walletAddress = "0x71C...92F3";
    const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${walletAddress}&bgcolor=1f2937&color=ffffff`;

    const handleCopy = () => {
        navigator.clipboard.writeText(walletAddress);
        alert("Address copied to clipboard!");
    };
    
    const handleSimulateDeposit = () => {
        if (onReceiveTransaction) {
            // Simulate receiving 0.5 ETH for testing purposes since wallet starts at 0
            onReceiveTransaction(0.5);
            closeModal();
        }
    };

    return (
        <Modal title="Receive Funds" closeModal={closeModal} show={true}>
            <div className="text-center space-y-4">
                <p className="text-sm text-gray-400">Scan to deposit assets. Supports ETH & ERC-20.</p>
                <div className="p-4 bg-gray-800 rounded-xl flex items-center justify-center shadow-inner">
                    <img src={qrCodeUrl} alt="Wallet QR Code" className="w-48 h-48 rounded-lg border-4 border-gray-700"/>
                </div>
                <div onClick={handleCopy} className="p-3 bg-gray-800 rounded-xl cursor-pointer hover:bg-gray-700 transition-colors border border-gray-600">
                    <p className="text-xs text-gray-500 mb-1">Your Address</p>
                    <p className="text-sm font-mono text-white break-all flex items-center justify-center gap-2">
                        {walletAddress} 
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                    </p>
                </div>
                
                <div className="grid grid-cols-2 gap-3 mt-4">
                     <button onClick={handleCopy} className="bg-blue-600 text-white font-bold py-3 rounded-xl hover:bg-blue-500 transition-all text-sm">
                        Copy Address
                    </button>
                    {/* Simulation Button for Zero Balance Start */}
                    <button onClick={handleSimulateDeposit} className="bg-purple-600 text-white font-bold py-3 rounded-xl hover:bg-purple-500 transition-all text-sm flex items-center justify-center gap-2">
                        <span>🎁</span> Test Faucet
                    </button>
                </div>
                <p className="text-[10px] text-gray-600">Use 'Test Faucet' to simulate an incoming deposit for demo purposes.</p>
            </div>
        </Modal>
    );
};

export default ReceiveModal;
