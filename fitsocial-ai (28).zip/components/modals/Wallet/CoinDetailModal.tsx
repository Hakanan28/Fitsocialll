
import React, { useEffect, useRef, useState } from 'react';
import { Coin, ModalType, NewsItem } from '../../../types';
import { fetchCandlestickData, fetchCoinNews } from '../../../services/cryptoService';

interface CoinDetailModalProps {
    closeModal: () => void;
    openModal: (modal: ModalType, data?: any) => void;
    coin: Coin;
}

type TimeInterval = '15m' | '1h' | '4h' | '1d' | '1w';

const CoinDetailModal: React.FC<CoinDetailModalProps> = ({ closeModal, openModal, coin }) => {
    const [candleData, setCandleData] = useState<any[]>([]);
    const [news, setNews] = useState<NewsItem[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [interval, setInterval] = useState<TimeInterval>('1h'); // Default interval
    
    const chartRef = useRef<HTMLDivElement>(null);
    const chartInstance = useRef<any>(null);

    // Fetch Data when coin or interval changes
    useEffect(() => {
        const loadData = async () => {
            setIsLoading(true);
            try {
                const [candles, newsItems] = await Promise.all([
                    fetchCandlestickData(coin.symbol, interval),
                    fetchCoinNews(coin.symbol)
                ]);
                setCandleData(candles);
                setNews(newsItems);
            } catch (error) {
                console.error("Data fetch failed", error);
            } finally {
                setIsLoading(false);
            }
        };
        
        loadData();
    }, [coin.symbol, interval]);

    // Initialize ApexChart
    useEffect(() => {
        if (!chartRef.current || candleData.length === 0) return;
        
        // Destroy previous instance if exists to prevent memory leaks and double rendering
        if (chartInstance.current) {
            chartInstance.current.destroy();
        }

        const options = {
            series: [{
                data: candleData
            }],
            chart: {
                type: 'candlestick',
                height: 350,
                background: 'transparent',
                toolbar: { show: false }, // Hide the desktop toolbar for a cleaner mobile look
                animations: { enabled: false }, // Disable animations for better performance on pan/zoom
                
                // --- CRITICAL INTERACTION SETTINGS ---
                selection: {
                    enabled: false // DISABLES the square drag select tool
                },
                zoom: {
                    enabled: true,
                    type: 'x', // Zoom only on time axis
                    autoScaleYaxis: true // Candles rescale vertically when zooming
                },
                pan: {
                    enabled: true, // Enable single finger panning
                    type: 'x'      // Pan only on time axis
                }
            },
            title: {
                text: `${coin.symbol}/USDT`,
                align: 'left',
                style: { color: '#9CA3AF', fontSize: '12px', fontFamily: 'Inter, sans-serif' }
            },
            xaxis: {
                type: 'datetime',
                labels: { 
                    style: { colors: '#6B7280', fontSize: '10px' },
                    datetimeFormatter: {
                        year: 'yyyy',
                        month: "MMM 'yy",
                        day: 'dd MMM',
                        hour: 'HH:mm'
                    }
                },
                axisBorder: { show: false },
                axisTicks: { show: false },
                tooltip: { enabled: false }, // Disable X-axis tooltip for cleaner interaction
                crosshairs: { show: true, stroke: { color: '#374151', dashArray: 4 } }
            },
            yaxis: {
                tooltip: { enabled: true },
                opposite: true, // Put prices on the right side like most trading apps
                labels: { 
                    style: { colors: '#9CA3AF', fontSize: '10px' },
                    formatter: (val: number) => {
                        if (val < 1) return val.toFixed(4);
                        return val.toFixed(2);
                    }
                }
            },
            grid: {
                borderColor: '#1F2937',
                strokeDashArray: 4,
                xaxis: { lines: { show: false } },   
                yaxis: { lines: { show: true } },
            },
            theme: { mode: 'dark' },
            plotOptions: {
                candlestick: {
                    colors: {
                        upward: '#10B981',   // Green
                        downward: '#EF4444'  // Red
                    },
                    wick: {
                        useFillColor: true,
                    }
                }
            }
        };

        // Check if ApexCharts is loaded (it should be via index.html CDN)
        if ((window as any).ApexCharts) {
            chartInstance.current = new (window as any).ApexCharts(chartRef.current, options);
            chartInstance.current.render();
        }

        return () => {
            if (chartInstance.current) chartInstance.current.destroy();
        }
    }, [candleData]); // Re-render only when data changes

    if (!coin) return null;

    // Dynamic Balance Calculation
    const estimatedValue = coin.balance * coin.price;
    
    const intervals: TimeInterval[] = ['15m', '1h', '4h', '1d', '1w'];

    return (
        <div className="fixed inset-0 bg-[#0B0E14] z-[300] flex flex-col animate-slideInUp overflow-hidden font-sans">
            {/* Full Screen Header */}
            <header className="flex items-center justify-between p-4 border-b border-gray-800 bg-[#151A23]">
                <div className="flex items-center gap-3">
                    <button onClick={closeModal} className="p-2 rounded-full hover:bg-white/10 transition-colors">
                         <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                    </button>
                    <div className="flex items-center gap-2">
                         <img src={coin.logoUrl} alt={coin.name} className="w-8 h-8 rounded-full bg-white/10 p-1" />
                         <div>
                             <h1 className="text-lg font-bold text-white leading-tight">{coin.name}</h1>
                             <div className="flex items-center gap-2">
                                <span className="text-xs font-mono text-gray-400">{coin.symbol}</span>
                                <span className={`text-xs font-bold px-1.5 rounded ${coin.priceChange24h >= 0 ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                                    {coin.priceChange24h >= 0 ? '+' : ''}{coin.priceChange24h.toFixed(2)}%
                                </span>
                             </div>
                         </div>
                    </div>
                </div>
                <div className="text-right">
                     <p className="text-white font-bold text-lg">${coin.price.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 6})}</p>
                </div>
            </header>

            <div className="flex-grow overflow-y-auto custom-scrollbar bg-[#0B0E14]">
                
                {/* Time Interval Selector */}
                <div className="flex border-b border-gray-800 bg-[#151A23] px-4 py-2 gap-4 overflow-x-auto no-scrollbar">
                    {intervals.map((t) => (
                        <button 
                            key={t} 
                            onClick={() => setInterval(t)}
                            className={`text-xs font-bold py-1 px-3 rounded-lg transition-colors whitespace-nowrap ${interval === t ? 'bg-gray-700 text-white' : 'text-gray-500 hover:text-gray-300'}`}
                        >
                            {t}
                        </button>
                    ))}
                </div>

                {/* Chart Section */}
                <div className="h-[400px] w-full bg-[#151A23] relative border-b border-gray-800">
                    {isLoading && (
                        <div className="absolute inset-0 flex items-center justify-center z-10 bg-[#151A23]/80 backdrop-blur-sm">
                             <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                        </div>
                    )}
                    <div ref={chartRef} className="w-full h-full"></div>
                </div>

                {/* Actions & Balance */}
                <div className="grid grid-cols-2 gap-4 p-4 border-b border-gray-800">
                     <div className="bg-gray-800/50 p-3 rounded-xl border border-white/5">
                         <p className="text-[10px] text-gray-400 uppercase font-bold">Your Balance</p>
                         <p className="text-xl font-white font-bold mt-1">{coin.balance > 0 ? coin.balance.toFixed(4) : "0.00"} {coin.symbol}</p>
                         <p className="text-xs text-gray-500">≈ ${estimatedValue.toFixed(2)}</p>
                     </div>
                     <div className="flex flex-col gap-2">
                         <button onClick={() => openModal(ModalType.SendCoin, coin)} className="flex-1 bg-blue-600 text-white font-bold text-sm rounded-lg hover:bg-blue-500 transition-colors shadow-lg flex items-center justify-center gap-2">
                             <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="7" y1="17" x2="17" y2="7"/><polyline points="7 7 17 7 17 17"/></svg>
                             Send
                         </button>
                         <button onClick={() => openModal(ModalType.ReceiveCoin)} className="flex-1 bg-green-600 text-white font-bold text-sm rounded-lg hover:bg-green-500 transition-colors shadow-lg flex items-center justify-center gap-2">
                             <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="7" y1="7" x2="17" y2="17"/><polyline points="17 7 17 17 7 17"/></svg>
                             Receive
                         </button>
                     </div>
                </div>

                {/* News Section */}
                <div className="p-4 pb-10">
                    <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                        <span>📰</span> Market News
                    </h3>
                    
                    {isLoading && news.length === 0 ? (
                        <div className="space-y-3">
                            {[1,2,3].map(i => (
                                <div key={i} className="h-20 bg-gray-800/50 rounded-xl animate-pulse"></div>
                            ))}
                        </div>
                    ) : news.length > 0 ? (
                        <div className="space-y-4">
                            {news.map(item => (
                                <a href={item.url} target="_blank" rel="noopener noreferrer" key={item.id} className="flex gap-3 group hover:bg-gray-800/50 p-2 -mx-2 rounded-xl transition-colors">
                                    <div className="w-24 h-24 flex-shrink-0 rounded-lg overflow-hidden bg-gray-800 border border-white/5">
                                        <img src={item.imageurl} alt="News" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                                    </div>
                                    <div className="flex-1 flex flex-col justify-between">
                                        <h4 className="text-white font-semibold text-sm line-clamp-2 group-hover:text-blue-400 transition-colors leading-snug">{item.title}</h4>
                                        <div className="flex justify-between items-center mt-2">
                                            <span className="text-[10px] text-gray-400 bg-gray-800 px-2 py-0.5 rounded">{item.source}</span>
                                            <span className="text-[10px] text-gray-500">{new Date(item.published_on * 1000).toLocaleDateString()}</span>
                                        </div>
                                    </div>
                                </a>
                            ))}
                        </div>
                    ) : (
                        <div className="text-center py-10 text-gray-500">
                            No recent news found for {coin.name}.
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default CoinDetailModal;
