
import React, { useState } from 'react';
import Modal from '../../ui/Modal';
import { Coin } from '../../../types';

interface SendModalProps {
    closeModal: () => void;
    coin?: Coin; // Can be opened without a specific coin
    showNotification: (message: string, type?: 'success' | 'error') => void;
    onSendTransaction?: (amount: number, address: string) => void;
}

const SendModal: React.FC<SendModalProps> = ({ closeModal, coin, showNotification, onSendTransaction }) => {
    const [step, setStep] = useState(1);
    const [recipient, setRecipient] = useState('');
    const [amount, setAmount] = useState('');
    const [gasFee] = useState(0.0005); // Simulated gas fee in ETH

    const handleNext = () => {
        if (!recipient.trim()) {
            showNotification("Please enter a valid recipient address.", "error");
            return;
        }
        
        const val = parseFloat(amount);
        if (isNaN(val) || val <= 0) {
            showNotification("Please enter a valid amount.", "error");
            return;
        }

        if (coin && val > coin.balance) {
            showNotification(`Insufficient balance. You have ${coin.balance} ${coin.symbol}.`, "error");
            return;
        }

        setStep(2);
    };

    const handleConfirm = () => {
        if (onSendTransaction && coin) {
            onSendTransaction(parseFloat(amount), recipient);
        } else {
             showNotification("Transaction processed (Simulation)", "success");
        }
        closeModal();
    };

    const renderStep1 = () => (
        <div className="space-y-4">
            <div>
                <label className="text-sm font-bold text-gray-300 block mb-1">Recipient Address</label>
                <input 
                    type="text" 
                    value={recipient} 
                    onChange={e => setRecipient(e.target.value)}
                    placeholder="0x..."
                    className="w-full p-3 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/50 transition-all"/>
            </div>
            <div>
                <div className="flex justify-between">
                    <label className="text-sm font-bold text-gray-300 block mb-1">Amount {coin ? `(${coin.symbol})` : ''}</label>
                    {coin && <span className="text-xs text-blue-400 font-bold cursor-pointer hover:underline" onClick={() => setAmount(coin.balance.toString())}>Max: {coin.balance.toFixed(4)}</span>}
                </div>
                <input 
                    type="number" 
                    value={amount}
                    onChange={e => setAmount(e.target.value)}
                    placeholder="0.0"
                    className="w-full p-3 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/50 transition-all"/>
            </div>
            <button onClick={handleNext} className="w-full bg-blue-600 text-white font-bold py-3 rounded-xl hover:bg-blue-700 transition-all transform hover:scale-105 shadow-lg">
                Next
            </button>
        </div>
    );

    const renderStep2 = () => (
        <div className="space-y-4 text-sm">
             <h3 className="text-lg font-bold text-white text-center mb-4">Confirm Transaction</h3>
             <div className="p-4 bg-gray-800 rounded-xl space-y-3 border border-gray-700">
                <div className="flex justify-between"><span className="text-gray-400">To:</span> <span className="font-mono text-white truncate w-32">{recipient}</span></div>
                <div className="flex justify-between"><span className="text-gray-400">Amount:</span> <span className="font-bold text-white text-lg">{amount} {coin?.symbol || 'ETH'}</span></div>
                <div className="border-t border-gray-700 my-2"></div>
                <div className="flex justify-between"><span className="text-gray-400">Est. Gas Fee:</span> <span className="text-gray-300">{gasFee} ETH</span></div>
                <div className="flex justify-between text-base bg-black/20 p-2 rounded"><span className="text-gray-400 font-bold">Total:</span> <span className="font-extrabold text-blue-400">{amount} {coin?.symbol || 'ETH'} + Gas</span></div>
             </div>
             <div className="flex space-x-2 pt-4">
                <button onClick={() => setStep(1)} className="flex-1 bg-gray-600 text-white font-bold py-3 rounded-xl hover:bg-gray-700 transition-colors">
                    Back
                </button>
                <button onClick={handleConfirm} className="flex-1 bg-green-600 text-white font-bold py-3 rounded-xl hover:bg-green-700 transition-all transform hover:scale-105 animate-pulsate shadow-lg">
                    Confirm & Send
                </button>
            </div>
        </div>
    );

    return (
        <Modal title={`Send ${coin?.name || 'Crypto'}`} closeModal={closeModal} show={true}>
            {step === 1 ? renderStep1() : renderStep2()}
        </Modal>
    );
};

export default SendModal;
