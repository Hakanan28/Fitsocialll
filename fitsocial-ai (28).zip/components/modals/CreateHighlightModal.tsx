import React, { useState } from 'react';
import { Story, StoryHighlight } from '../../types';

interface CreateHighlightModalProps {
    closeModal: () => void;
    onCreateHighlight: (newHighlight: StoryHighlight) => void;
}

const mockArchivedStories: Story[] = [
    { user: 'You', mediaUrl: 'https://picsum.photos/seed/archive1/400/700', mediaType: 'image' },
    { user: 'You', mediaUrl: 'https://firebasestorage.googleapis.com/v0/b/genai-downloads.appspot.com/o/developer-documentation%2Fvideos%2Fsigned-urls%2Frunning.mp4?alt=media&token=050d2c77-7a54-4a57-9fd3-48b4ad1500d4', mediaType: 'video' },
    { user: 'You', mediaUrl: 'https://picsum.photos/seed/archive3/400/700', mediaType: 'image' },
    { user: 'You', mediaUrl: 'https://picsum.photos/seed/archive4/400/700', mediaType: 'image' },
    { user: 'You', mediaUrl: 'https://picsum.photos/seed/archive5/400/700', mediaType: 'image' },
    { user: 'You', mediaUrl: 'https://picsum.photos/seed/archive6/400/700', mediaType: 'image' },
];


const CreateHighlightModal: React.FC<CreateHighlightModalProps> = ({ closeModal, onCreateHighlight }) => {
    const [title, setTitle] = useState('');
    const [selectedStories, setSelectedStories] = useState<Story[]>([]);

    const handleToggleStory = (story: Story) => {
        setSelectedStories(prev => 
            prev.some(s => s.mediaUrl === story.mediaUrl) 
                ? prev.filter(s => s.mediaUrl !== story.mediaUrl) 
                : [...prev, story]
        );
    };

    const handleCreate = () => {
        if (!title.trim() || selectedStories.length === 0) {
            alert("Please provide a title and select at least one story.");
            return;
        }

        const newHighlight: StoryHighlight = {
            id: Date.now().toString(),
            title: title,
            coverImage: selectedStories[0].mediaUrl,
            stories: selectedStories,
        };

        onCreateHighlight(newHighlight);
        closeModal();
    };

    const handleOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
        if (e.target === e.currentTarget) closeModal();
    };

    return (
        <div className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-4 animate-fadeIn" onClick={handleOverlayClick}>
            <div className="bg-gradient-to-br from-[#1f2937] to-[#111827] border border-gray-700 w-full max-w-md p-6 rounded-2xl shadow-2xl shadow-black/50 animate-slideIn flex flex-col max-h-[90vh]">
                <header className="flex justify-between items-center pb-4 border-b border-gray-600 flex-shrink-0">
                    <h3 className="text-xl font-bold text-white">New Highlight</h3>
                    <button onClick={closeModal} className="text-gray-400 hover:text-white transition-all transform hover:rotate-90 text-2xl">&times;</button>
                </header>
                <div className="flex-grow mt-4 overflow-y-auto space-y-4">
                     <div>
                        <label htmlFor="highlight-title" className="text-sm font-bold text-gray-300 block mb-1">Title</label>
                        <input 
                            type="text" 
                            id="highlight-title"
                            value={title}
                            onChange={e => setTitle(e.target.value)}
                            className="w-full p-3 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-green-500 focus:ring-2 focus:ring-green-500/50 transition-all"
                            placeholder="Highlight Name"
                        />
                    </div>
                    <div>
                         <label className="text-sm font-bold text-gray-300 block mb-2">Select from your story archive:</label>
                         <div className="grid grid-cols-3 gap-2">
                             {mockArchivedStories.map((story, index) => (
                                <div 
                                    key={index} 
                                    className="relative aspect-[9/16] rounded-lg overflow-hidden cursor-pointer bg-black"
                                    onClick={() => handleToggleStory(story)}
                                >
                                    {story.mediaType === 'image' ? (
                                        <img src={story.mediaUrl} alt={`Story ${index + 1}`} className="w-full h-full object-cover" />
                                    ) : (
                                        <video src={story.mediaUrl} muted loop className="w-full h-full object-cover" />
                                    )}
                                    {story.mediaType === 'video' && (
                                        <div className="absolute top-1 right-1 bg-black/50 p-1 rounded-full">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="currentColor" className="text-white"><path d="M8 5v14l11-7z"/></svg>
                                        </div>
                                    )}
                                    {selectedStories.some(s => s.mediaUrl === story.mediaUrl) && (
                                        <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                                            <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center border-2 border-white">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className="text-white"><path d="M20 6 9 17l-5-5"/></svg>
                                            </div>
                                        </div>
                                    )}
                                </div>
                             ))}
                         </div>
                    </div>
                </div>
                <footer className="mt-6 flex-shrink-0">
                     <button 
                        onClick={handleCreate} 
                        disabled={!title.trim() || selectedStories.length === 0}
                        className="w-full bg-green-500 text-white font-bold py-3 rounded-xl hover:bg-green-600 transition-colors transform hover:scale-105 disabled:bg-gray-500 disabled:cursor-not-allowed"
                    >
                        Create Highlight
                    </button>
                </footer>
            </div>
        </div>
    );
};

export default CreateHighlightModal;