
import React, { useState, useRef } from 'react';
import { editImage } from '../../services/geminiService';
import Modal from '../ui/Modal';
import { useTranslation } from '../../hooks/i18n';

// Redefine props for this specific modal
interface ImageEditingModalProps {
    closeModal: () => void;
    onSave: (data: { caption: string, mediaUrl: string, filter: string, mediaType: 'image' }) => void;
}

const fileToBase64 = (file: File): Promise<{ base64: string, dataUrl: string }> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => {
            const dataUrl = reader.result as string;
            const base64 = dataUrl.split(',')[1];
            resolve({ base64, dataUrl });
        };
        reader.onerror = error => reject(error);
    });
};

const ImageEditingModal: React.FC<ImageEditingModalProps> = ({ closeModal, onSave }) => {
    const { t } = useTranslation();
    const [originalImage, setOriginalImage] = useState<{ file: File, dataUrl: string } | null>(null);
    const [editedImage, setEditedImage] = useState<string | null>(null);
    const [prompt, setPrompt] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            try {
                const { dataUrl } = await fileToBase64(file);
                setOriginalImage({ file, dataUrl });
                setError(null);
            } catch (err) {
                setError(t('imageEditing.errorLoad') as string);
            }
        }
    };

    const handleGenerate = async () => {
        if (!originalImage || !prompt.trim()) return;
        setIsLoading(true);
        setError(null);
        try {
            const { base64 } = await fileToBase64(originalImage.file);
            const resultDataUrl = await editImage(prompt, base64, originalImage.file.type);
            setEditedImage(resultDataUrl);
        } catch (err) {
            console.error(err);
            setError(t('imageEditing.errorEdit') as string);
        } finally {
            setIsLoading(false);
        }
    };

    const handleUseImage = () => {
        if (editedImage) {
            onSave({
                mediaUrl: editedImage,
                mediaType: 'image',
                caption: `Edited with AI: ${prompt}`, // Add context to caption
                filter: 'none',
            });
            closeModal();
        }
    };
    
    const handleDownload = () => {
        if (!editedImage) return;
        const link = document.createElement('a');
        link.href = editedImage;
        link.download = `fitsocial_magic_edit_${Date.now()}.png`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const handleStartOver = () => {
        setOriginalImage(null);
        setEditedImage(null);
        setError(null);
        setPrompt('');
    };

    return (
        <Modal title={`✨ ${t('imageEditing.title')}`} closeModal={closeModal} show={true}>
            <div className="relative">
                {isLoading && (
                     <div className="absolute inset-0 bg-gray-900/80 z-10 flex flex-col items-center justify-center animate-fadeIn rounded-xl backdrop-blur-sm">
                        <div className="w-10 h-10 border-4 border-gray-600 border-t-emerald-500 rounded-full animate-spin"></div>
                        <p className="text-xs text-emerald-400 mt-3 animate-pulse">{t('imageEditing.loadingMessage')}</p>
                    </div>
                )}
                {error && <p className="text-red-400 text-sm text-center bg-red-900/30 p-3 rounded-lg border border-red-500/30 mb-4">{error}</p>}
                
                {!editedImage ? (
                    <div className="space-y-4 animate-fadeIn">
                        <div>
                            <label className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 block">{t('imageEditing.promptLabel')}</label>
                            <textarea
                                value={prompt}
                                onChange={(e) => setPrompt(e.target.value)}
                                placeholder={t('imageEditing.promptPlaceholder') as string}
                                className="w-full p-4 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/50 transition-colors resize-none"
                                rows={3}
                                disabled={isLoading}
                                autoFocus
                            />
                        </div>

                        {!originalImage ? (
                            <div 
                                onClick={() => fileInputRef.current?.click()}
                                className="h-64 w-full rounded-2xl border-2 border-dashed border-gray-600 bg-gray-800/50 flex flex-col items-center justify-center cursor-pointer hover:border-emerald-500 hover:bg-gray-800 transition-colors"
                            >
                                <div className="w-16 h-16 bg-gray-900/50 rounded-full flex items-center justify-center border border-gray-700 mb-4">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="text-gray-500"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/></svg>
                                </div>
                                <p className="font-bold text-white">{t('imageEditing.uploadImage')}</p>
                                <p className="text-sm text-gray-400">{t('imageEditing.uploadImageDescription')}</p>
                                <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
                            </div>
                        ) : (
                            <div className="relative aspect-[4/5] bg-black rounded-xl overflow-hidden border border-gray-700 w-full max-w-sm mx-auto">
                                <img src={originalImage.dataUrl} className="w-full h-full object-contain" alt="Original Preview"/>
                                <button
                                    onClick={() => { setOriginalImage(null); if(fileInputRef.current) fileInputRef.current.value = ""; }}
                                    className="absolute top-2 right-2 bg-black/60 text-white rounded-full p-1 hover:bg-red-500"
                                >
                                     <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                                </button>
                            </div>
                        )}

                        <button
                            onClick={handleGenerate}
                            disabled={isLoading || !prompt.trim() || !originalImage}
                            className="w-full py-4 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-500 transition-colors disabled:bg-gray-500 disabled:cursor-not-allowed"
                        >
                            {t('imageEditing.createButton')}
                        </button>
                    </div>
                ) : (
                    <div className="space-y-4 animate-fadeIn">
                        <div className="flex flex-col gap-4">
                            <div>
                                <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 text-center">{t('imageEditing.original')}</p>
                                <div className="aspect-square bg-black rounded-xl overflow-hidden border border-gray-700">
                                    <img src={originalImage!.dataUrl} className="w-full h-full object-contain" alt="Original"/>
                                </div>
                            </div>
                            <div>
                                <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 text-center">{t('imageEditing.edited')}</p>
                                <div className="aspect-square bg-black rounded-xl overflow-hidden border-2 border-emerald-500">
                                    <img src={editedImage!} className="w-full h-full object-contain" alt="Edited" />
                                </div>
                            </div>
                        </div>
                        
                        <div>
                            <label className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 block">{t('imageEditing.tryAnotherPrompt')}</label>
                            <div className="relative">
                                <textarea
                                    value={prompt}
                                    onChange={(e) => setPrompt(e.target.value)}
                                    placeholder={t('imageEditing.tryAnotherPlaceholder') as string}
                                    className="w-full p-4 pr-32 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/50 transition-colors resize-none"
                                    rows={2}
                                    disabled={isLoading}
                                />
                                <button
                                    onClick={handleGenerate}
                                    disabled={isLoading || !prompt.trim()}
                                    className="absolute right-2 top-1/2 -translate-y-1/2 bg-emerald-600 text-white font-bold h-[calc(100%-1rem)] px-4 rounded-lg hover:bg-emerald-500 transition-colors disabled:bg-gray-500 disabled:cursor-not-allowed flex items-center justify-center"
                                >
                                    {isLoading ? <div className="w-5 h-5 border-2 border-t-transparent border-white rounded-full animate-spin"></div> : t('imageEditing.recreateButton')}
                                </button>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                            <button
                                onClick={handleDownload}
                                className="w-full py-3 bg-gray-700 text-white font-bold rounded-xl hover:bg-gray-600 transition-colors flex items-center justify-center gap-2"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>
                                {t('imageEditing.downloadButton')}
                            </button>
                            <button
                                onClick={handleStartOver}
                                className="w-full py-3 bg-gray-700 text-white font-bold rounded-xl hover:bg-gray-600 transition-colors"
                            >
                                {t('imageEditing.startOverButton')}
                            </button>
                        </div>
                        <button
                            onClick={handleUseImage}
                            className="w-full py-4 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-500 transition-colors animate-pulse"
                        >
                            {t('imageEditing.useImageButton')}
                        </button>
                    </div>
                )}
            </div>
        </Modal>
    );
};

export default ImageEditingModal;
