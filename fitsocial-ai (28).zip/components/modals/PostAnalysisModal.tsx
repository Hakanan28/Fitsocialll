import React from 'react';
import Modal from '../ui/Modal';

interface PostAnalysisModalProps {
    closeModal: () => void;
    isLoading: boolean;
    analysisResult: string | null;
    error: string | null;
}

const PostAnalysisModal: React.FC<PostAnalysisModalProps> = ({ closeModal, isLoading, analysisResult, error }) => {
    // A more robust markdown renderer that produces valid HTML structure.
    const renderMarkdown = (text: string): React.ReactNode => {
        const lines = text.split('\n');
        const elements: React.ReactNode[] = [];
        let listItems: string[] = [];

        const flushList = () => {
            if (listItems.length > 0) {
                elements.push(
                    <ul key={`ul-${elements.length}`} className="list-disc list-outside space-y-1 pl-5">
                        {listItems.map((item, i) => (
                            <li key={i} className="text-gray-300">{item}</li>
                        ))}
                    </ul>
                );
                listItems = [];
            }
        };

        lines.forEach((line, index) => {
            const trimmedLine = line.trim();
            if (trimmedLine.startsWith('### ') || trimmedLine.startsWith('## ') || trimmedLine.startsWith('# ')) {
                flushList();
                elements.push(<h3 key={index} className="text-lg font-bold text-green-400 mt-4 mb-2">{trimmedLine.replace(/#/g, '').trim()}</h3>);
            } else if (trimmedLine.startsWith('* ') || trimmedLine.startsWith('- ')) {
                listItems.push(trimmedLine.substring(2).trim());
            } else if (trimmedLine !== '') {
                flushList();
                elements.push(<p key={index} className="text-gray-300 mb-2">{trimmedLine}</p>);
            }
        });

        flushList(); // Flush any remaining list items at the end
        return <div>{elements}</div>;
    };

    return (
        <Modal title="AI Post Analysis" closeModal={closeModal} show={true}>
            {isLoading && (
                <div className="text-center p-8">
                    <div className="w-12 h-12 border-4 border-t-green-400 border-gray-600 rounded-full animate-spin mx-auto"></div>
                    <p className="text-green-300 mt-4 font-semibold animate-pulse">AI is analyzing your content strategy...</p>
                </div>
            )}
            {error && (
                 <div className="text-center p-4 bg-red-900/50 border border-red-700 rounded-lg">
                    <p className="text-red-400 font-bold">Analysis Failed</p>
                    <p className="text-red-300 text-sm mt-1">{error}</p>
                </div>
            )}
            {analysisResult && (
                <div className="animate-fadeIn space-y-2">
                     {renderMarkdown(analysisResult)}
                </div>
            )}
        </Modal>
    );
};

export default PostAnalysisModal;