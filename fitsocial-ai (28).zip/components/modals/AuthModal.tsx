
import React, { useState, useEffect } from 'react';
import { UserProfile } from '../../types';
import { findUserByEmail, findUserByPhone } from '../../data/users';
import { useTranslation } from '../../hooks/i18n';

interface AuthModalProps {
    onLoginSuccess: (user: UserProfile) => void;
    onSignUp: (newUser: UserProfile) => void;
    existingUsers: UserProfile[];
}

const SocialButton: React.FC<{ icon: React.ReactNode; onClick: () => void; label?: string }> = ({ icon, onClick, label }) => (
    <button onClick={onClick} className="flex items-center justify-center w-12 h-12 rounded-full bg-[#1a1d24] border border-gray-700 hover:border-[#00ff88] hover:bg-[#00ff88]/10 transition-all duration-300 group shadow-lg">
        <div className="group-hover:scale-110 transition-transform text-gray-300 group-hover:text-[#00ff88]">
            {icon}
        </div>
    </button>
);

const AuthModal: React.FC<AuthModalProps> = ({ onLoginSuccess, onSignUp, existingUsers }) => {
    const { t } = useTranslation();
    
    const [activeTab, setActiveTab] = useState<'login' | 'signup'>('login');
    const [loginIdentifier, setLoginIdentifier] = useState('');
    const [loginPassword, setLoginPassword] = useState('');
    
    // Signup fields
    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    useEffect(() => {
        if (success) {
            const timer = setTimeout(() => setSuccess(''), 4000);
            return () => clearTimeout(timer);
        }
    }, [success]);
    
    const handleLogin = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        const user = findUserByEmail(loginIdentifier, existingUsers) || findUserByPhone(loginIdentifier, existingUsers);
        if (user && user.password === loginPassword) {
            onLoginSuccess(user);
        } else {
            setError(t('auth.invalidIdentifierOrPassword') as string);
        }
    };
    
    const handleGoogleLogin = () => {
        const googleUser = existingUsers.find(u => u.email === 'zeynep@fitsocial.app');
        if (googleUser) onLoginSuccess(googleUser);
        else setError("Simulated Google login user not found.");
    };

    const handleSignUp = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        
        if (existingUsers.some(u => u.username.toLowerCase() === username.toLowerCase())) {
            setError(t('auth.usernameTaken') as string);
            return;
        }

        const newUser: UserProfile = {
            username: username,
            email: email,
            phone: '',
            password: password,
            avatarText: username.charAt(0).toUpperCase() || '?',
            avatarColor: "#" + Math.floor(Math.random()*16777215).toString(16).padStart(6, '0'),
            avatarImage: `https://placehold.co/150x150/333/FFF?text=${(username.charAt(0) || '?').toUpperCase()}`,
            posts: [], followers: 0, following: [],
            cvsScore: 0.0,
            bio: `New FitSocial member!`,
            somatotype: 'mesomorph',
        };
        onSignUp(newUser);
        setSuccess(t('auth.signupSuccess') as string);
        setLoginIdentifier(email);
        setLoginPassword('');
        setActiveTab('login');
    };

    return (
        <div className="fixed inset-0 z-[999] flex items-center justify-center overflow-hidden font-sans bg-black">
            {/* 
               BACKGROUND LAYER
               Using a specific style of image and overlays to match "Running Silhouettes + Neon Waves"
            */}
            <div className="absolute inset-0 w-full h-full">
                {/* Base Image - Futuristic Runner */}
                <img 
                    src="https://images.unsplash.com/photo-1526506118085-60ce8714f8c5?q=80&w=2000&auto=format&fit=crop" 
                    className="w-full h-full object-cover opacity-40 grayscale"
                    alt="Background"
                />
                
                {/* Neon Green/Blue Gradient Overlay for the "Wave" effect */}
                <div className="absolute inset-0 bg-gradient-to-tr from-black via-black/80 to-[#00ff88]/20 mix-blend-hard-light"></div>
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,_rgba(0,255,136,0.15),transparent_70%)]"></div>
                
                {/* Scanline Texture */}
                <div className="absolute inset-0 bg-[linear-gradient(to_bottom,rgba(0,0,0,0)_50%,rgba(0,0,0,0.2)_50%)] bg-[length:100%_4px] pointer-events-none z-0 opacity-20"></div>
            </div>

            {/* MAIN CARD */}
            <div className="relative z-10 w-full max-w-[380px] bg-[#0a0b10]/80 backdrop-blur-xl rounded-[32px] p-8 border border-[#00ff88]/30 shadow-[0_0_50px_rgba(0,255,136,0.15)] flex flex-col items-center animate-slideInUp">
                
                {/* Logo Area */}
                <div className="flex flex-col items-center justify-center mb-8">
                    <div className="w-12 h-12 bg-[#00ff88] rounded-full flex items-center justify-center mb-3 shadow-[0_0_20px_#00ff88]">
                         <svg width="28" height="28" viewBox="0 0 24 24" fill="none" className="text-black">
                             <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2Z" stroke="currentColor" strokeWidth="2.5"/>
                             <path d="M15 15C15 13 14 12 13 12H11C10 12 9 13 9 15" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"/>
                        </svg>
                    </div>
                    <h1 className="text-3xl font-black text-white tracking-tighter italic">FitSocial</h1>
                </div>

                {/* Tabs */}
                <div className="flex bg-[#13151a] p-1.5 rounded-xl w-full mb-8 border border-white/5 relative">
                    <div 
                        className={`absolute top-1.5 bottom-1.5 w-[calc(50%-6px)] bg-[#2a2d36] rounded-lg transition-all duration-300 ease-out ${activeTab === 'login' ? 'left-1.5' : 'left-[calc(50%+3px)]'}`}
                    ></div>
                    <button 
                        onClick={() => setActiveTab('login')}
                        className={`flex-1 py-2.5 rounded-lg text-sm font-bold transition-all relative z-10 ${activeTab === 'login' ? 'text-[#00ff88]' : 'text-gray-500 hover:text-gray-300'}`}
                    >
                        Log In
                    </button>
                    <button 
                        onClick={() => setActiveTab('signup')}
                        className={`flex-1 py-2.5 rounded-lg text-sm font-bold transition-all relative z-10 ${activeTab === 'signup' ? 'text-[#00ff88]' : 'text-gray-500 hover:text-gray-300'}`}
                    >
                        Sign Up
                    </button>
                </div>

                {/* Social Buttons */}
                <div className="flex justify-center gap-6 mb-8 w-full">
                    <SocialButton icon={<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>} onClick={handleGoogleLogin} />
                    <SocialButton icon={<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M12 2.04c-5.5 0-10 4.49-10 10.02 0 5 3.66 9.15 8.44 9.9v-7H7.9v-2.9h2.54V9.85c0-2.51 1.52-3.88 3.77-3.88 1.08 0 2.01.08 2.28.11v2.63h-1.56c-1.22 0-1.46.58-1.46 1.43v1.88h2.91l-.38 2.9h-2.53v7c4.77-.75 8.44-4.9 8.44-9.9 0-5.53-4.5-10.02-10-10.02z"/></svg>} onClick={() => {}} />
                    <SocialButton icon={<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>} onClick={() => {}} />
                </div>

                <div className="flex items-center w-full mb-6">
                    <div className="h-px bg-gray-700 flex-1"></div>
                    <span className="px-4 text-[10px] text-gray-500 font-bold tracking-widest">OR</span>
                    <div className="h-px bg-gray-700 flex-1"></div>
                </div>

                {error && (
                    <div className="w-full bg-red-500/10 border border-red-500/50 rounded-xl p-3 mb-4 text-center">
                        <p className="text-red-400 text-xs font-bold">{error}</p>
                    </div>
                )}
                {success && (
                    <div className="w-full bg-green-500/10 border border-green-500/50 rounded-xl p-3 mb-4 text-center">
                        <p className="text-green-400 text-xs font-bold">{success}</p>
                    </div>
                )}

                {/* Form Area */}
                <form onSubmit={activeTab === 'login' ? handleLogin : handleSignUp} className="w-full space-y-4">
                    
                    {activeTab === 'signup' && (
                        <div className="group">
                            <input 
                                type="text" 
                                value={username} 
                                onChange={e => setUsername(e.target.value)} 
                                placeholder="Username" 
                                className="w-full bg-[#13151a] text-white text-sm rounded-xl px-4 py-3.5 border border-gray-800 focus:border-[#00ff88] focus:ring-1 focus:ring-[#00ff88] outline-none transition-all placeholder-gray-600 font-medium"
                                required 
                            />
                        </div>
                    )}

                    <div className="group">
                        <input 
                            type={activeTab === 'signup' ? "email" : "text"} 
                            value={activeTab === 'login' ? loginIdentifier : email} 
                            onChange={e => activeTab === 'login' ? setLoginIdentifier(e.target.value) : setEmail(e.target.value)} 
                            placeholder={activeTab === 'login' ? "Email or Phone Number" : "Email Address"}
                            className="w-full bg-[#13151a] text-white text-sm rounded-xl px-4 py-3.5 border border-gray-800 focus:border-[#00ff88] focus:ring-1 focus:ring-[#00ff88] outline-none transition-all placeholder-gray-600 font-medium"
                            required 
                        />
                    </div>

                    <div className="group">
                        <input 
                            type="password" 
                            value={activeTab === 'login' ? loginPassword : password} 
                            onChange={e => activeTab === 'login' ? setLoginPassword(e.target.value) : setPassword(e.target.value)} 
                            placeholder="Password" 
                            className="w-full bg-[#13151a] text-white text-sm rounded-xl px-4 py-3.5 border border-gray-800 focus:border-[#00ff88] focus:ring-1 focus:ring-[#00ff88] outline-none transition-all placeholder-gray-600 font-medium"
                            required 
                        />
                    </div>

                    <button 
                        type="submit" 
                        className="w-full py-4 mt-2 bg-[#00ff88] hover:bg-[#00cc6a] text-black font-black rounded-xl text-base shadow-[0_0_30px_rgba(0,255,136,0.3)] transition-all transform hover:scale-[1.02] active:scale-95 uppercase tracking-wide"
                    >
                        {activeTab === 'login' ? 'Log In' : 'Create Account'}
                    </button>
                </form>

                <div className="mt-6 text-center">
                    <button 
                        className="text-xs text-gray-500 hover:text-[#00ff88] transition-colors font-semibold"
                    >
                        {activeTab === 'login' ? "Forgot Password?" : "Already have an account? Log In"}
                    </button>
                </div>

            </div>
        </div>
    );
};

export default AuthModal;
