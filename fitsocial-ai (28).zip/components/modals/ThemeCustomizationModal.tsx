
import React, { useState, useRef } from 'react';
import { CustomTheme } from '../../types';

interface ThemeCustomizationModalProps {
    closeModal: () => void;
    setCustomTheme: (theme: CustomTheme | null) => void;
}

// 1. 50+ Solid Colors Palette
const solidColors: Omit<CustomTheme, 'type'>[] = [
    // Monochromes
    { value: '#000000', textColor: 'light' }, { value: '#111827', textColor: 'light' }, { value: '#1f2937', textColor: 'light' },
    { value: '#374151', textColor: 'light' }, { value: '#4b5563', textColor: 'light' }, { value: '#6b7280', textColor: 'light' },
    { value: '#9ca3af', textColor: 'dark' },  { value: '#d1d5db', textColor: 'dark' },  { value: '#f3f4f6', textColor: 'dark' },
    { value: '#ffffff', textColor: 'dark' },
    
    // Reds & Pinks
    { value: '#450a0a', textColor: 'light' }, { value: '#7f1d1d', textColor: 'light' }, { value: '#b91c1c', textColor: 'light' },
    { value: '#ef4444', textColor: 'light' }, { value: '#f87171', textColor: 'dark' },  { value: '#fecaca', textColor: 'dark' },
    { value: '#831843', textColor: 'light' }, { value: '#be185d', textColor: 'light' }, { value: '#ec4899', textColor: 'light' },
    { value: '#f472b6', textColor: 'dark' },  { value: '#fbcfe8', textColor: 'dark' },
    
    // Oranges & Yellows
    { value: '#431407', textColor: 'light' }, { value: '#7c2d12', textColor: 'light' }, { value: '#c2410c', textColor: 'light' },
    { value: '#f97316', textColor: 'light' }, { value: '#fdba74', textColor: 'dark' },  { value: '#ffedd5', textColor: 'dark' },
    { value: '#713f12', textColor: 'light' }, { value: '#a16207', textColor: 'light' }, { value: '#eab308', textColor: 'dark' },
    { value: '#fde047', textColor: 'dark' },  { value: '#fef9c3', textColor: 'dark' },

    // Greens & Teals
    { value: '#052e16', textColor: 'light' }, { value: '#14532d', textColor: 'light' }, { value: '#15803d', textColor: 'light' },
    { value: '#22c55e', textColor: 'light' }, { value: '#86efac', textColor: 'dark' },  { value: '#dcfce7', textColor: 'dark' },
    { value: '#042f2e', textColor: 'light' }, { value: '#0f766e', textColor: 'light' }, { value: '#14b8a6', textColor: 'light' },
    { value: '#5eead4', textColor: 'dark' },  { value: '#ccfbf1', textColor: 'dark' },

    // Blues
    { value: '#172554', textColor: 'light' }, { value: '#1e40af', textColor: 'light' }, { value: '#3b82f6', textColor: 'light' },
    { value: '#60a5fa', textColor: 'dark' },  { value: '#dbeafe', textColor: 'dark' },
    { value: '#082f49', textColor: 'light' }, { value: '#0369a1', textColor: 'light' }, { value: '#0ea5e9', textColor: 'light' },
    { value: '#7dd3fc', textColor: 'dark' },  { value: '#e0f2fe', textColor: 'dark' },

    // Purples & Violets
    { value: '#2e1065', textColor: 'light' }, { value: '#5b21b6', textColor: 'light' }, { value: '#7c3aed', textColor: 'light' },
    { value: '#a78bfa', textColor: 'light' }, { value: '#ddd6fe', textColor: 'dark' },  { value: '#4c1d95', textColor: 'light' },
];

// 2. Animated / Vibrant Gradients
const vibrantGradients: Omit<CustomTheme, 'type'>[] = [
    { value: 'linear-gradient(270deg, #ff9a9e 0%, #fecfef 99%, #fecfef 100%)', textColor: 'dark' },
    { value: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', textColor: 'light' },
    { value: 'linear-gradient(to top, #30cfd0 0%, #330867 100%)', textColor: 'light' },
    { value: 'linear-gradient(to right, #4facfe 0%, #00f2fe 100%)', textColor: 'dark' },
    { value: 'linear-gradient(to right, #43e97b 0%, #38f9d7 100%)', textColor: 'dark' },
    { value: 'linear-gradient(to right, #fa709a 0%, #fee140 100%)', textColor: 'dark' },
    { value: 'linear-gradient(to top, #5f72bd 0%, #9b23ea 100%)', textColor: 'light' },
    { value: 'linear-gradient(to top, #09203f 0%, #537895 100%)', textColor: 'light' },
    { value: 'linear-gradient(-20deg, #2b5876 0%, #4e4376 100%)', textColor: 'light' },
    { value: 'linear-gradient(to right, #f83600 0%, #f9d423 100%)', textColor: 'light' },
    { value: 'radial-gradient(circle at 50% -20%, #1a1a2e 0%, #16213e 40%, #0f3460 100%)', textColor: 'light' },
    { value: 'linear-gradient(109.6deg, rgba(0, 0, 0, 0.93) 11.2%, rgb(63, 61, 61) 78.9%)', textColor: 'light' },
    { value: 'linear-gradient(to top, #00c6fb 0%, #005bea 100%)', textColor: 'light' },
    { value: 'linear-gradient(to top, #9be15d 0%, #00e3ae 100%)', textColor: 'dark' },
    { value: 'linear-gradient(to right, #243949 0%, #517fa4 100%)', textColor: 'light' },
    { value: 'linear-gradient(180deg, #2D2F33 0%, #1C1E22 100%)', textColor: 'light' }, // Dark Sleek
    { value: 'conic-gradient(from 180deg at 50% 50%, #FF6B6B 0deg, #FFD93D 120deg, #6BCB77 240deg, #4D96FF 360deg)', textColor: 'dark' }, // Rainbow
];

// Helper for SVGs
const createSvgPattern = (path: string, color = '255,255,255') => 
    `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='rgba(${color},0.15)' fill-rule='evenodd'%3E%3Cpath d='${path}' /%3E%3C/g%3E%3C/svg%3E")`;

// 3. Telegram Style Patterns
const patternWallpapers: Omit<CustomTheme, 'type'>[] = [
    // 1. The Requested "Green with Tiny Cats"
    { 
        value: `url("data:image/svg+xml,%3Csvg width='52' height='26' viewBox='0 0 52 26' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23064e3b' fill-opacity='0.2'%3E%3Cpath d='M10 10c0-2.21-1.79-4-4-4-3.314 0-6-2.686-6-6h2c0 2.21 1.79 4 4 4 3.314 0 6 2.686 6 6 0 2.21 1.79 4 4 4 3.314 0 6 2.686 6 6 0 2.21 1.79 4 4 4v2c-3.314 0-6-2.686-6-6 0-2.21-1.79-4-4-4-3.314 0-6-2.686-6-6zm25.464-1.95l8.486 8.486-1.414 1.414-8.486-8.486 1.414-1.414z' /%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`, 
        backgroundColor: '#10b981', // Emerald 500
        backgroundSize: '40px',
        textColor: 'light' 
    },
    // Gym / Dumbbells
    { 
        value: createSvgPattern('M20 20h20v20H20V20zM0 0h20v20H0V0z'),
        backgroundColor: '#111827', 
        textColor: 'light' 
    },
    // Pizza & Food (Red)
    { 
        value: `url("data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Ccircle cx='2' cy='2' r='2' fill='rgba(255,255,255,0.2)'/%3E%3C/svg%3E")`,
        backgroundColor: '#b91c1c', 
        textColor: 'light' 
    },
    // Blueprint (Blue)
    { 
        value: `radial-gradient(circle, #3b82f6 1px, transparent 1px)`,
        backgroundColor: '#1e3a8a', 
        backgroundSize: '20px 20px',
        textColor: 'light' 
    },
    // Honeycomb (Yellow)
    { 
        value: `url("data:image/svg+xml,%3Csvg width='56' height='100' viewBox='0 0 56 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M28 66L0 50L0 16L28 0L56 16L56 50L28 66L28 100' fill='none' stroke='rgba(0,0,0,0.1)' stroke-width='2'/%3E%3C/svg%3E")`,
        backgroundColor: '#fbbf24', 
        textColor: 'dark' 
    },
    // Clouds (Sky Blue)
    { 
        value: createSvgPattern('M10 10a5 5 0 1 1 0-10 5 5 0 0 1 0 10zm25 25a5 5 0 1 1 0-10 5 5 0 0 1 0 10z'),
        backgroundColor: '#38bdf8', 
        textColor: 'dark' 
    },
    // Cyber Grid
    {
        value: 'linear-gradient(transparent 95%, #ec4899 95%), linear-gradient(90deg, transparent 95%, #ec4899 95%)',
        backgroundColor: '#111',
        backgroundSize: '30px 30px',
        textColor: 'light'
    },
    // Cute Pink
    {
        value: `radial-gradient(circle at 50% 50%, rgba(255,255,255,0.2) 20%, transparent 20%)`,
        backgroundColor: '#f472b6',
        backgroundSize: '30px 30px',
        textColor: 'dark'
    }
];


const ThemeCustomizationModal: React.FC<ThemeCustomizationModalProps> = ({ closeModal, setCustomTheme }) => {
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [isLoading, setIsLoading] = useState(false);

    const handleOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
        if (e.target === e.currentTarget) closeModal();
    };
    
    const getImageTextColor = (imageUrl: string): Promise<'light' | 'dark'> => {
        return new Promise((resolve, reject) => {
          const img = new Image();
          img.crossOrigin = 'Anonymous';
          img.onload = () => {
            const canvas = document.createElement('canvas');
            canvas.width = img.width;
            canvas.height = img.height;
            const ctx = canvas.getContext('2d');
            if (!ctx) {
              reject('Could not get canvas context');
              return;
            }
            ctx.drawImage(img, 0, 0);
            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            const data = imageData.data;
            let r = 0, g = 0, b = 0, count = 0;
            const skip = 20; 
            for (let i = 0; i < data.length; i += 4 * skip) {
              r += data[i];
              g += data[i + 1];
              b += data[i + 2];
              count++;
            }
            const avgBrightness = (r / count + g / count + b / count);
            resolve(avgBrightness > 128 ? 'dark' : 'light');
          };
          img.onerror = (err) => reject(err);
          img.src = imageUrl;
        });
    };
    
    const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        setIsLoading(true);
        const reader = new FileReader();
        reader.onload = async (event) => {
            const imageUrl = event.target?.result as string;
            try {
                const textColor = await getImageTextColor(imageUrl);
                setCustomTheme({ type: 'image', value: imageUrl, textColor });
            } catch (error) {
                console.error("Error analyzing image brightness:", error);
                setCustomTheme({ type: 'image', value: imageUrl, textColor: 'light' });
            } finally {
                setIsLoading(false);
            }
        };
        reader.readAsDataURL(file);
    };

    return (
        <div className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-0 md:p-4" onClick={handleOverlayClick}>
            <div className="bg-[#1E1E1E] w-full max-w-md h-full rounded-none md:rounded-2xl shadow-2xl flex flex-col animate-slideIn max-h-full md:max-h-[90vh]">
                <header className="flex items-center p-4 border-b border-gray-700 flex-shrink-0">
                    <h3 className="text-xl font-bold text-white flex-1">Customize Appearance</h3>
                    <button onClick={closeModal} className="text-gray-400 hover:text-white text-3xl">&times;</button>
                </header>
                <div className="flex-grow pt-4 space-y-6 overflow-y-auto p-4 scrollbar-thin scrollbar-thumb-gray-700">
                    
                    {/* Custom Image Section */}
                    <section>
                        <h4 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-3">Custom Image</h4>
                        <div className="grid grid-cols-2 gap-3">
                            <button onClick={() => fileInputRef.current?.click()} disabled={isLoading} className="bg-green-600 text-white font-semibold py-3 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center gap-2 disabled:bg-gray-500">
                                {isLoading ? (
                                    <div className="w-5 h-5 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
                                ) : (
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/></svg>
                                )}
                                Upload Image
                            </button>
                             <button onClick={() => setCustomTheme(null)} className="bg-gray-700 text-white font-semibold py-3 rounded-lg hover:bg-gray-600 transition-colors">
                                Reset to Default
                            </button>
                        </div>
                        <input type="file" ref={fileInputRef} onChange={handleImageUpload} accept="image/*" className="hidden"/>
                    </section>

                    {/* Pattern Wallpapers (Telegram Style) */}
                    <section>
                        <h4 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-3">Patterns & Textures</h4>
                        <div className="grid grid-cols-4 gap-3">
                            {patternWallpapers.map((pattern, index) => (
                                <button key={index} onClick={() => setCustomTheme({ type: 'pattern', ...pattern })}
                                    className="w-full aspect-square rounded-xl shadow-md transform transition-transform hover:scale-105 border border-white/10"
                                    style={{
                                        backgroundImage: pattern.value,
                                        backgroundColor: pattern.backgroundColor,
                                        backgroundSize: pattern.backgroundSize,
                                    }}
                                    aria-label={`Select pattern ${index + 1}`}
                                />
                            ))}
                        </div>
                    </section>

                    {/* Animated & Vibrant Gradients */}
                    <section>
                        <h4 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-3">Vibrant & Animated</h4>
                        <div className="grid grid-cols-4 gap-3">
                            {vibrantGradients.map((grad, index) => (
                                <button key={index} onClick={() => setCustomTheme({ type: 'pattern', ...grad })}
                                    className="w-full aspect-square rounded-xl shadow-md transform transition-transform hover:scale-105 border border-white/10"
                                    style={{ background: grad.value }}
                                    aria-label={`Select gradient ${index + 1}`}
                                />
                            ))}
                        </div>
                    </section>

                    {/* Solid Colors */}
                     <section>
                        <h4 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-3">Solid Colors</h4>
                        <div className="grid grid-cols-9 gap-2">
                            {solidColors.map((color, idx) => (
                                <button key={idx} onClick={() => setCustomTheme({ type: 'color', ...color })}
                                    className="w-full aspect-square rounded-full shadow-md transform transition-transform hover:scale-110 border border-white/10"
                                    style={{ backgroundColor: color.value }}
                                    aria-label={`Set background to ${color.value}`}
                                />
                            ))}
                        </div>
                    </section>
                </div>
            </div>
        </div>
    );
};

export default ThemeCustomizationModal;
