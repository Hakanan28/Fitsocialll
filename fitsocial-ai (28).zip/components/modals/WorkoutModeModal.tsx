
import React from 'react';
import { ModalType } from '../../types';

interface WorkoutModeModalProps {
    closeModal: () => void;
    isProUser: boolean;
    openModal: (modal: ModalType, data?: any) => void;
}

const WorkoutModeModal: React.FC<WorkoutModeModalProps> = ({ closeModal, isProUser, openModal }) => {
    
    const openFormAssistant = () => {
        if (isProUser) {
            closeModal();
            openModal(ModalType.HolographicForm);
        } else {
            openModal(ModalType.PremiumPitch);
        }
    };

    const handleEndWorkout = () => {
        closeModal();
        openModal(ModalType.CryptoRewards, {
            amount: 50,
            reason: "For completing your Chest & Triceps workout!"
        });
    };

    return (
        <div className="fixed inset-0 bg-[#121212] z-[150] flex flex-col animate-fadeIn">
            <header className="flex justify-between items-center p-4 border-b border-gray-700">
                <h2 className="text-xl font-bold text-white">Chest & Triceps</h2>
                <button onClick={handleEndWorkout} className="text-red-500 font-bold hover:text-red-400 transition-colors">End</button>
            </header>
            <div className="flex-1 p-6 text-center flex flex-col justify-center">
                <span className="text-sm font-semibold text-gray-400 uppercase">NEXT EXERCISE (1/5)</span>
                <h3 className="text-5xl font-extrabold text-green-400 my-4">Bench Press</h3>
                <div className="mt-8 space-y-4">
                    <div className="bg-[#1E1E1E] p-4 rounded-xl shadow-lg">
                        <h4 className="text-xl font-bold text-white">Set 1 / 3</h4>
                        <div className="bg-black/50 p-3 rounded-xl my-4 flex items-center justify-between border border-indigo-500/30">
                            <div className="flex items-center space-x-3"><span className="text-2xl animate-pulse">🎧</span><div><p className="text-xs font-bold text-indigo-400">Neural Music</p><p className="text-sm font-semibold text-white">Focus Mode: Alpha (10Hz)</p></div></div>
                            <div className="text-lg font-bold text-white">60 BPM</div>
                        </div>
                        <div className="flex justify-around items-center mt-3">
                            <div><label className="text-sm text-gray-400">Weight (kg)</label><input type="number" defaultValue="60" className="w-24 p-2 mt-1 bg-gray-700 text-white text-center rounded-xl"/></div>
                            <div><label className="text-sm text-gray-400">Reps</label><input type="number" defaultValue="10" className="w-24 p-2 mt-1 bg-gray-700 text-white text-center rounded-xl"/></div>
                        </div>
                    </div>
                </div>
                 <button className="w-full bg-red-600 text-white py-3 rounded-xl font-bold mt-6 flex items-center justify-center space-x-2 hover:bg-red-700 transition-colors transform hover:scale-105"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" x2="12" y1="19" y2="22"/></svg><span>Start Voice Logging</span></button>
                 <button onClick={openFormAssistant} className="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold mt-4 flex items-center justify-center space-x-2 hover:bg-indigo-700 transition-colors transform hover:scale-105"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 7V5a2 2 0 0 1 2-2h2"/><path d="M17 3h2a2 2 0 0 1 2 2v2"/><path d="M21 17v2a2 2 0 0 1-2 2h-2"/><path d="M7 21H5a2 2 0 0 1-2-2v-2"/><path d="M8 11a2 2 0 0 0-2 2v1"/><path d="M18 11a2 2 0 0 1-2 2v1"/><path d="M12 11v2"/><path d="M9 17h6"/></svg><span>Check My Form (AI) <span className="text-xs bg-indigo-300 text-black font-bold px-1 py-0.5 rounded">PRO</span></span></button>
            </div>
            <footer className="p-4"><button className="w-full bg-green-500 text-white py-4 rounded-xl font-extrabold text-xl hover:bg-green-600 transition-colors transform hover:scale-105">Complete Set (1/3)</button></footer>
        </div>
    );
};

export default WorkoutModeModal;
