import React, { useState } from 'react';
import { UserProfile } from '../../types';

interface FollowListModalProps {
    closeModal: () => void;
    type: 'followers' | 'following';
    profile: UserProfile;
    allUsers: UserProfile[];
    currentUser: UserProfile;
    handleToggleFollow: (username: string) => void;
    viewUserProfile: (user: UserProfile) => void;
}

const FollowListModal: React.FC<FollowListModalProps> = ({ closeModal, type, profile, allUsers, currentUser, handleToggleFollow, viewUserProfile }) => {
    
    const [activeList, setActiveList] = useState<'followers' | 'following'>(type);

    const followerUsernames = allUsers
        .filter(user => user.following.includes(profile.username))
        .map(user => user.username);
    
    const followingUsernames = profile.following;

    const userListUsernames = activeList === 'followers' ? followerUsernames : followingUsernames;

    const userListProfiles = userListUsernames
        .map(username => allUsers.find(u => u.username === username))
        .filter((u): u is UserProfile => u !== undefined);
    
    const handleOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
        if (e.target === e.currentTarget) {
            closeModal();
        }
    };

    return (
        <div className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-0" onClick={handleOverlayClick}>
            <div className="bg-[#1E1E1E] w-full max-w-md h-full md:h-[70vh] md:max-h-[600px] rounded-none md:rounded-2xl shadow-2xl flex flex-col animate-slideIn">
                <header className="flex-shrink-0 flex flex-col justify-center items-center pt-4 border-b border-gray-700 relative">
                    <h3 className="text-xl font-bold text-white mb-3">{profile.username}</h3>
                    <div className="w-full flex">
                        <button onClick={() => setActiveList('followers')} className={`flex-1 py-3 text-sm font-semibold border-b-2 transition-colors ${activeList === 'followers' ? 'text-white border-white' : 'text-gray-500 border-transparent'}`}>
                            {followerUsernames.length} Followers
                        </button>
                         <button onClick={() => setActiveList('following')} className={`flex-1 py-3 text-sm font-semibold border-b-2 transition-colors ${activeList === 'following' ? 'text-white border-white' : 'text-gray-500 border-transparent'}`}>
                            {followingUsernames.length} Following
                        </button>
                    </div>
                    <button onClick={closeModal} className="absolute top-1/2 -translate-y-1/2 right-4 text-gray-400 hover:text-white text-2xl">&times;</button>
                </header>
                <div className="flex-1 p-2 space-y-2 overflow-y-auto">
                    {userListProfiles.length > 0 ? (
                        userListProfiles.map(user => {
                            const isCurrentUserFollowingThisUser = currentUser.following.includes(user.username);
                            const isThisUserFollowingCurrentUser = user.following.includes(currentUser.username);
                            const isOwnProfile = currentUser.username === user.username;
                            
                            let button = null;
                            if (!isOwnProfile) {
                                if (isCurrentUserFollowingThisUser) {
                                    button = (
                                        <button 
                                            onClick={() => handleToggleFollow(user.username)}
                                            className="text-sm font-semibold px-4 py-1.5 rounded-lg transition-all duration-200 bg-gray-700 text-white hover:bg-red-600/20 hover:border-red-500 hover:text-red-400 border border-gray-600"
                                        >
                                            Following
                                        </button>
                                    );
                                } else if (isThisUserFollowingCurrentUser) {
                                    button = (
                                         <button 
                                            onClick={() => handleToggleFollow(user.username)}
                                            className="text-sm font-semibold px-4 py-1.5 rounded-lg transition-all duration-200 bg-blue-600 text-white hover:bg-blue-500"
                                        >
                                            Follow Back
                                        </button>
                                    );
                                } else {
                                    button = (
                                        <button 
                                            onClick={() => handleToggleFollow(user.username)}
                                            className="text-sm font-semibold px-4 py-1.5 rounded-lg transition-all duration-200 bg-green-500 text-white hover:bg-green-600"
                                        >
                                            Follow
                                        </button>
                                    );
                                }
                            }

                            return (
                                <div key={user.username} className="flex items-center p-3 hover:bg-gray-700 rounded-xl transition-colors">
                                    <div onClick={() => viewUserProfile(user)} className="flex items-center flex-1 cursor-pointer overflow-hidden">
                                        <img className="w-10 h-10 rounded-full object-cover flex-shrink-0" src={user.avatarImage} alt={user.username} />
                                        <div className="ml-3 overflow-hidden">
                                            <h4 className="font-bold text-white truncate">{user.username}</h4>
                                            <p className="text-xs text-gray-400 truncate">{user.bio || 'FitSocial User'}</p>
                                        </div>
                                    </div>
                                    <div className="ml-2">
                                        {button}
                                    </div>
                                </div>
                            );
                        })
                    ) : (
                        <p className="text-center text-gray-500 pt-10">No users to show.</p>
                    )}
                </div>
            </div>
        </div>
    );
};

export default FollowListModal;