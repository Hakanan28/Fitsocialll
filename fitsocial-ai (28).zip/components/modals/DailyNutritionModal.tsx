
import React from 'react';
import Modal from '../ui/Modal';
import { FoodLogEntry } from '../../types';

interface DailyNutritionModalProps {
    closeModal: () => void;
    foodLog: FoodLogEntry[];
    date: string;
    totalMacros: { cal: number, pro: number, carb: number, fat: number };
    goals: { cal: number, pro: number, carb: number, fat: number };
}

const DailyNutritionModal: React.FC<DailyNutritionModalProps> = ({ closeModal, foodLog, date, totalMacros, goals }) => {
    
    // Group foods by meal type
    const groupedMeals = {
        Breakfast: foodLog.filter(f => f.mealType === 'Breakfast' || f.mealType === 'Kahvaltı'),
        Lunch: foodLog.filter(f => f.mealType === 'Lunch' || f.mealType === 'Öğle Yemeği'),
        Dinner: foodLog.filter(f => f.mealType === 'Dinner' || f.mealType === 'Akşam Yemeği'),
        Snack: foodLog.filter(f => !['Breakfast', 'Kahvaltı', 'Lunch', 'Öğle Yemeği', 'Dinner', 'Akşam Yemeği'].includes(f.mealType))
    };

    const getMealTotals = (items: FoodLogEntry[]) => {
        return items.reduce((acc, item) => ({
            cal: acc.cal + item.calories,
            pro: acc.pro + (item.macros?.pro || 0),
            carb: acc.carb + (item.macros?.carb || 0),
            fat: acc.fat + (item.macros?.fat || 0)
        }), { cal: 0, pro: 0, carb: 0, fat: 0 });
    };

    const renderMealSection = (title: string, items: FoodLogEntry[]) => {
        if (items.length === 0) return null;
        const totals = getMealTotals(items);

        return (
            <div className="bg-[#1E1E1E] rounded-xl p-4 mb-4 border border-gray-700">
                <div className="flex justify-between items-center mb-3 border-b border-gray-700 pb-2">
                    <h3 className="font-bold text-lg text-white">{title}</h3>
                    <span className="text-sm font-bold text-green-400">{totals.cal.toFixed(0)} kcal</span>
                </div>
                <div className="space-y-3">
                    {items.map((item) => (
                        <div key={item.id} className="flex justify-between items-start">
                            <div>
                                <p className="text-white font-medium text-sm">{item.name}</p>
                                <p className="text-xs text-gray-400">
                                    P: {item.macros?.pro.toFixed(1)}g • C: {item.macros?.carb.toFixed(1)}g • F: {item.macros?.fat.toFixed(1)}g
                                </p>
                            </div>
                            <span className="text-sm text-gray-300">{item.calories.toFixed(0)}</span>
                        </div>
                    ))}
                </div>
            </div>
        );
    };

    return (
        <Modal title={`Nutrition: ${date}`} closeModal={closeModal} show={true}>
            <div className="space-y-6">
                {/* Summary Header */}
                <div className="bg-gradient-to-r from-green-900 to-teal-900 p-5 rounded-xl shadow-lg border border-green-500/30">
                    <h2 className="text-xl font-bold text-white mb-4 text-center">Daily Summary</h2>
                    <div className="grid grid-cols-4 gap-2 text-center">
                        <div>
                            <div className="text-xs text-gray-300 uppercase font-bold">Calories</div>
                            <div className="text-lg font-bold text-white">{totalMacros.cal.toFixed(0)}</div>
                            <div className="text-[10px] text-gray-400">/ {goals.cal}</div>
                        </div>
                        <div>
                            <div className="text-xs text-blue-300 uppercase font-bold">Protein</div>
                            <div className="text-lg font-bold text-white">{totalMacros.pro.toFixed(0)}g</div>
                            <div className="text-[10px] text-gray-400">/ {goals.pro}g</div>
                        </div>
                        <div>
                            <div className="text-xs text-orange-300 uppercase font-bold">Carbs</div>
                            <div className="text-lg font-bold text-white">{totalMacros.carb.toFixed(0)}g</div>
                            <div className="text-[10px] text-gray-400">/ {goals.carb}g</div>
                        </div>
                        <div>
                            <div className="text-xs text-yellow-300 uppercase font-bold">Fat</div>
                            <div className="text-lg font-bold text-white">{totalMacros.fat.toFixed(0)}g</div>
                            <div className="text-[10px] text-gray-400">/ {goals.fat}g</div>
                        </div>
                    </div>
                    <div className="mt-4 h-2 bg-gray-700 rounded-full overflow-hidden">
                        <div className="bg-green-400 h-full" style={{ width: `${Math.min((totalMacros.cal / goals.cal) * 100, 100)}%` }}></div>
                    </div>
                </div>

                {/* Meal Sections */}
                <div className="pb-4">
                    {renderMealSection("Breakfast 🍳", groupedMeals.Breakfast)}
                    {renderMealSection("Lunch 🥗", groupedMeals.Lunch)}
                    {renderMealSection("Dinner 🍲", groupedMeals.Dinner)}
                    {renderMealSection("Snacks & Other 🍎", groupedMeals.Snack)}
                    
                    {foodLog.length === 0 && (
                        <div className="text-center py-10 text-gray-500">
                            <span className="text-4xl block mb-2">🍽️</span>
                            No meals logged for this day.
                        </div>
                    )}
                </div>
            </div>
        </Modal>
    );
};

export default DailyNutritionModal;
