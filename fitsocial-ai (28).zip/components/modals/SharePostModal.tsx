
import React, { useState } from 'react';
import Modal from '../ui/Modal';
import { UserProfile, Post, Reel, NFT } from '../../types';

interface SharePostModalProps {
    closeModal: () => void;
    modalData: { content: Post | Reel | NFT };
    showNotification: (message: string, type?: 'success' | 'error') => void;
    users: UserProfile[];
    currentUser: UserProfile;
    onPostShared: (content: Post | Reel | NFT, recipientUsername: string) => void;
}

const SharePostModal: React.FC<SharePostModalProps> = ({ closeModal, modalData, showNotification, users, currentUser, onPostShared }) => {
    if (!modalData || !modalData.content) {
        console.error("SharePostModal opened without content.");
        return null;
    }
    const { content } = modalData;

    const [searchQuery, setSearchQuery] = useState('');
    const filteredUsers = users.filter(user =>
        user.username.toLowerCase().includes(searchQuery.toLowerCase()) && user.username !== currentUser.username
    );

    const handleInternalShare = (user: UserProfile) => {
        onPostShared(content, user.username);
        showNotification(`Post sent to ${user.username} via DM!`);
        closeModal();
    };

    const getAuthor = () => {
        if ('author' in content) return content.author;
        if ('user' in content) return content.user;
        if ('owner' in content) return content.owner.username;
        return 'Unknown';
    }

    const getMediaUrl = () => {
        if ('mediaUrl' in content) return content.mediaUrl;
        if ('videoSrc' in content) return content.videoSrc;
        if ('imageUrl' in content) return content.imageUrl;
        return '';
    }
    
    const author = getAuthor();
    const mediaUrl = getMediaUrl();

    const shareData = {
        title: `Check out this content by @${author} on FitSocial!`,
        text: `Check out this amazing content from @${author} on FitSocial!`,
        url: window.location.href, // In a real app, this would be a deep link to the post
    };

    const handleNativeShare = async () => {
        if (navigator.share) {
            try {
                await navigator.share(shareData);
                showNotification("Shared successfully!");
                closeModal();
            } catch (err) {
                console.log('Error sharing:', err);
            }
        } else {
            showNotification("Native sharing not supported on this browser.", "error");
        }
    };

    const handleCopyLink = () => {
        navigator.clipboard.writeText(shareData.url);
        showNotification("Link copied to clipboard!");
        closeModal();
    };

    const isVideo = mediaUrl?.endsWith('.mp4') || ('mediaType' in content && content.mediaType === 'video');

    return (
        <Modal title="Share" closeModal={closeModal} show={true}>
            <div className="space-y-6">
                {/* Content Preview */}
                <div className="flex items-center space-x-3 p-3 bg-gray-800/50 rounded-xl border border-white/5">
                    {isVideo ? (
                        <video src={mediaUrl} className="w-12 h-12 object-cover rounded-lg bg-black" muted loop />
                    ) : (
                        <img className="w-12 h-12 object-cover rounded-lg" src={mediaUrl} alt="Post preview" />
                    )}
                    <div>
                        <p className="text-xs text-gray-400 font-medium uppercase tracking-wide">Content by</p>
                        <p className="font-bold text-white text-lg">@{author}</p>
                    </div>
                </div>

                {/* External Sharing Options */}
                <div>
                    <h4 className="text-sm font-bold text-gray-400 mb-3 px-1">Share Externally</h4>
                    <div className="flex gap-4 justify-around">
                        {navigator.share && (
                            <button onClick={handleNativeShare} className="flex flex-col items-center gap-2 group">
                                <div className="w-14 h-14 rounded-full bg-indigo-600 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" x2="12" y1="2" y2="15"/></svg>
                                </div>
                                <span className="text-xs text-gray-300">System</span>
                            </button>
                        )}
                         <button onClick={handleCopyLink} className="flex flex-col items-center gap-2 group">
                            <div className="w-14 h-14 rounded-full bg-gray-700 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
                            </div>
                             <span className="text-xs text-gray-300">Copy</span>
                        </button>
                    </div>
                </div>

                <div className="border-t border-gray-700 my-4"></div>

                {/* Internal DM Share */}
                <div>
                    <h4 className="text-sm font-bold text-gray-400 mb-3 px-1">Send via Direct Message</h4>
                    <input 
                        type="search"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full pl-4 pr-4 py-2 mb-3 rounded-lg bg-gray-800 border-transparent text-white focus:bg-gray-700 focus:ring-1 focus:ring-green-500 placeholder-gray-500 transition-colors" 
                        placeholder="Search friends..." 
                    />
                    <div className="max-h-48 overflow-y-auto space-y-2 pr-2">
                        {filteredUsers.length > 0 ? filteredUsers.map(user => (
                            <div key={user.username} className="flex items-center p-2 bg-gray-800/50 rounded-lg hover:bg-gray-700 transition-colors">
                                <img src={user.avatarImage} alt={user.username} className="w-10 h-10 rounded-full object-cover mr-3" />
                                <span className="font-semibold text-white flex-1">{user.username}</span>
                                <button onClick={() => handleInternalShare(user)} className="bg-green-600 text-white font-bold py-1.5 px-4 rounded-lg text-xs hover:bg-green-500 transition-colors">
                                    Send
                                </button>
                            </div>
                        )) : (
                            <p className="text-center text-gray-500 py-4 text-sm">No friends found.</p>
                        )}
                    </div>
                </div>
            </div>
        </Modal>
    );
};

export default SharePostModal;
