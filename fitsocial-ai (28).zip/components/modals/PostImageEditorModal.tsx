import React, { useState, useRef, useEffect } from 'react';
import { FILTERS } from '../../utils/filters';
import { expandImageWithAi } from '../../services/geminiService';

interface PostImageEditorModalProps {
    closeModal: () => void;
    onSave: (data: { caption: string, mediaUrl: string, filter: string, mediaType: 'image', location?: string, taggedUsers?: string[] }) => void;
    modalData?: { mediaFile?: File };
}

type ToolType = 'filtre' | 'ayarla' | 'ai';

const PostImageEditorModal: React.FC<PostImageEditorModalProps> = ({ closeModal, onSave, modalData }) => {
    const [mediaFile] = useState<File | null>(modalData?.mediaFile || null);
    const [mediaPreview, setMediaPreview] = useState<string | null>(mediaFile ? URL.createObjectURL(mediaFile) : null);
    const [activeTool, setActiveTool] = useState<ToolType>('filtre');
    
    const [selectedFilter, setSelectedFilter] = useState('none');
    const [adjustments, setAdjustments] = useState({ brightness: 100, contrast: 100, saturation: 100 });
    
    const [caption, setCaption] = useState('');
    const [location, setLocation] = useState('');
    const [tags, setTags] = useState('');

    const [isExpanding, setIsExpanding] = useState(false);
    const [aiAnalysis, setAiAnalysis] = useState<{score: number, tip: string} | null>(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);

    const handleAiExpand = async () => {
        if (!mediaPreview || isExpanding) return;
        setIsExpanding(true);
        try {
            const expandedUrl = await expandImageWithAi(mediaPreview, 4 / 5);
            setMediaPreview(expandedUrl);
        } catch (error) {
            console.error("AI expansion failed:", error);
            // Optionally show a notification
        } finally {
            setIsExpanding(false);
        }
    };

    const handleAdjustmentChange = (key: keyof typeof adjustments, value: number) => {
        setAdjustments(prev => ({ ...prev, [key]: value }));
    };

    const generateAiAnalysis = () => {
        setIsAnalyzing(true);
        setTimeout(() => {
            setAiAnalysis({
                score: 88,
                tip: "Great lighting! Post at 18:00 for max engagement. Use #FitnessMotivation."
            });
            setIsAnalyzing(false);
        }, 1500);
    };

    const handleSubmit = () => {
        if (!mediaPreview) return;
        
        onSave({
            mediaUrl: mediaPreview,
            mediaType: 'image',
            filter: getFilterString(),
            caption,
            location,
            taggedUsers: tags.split(',').map(t => t.trim()).filter(Boolean)
        });
        closeModal();
    };

    const getFilterString = () => {
        const base = `brightness(${adjustments.brightness}%) contrast(${adjustments.contrast}%) saturate(${adjustments.saturation}%)`;
        return selectedFilter !== 'none' ? `${selectedFilter} ${base}` : base;
    };

    return (
        <div className="fixed inset-0 bg-[#0f0f0f] z-[200] flex flex-col animate-fadeIn font-sans text-white">
            
            <header className="flex justify-between items-center p-4 border-b border-white/10 bg-[#121212]">
                <button onClick={closeModal} className="text-red-500 font-bold text-sm hover:text-red-400">İptal</button>
                <h3 className="font-bold text-sm tracking-wide">Yeni Gönderi</h3>
                <button onClick={handleSubmit} className="text-blue-500 font-bold text-sm hover:text-blue-400">Paylaş</button>
            </header>

            <div className="flex-1 relative flex items-center justify-center bg-[#050505] overflow-hidden">
                <div className="relative max-h-full max-w-full aspect-auto shadow-2xl">
                    <img 
                        src={mediaPreview || ''} 
                        alt="Preview" 
                        className="max-h-[60vh] w-auto object-contain transition-all duration-200"
                        style={{ filter: getFilterString() }} 
                    />
                    {isExpanding && (
                        <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center z-10 backdrop-blur-sm">
                            <div className="w-8 h-8 border-4 border-gray-600 border-t-green-500 rounded-full animate-spin"></div>
                            <p className="text-xs text-green-400 mt-3 font-semibold animate-pulse">✨ AI expanding image...</p>
                        </div>
                    )}
                </div>
            </div>

            <div className="bg-[#121212] border-t border-white/10 pb-safe">
                <div className="h-40 p-4 border-b border-white/5 overflow-y-auto">
                    
                    {activeTool === 'filtre' && (
                        <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2">
                            {FILTERS.map(f => (
                                <button key={f.name} onClick={() => setSelectedFilter(f.filter)} className="flex flex-col items-center gap-2 flex-shrink-0 group">
                                    <div className={`w-20 h-20 rounded-md overflow-hidden border-2 transition-all ${selectedFilter === f.filter ? 'border-blue-500' : 'border-transparent group-hover:border-white/30'}`}>
                                        <img src={mediaPreview || ''} className="w-full h-full object-cover" style={{ filter: f.filter }} alt={f.name}/>
                                    </div>
                                    <span className={`text-[10px] font-semibold ${selectedFilter === f.filter ? 'text-blue-400' : 'text-gray-500'}`}>{f.name}</span>
                                </button>
                            ))}
                        </div>
                    )}

                    {activeTool === 'ayarla' && (
                        <div className="space-y-4 px-2">
                            <div className="flex items-center gap-3">
                                <span className="text-xs font-bold w-20 text-gray-400">Parlaklık</span>
                                <input type="range" min="50" max="150" value={adjustments.brightness} onChange={e => handleAdjustmentChange('brightness', Number(e.target.value))} className="flex-1 accent-white h-1 bg-gray-700 rounded-lg appearance-none cursor-pointer"/>
                            </div>
                            <div className="flex items-center gap-3">
                                <span className="text-xs font-bold w-20 text-gray-400">Kontrast</span>
                                <input type="range" min="50" max="150" value={adjustments.contrast} onChange={e => handleAdjustmentChange('contrast', Number(e.target.value))} className="flex-1 accent-white h-1 bg-gray-700 rounded-lg appearance-none cursor-pointer"/>
                            </div>
                            <div className="flex items-center gap-3">
                                <span className="text-xs font-bold w-20 text-gray-400">Dolgunluk</span>
                                <input type="range" min="0" max="200" value={adjustments.saturation} onChange={e => handleAdjustmentChange('saturation', Number(e.target.value))} className="flex-1 accent-white h-1 bg-gray-700 rounded-lg appearance-none cursor-pointer"/>
                            </div>
                        </div>
                    )}

                    {activeTool === 'ai' && (
                        <div className="flex flex-col items-center justify-center h-full text-center space-y-4">
                            <p className="text-xs text-gray-400 max-w-xs">Let AI expand your image to fit the post format perfectly without cropping.</p>
                            <button onClick={handleAiExpand} disabled={isExpanding} className="bg-gradient-to-r from-purple-500 to-indigo-500 text-white font-bold py-2 px-6 rounded-full shadow-lg hover:scale-105 transition-transform disabled:opacity-50">
                                {isExpanding ? 'Expanding...' : '✨ Magic Expand'}
                            </button>
                        </div>
                    )}
                </div>

                <div className="flex justify-around px-4 pt-2">
                    <ToolButton active={activeTool === 'filtre'} onClick={() => setActiveTool('filtre')} icon={<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="8" cy="8" r="6"/><circle cx="16" cy="16" r="6"/><path d="M12 12L12 12"/></svg>} label="Filtre" />
                    <ToolButton active={activeTool === 'ayarla'} onClick={() => setActiveTool('ayarla')} icon={<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/><circle cx="8" cy="6" r="2" fill="currentColor"/><circle cx="16" cy="12" r="2" fill="currentColor"/><circle cx="10" cy="18" r="2" fill="currentColor"/></svg>} label="Ayarla" />
                    <ToolButton active={activeTool === 'ai'} onClick={() => setActiveTool('ai')} icon={<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/></svg>} label="AI Genişlet" />
                </div>
            </div>
        </div>
    );
};

const ToolButton = ({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) => (
    <button onClick={onClick} className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-all ${active ? 'text-white' : 'text-gray-500 hover:text-gray-300'}`}>
        <div className={`p-1 rounded-full ${active ? '' : ''}`}>{icon}</div>
        <span className="text-[9px] font-bold uppercase tracking-wide">{label}</span>
    </button>
);

export default PostImageEditorModal;