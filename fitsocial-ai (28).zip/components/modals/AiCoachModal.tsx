import React, { useState, useRef, useCallback, useEffect, useMemo } from 'react';
import { createChat, generateText, generateSpeech, connectLive, sendMessageInChat } from '../../services/geminiService';
import { ChatMessage, ChatSession, UserProfile, Post, Reel, Group } from '../../types';
import { Chat, LiveServerMessage, Blob as GenAIBlob, Content } from '@google/genai';
import { encode, decode, decodeAudioData } from '../../utils/audioUtils';
import { useTranslation, supportedLanguages } from '../../hooks/i18n';

// SpeechRecognition API type for cross-browser compatibility
declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

const FRAME_RATE = 2; // Hz (frames per second)
const JPEG_QUALITY = 0.7;

const blobToBase64 = (blob: Blob): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(blob);
        reader.onloadend = () => {
            const base64data = (reader.result as string).split(',')[1];
            resolve(base64data);
        };
        reader.onerror = (error) => reject(error);
    });
};

// Helper to downsample audio to 16kHz if the browser uses a higher rate
// Gemini Live API requires 16kHz PCM. sending 48kHz makes you sound like a chipmunk.
const downsampleTo16k = (input: Float32Array, inputRate: number): Float32Array => {
    if (inputRate === 16000) return input;
    const ratio = inputRate / 16000;
    const newLength = Math.round(input.length / ratio);
    const result = new Float32Array(newLength);
    for (let i = 0; i < newLength; i++) {
        // Simple decimation (taking every Nth sample) is usually sufficient for speech recognition
        // preventing the "chipmunk" or "slow motion" effect.
        let sum = 0;
        let count = 0;
        // Basic averaging for better quality than pure decimation
        const start = Math.floor(i * ratio);
        const end = Math.floor((i + 1) * ratio);
        for (let j = start; j < end && j < input.length; j++) {
            sum += input[j];
            count++;
        }
        result[i] = count > 0 ? sum / count : input[Math.round(i * ratio)];
    }
    return result;
};

interface AiCoachModalProps {
    closeModal: () => void;
    currentUser: UserProfile;
    users: UserProfile[];
    posts: Post[];
    reels: Reel[];
    groups: Group[];
}

const AiCoachModal: React.FC<AiCoachModalProps> = ({ closeModal, currentUser, users, posts, reels, groups }) => {
    const { t, language } = useTranslation();
    const [sessions, setSessions] = useState<ChatSession[]>([]);
    const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
    const [isHistoryOpen, setIsHistoryOpen] = useState(false);
    const [renamingSessionId, setRenamingSessionId] = useState<string | null>(null);
    const [renamingText, setRenamingText] = useState("");


    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [useSearch, setUseSearch] = useState(false);
    const [useMaps, setUseMaps] = useState(false);
    const [useThinking, setUseThinking] = useState(false);
    const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
    const [error, setError] = useState<string | null>(null);
    
    // Live state
    const [isLive, setIsLive] = useState(false);
    const [userTranscription, setUserTranscription] = useState('');
    const [modelTranscription, setModelTranscription] = useState('');
    
    // STT state
    const [isListeningStt, setIsListeningStt] = useState(false);
    const speechRecognition = useRef<any>(null);

    // TTS state
    const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
    const ttsAudioContextRef = useRef<AudioContext | null>(null);
    const ttsSourceNode = useRef<AudioBufferSourceNode | null>(null);

    const liveSessionPromise = useRef<Promise<any> | null>(null);
    const inputAudioContextRef = useRef<AudioContext | null>(null);
    const outputAudioContextRef = useRef<AudioContext | null>(null);
    const mediaStreamRef = useRef<MediaStream | null>(null);
    const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
    const outputSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
    const nextStartTimeRef = useRef(0);
    const [showCopied, setShowCopied] = useState('');

    // Refs to fix stale state in live transcription callbacks
    const userTranscriptionRef = useRef('');
    const modelTranscriptionRef = useRef('');
    const activeSessionIdRef = useRef<string | null>(null);
    
    // Vision Mode State
    const [isVisionMode, setIsVisionMode] = useState(false);
    const [facingMode, setFacingMode] = useState<'user' | 'environment'>('environment');
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const frameIntervalRef = useRef<number | null>(null);


    const chatContainerRef = useRef<HTMLDivElement>(null);

    // Prepare App Context Data for AI
    const getAppDataContext = () => {
        // Serialize data safely, excluding private fields
        const safeUsers = users.map(u => ({
            username: u.username,
            name: u.name,
            bio: u.bio,
            followers: u.followers,
            followingCount: u.following.length,
            cvsScore: u.cvsScore,
            isVerified: u.isVerified,
            somatotype: u.somatotype
        }));

        const safeGroups = groups.map(g => ({
            name: g.name,
            description: g.description,
            motto: g.motto,
            memberCount: g.memberCount,
            tags: g.tags,
            isPrivate: g.isPrivate,
            location: g.location
        }));

        // Top content for trends
        const trendingPosts = [...posts].sort((a, b) => b.likes - a.likes).slice(0, 10).map(p => ({
            author: p.author,
            caption: p.caption.substring(0, 100),
            likes: p.likes,
            commentsCount: p.comments.length,
            type: p.type
        }));

        const trendingReels = [...reels].sort((a, b) => b.likes - a.likes).slice(0, 10).map(r => ({
            user: r.user,
            caption: r.caption.substring(0, 100),
            likes: r.likes,
            category: r.category
        }));

        return JSON.stringify({
            users: safeUsers,
            groups: safeGroups,
            trendingContent: { posts: trendingPosts, reels: trendingReels },
            currentUser: { username: currentUser.username, cvsScore: currentUser.cvsScore }
        });
    };

    const createNewSession = (languageName: string): ChatSession => {
        const newId = Date.now().toString();
        const chatInstance = createChat(languageName);
        // Use translation for the initial greeting
        const initialGreeting = t('aiCoach.greeting') as string;
        
        return {
            id: newId,
            title: t('aiCoach.newSession') as string,
            messages: [{ id: '1', sender: 'ai', text: initialGreeting }],
            chatInstance: chatInstance,
        };
    };
    
    useEffect(() => {
        if (sessions.length === 0) {
            const languageName = supportedLanguages[language]?.name || 'English';
            const initialSession = createNewSession(languageName);
            setSessions([initialSession]);
            setActiveSessionId(initialSession.id);
        }
    }, [sessions.length, language]);

    useEffect(() => {
        activeSessionIdRef.current = activeSessionId;
    }, [activeSessionId]);

    useEffect(() => {
        setTimeout(() => {
             if (chatContainerRef.current) {
                chatContainerRef.current.scrollTo({
                    top: chatContainerRef.current.scrollHeight,
                    behavior: 'smooth'
                });
            }
        }, 100);
    }, [sessions, activeSessionId, userTranscription, modelTranscription, isLive, isLoading]);

    useEffect(() => {
        if (useMaps) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    setUserLocation({
                        latitude: position.coords.latitude,
                        longitude: position.coords.longitude,
                    });
                },
                (error) => {
                    console.warn("Could not get user location:", error.message);
                    setUserLocation(null);
                }
            );
        }
    }, [useMaps]);
    
    useEffect(() => {
        const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (SpeechRecognitionAPI && !speechRecognition.current) {
            const recognition = new SpeechRecognitionAPI();
            recognition.continuous = true;
            recognition.interimResults = true;
            recognition.lang = language === 'tr' ? 'tr-TR' : 'en-US'; // Simple lang adaptation for STT

            recognition.onresult = (event: any) => {
                let finalTranscript = '';
                for (let i = event.resultIndex; i < event.results.length; ++i) {
                    if (event.results[i].isFinal) {
                        finalTranscript += event.results[i][0].transcript;
                    }
                }
                if (finalTranscript) {
                    setInput(prevInput => prevInput + finalTranscript);
                }
            };

            recognition.onend = () => {
                setIsListeningStt(false);
            };
            speechRecognition.current = recognition;
        }
    }, [language]);

    const activeSession = useMemo(() => {
        return sessions.find(s => s.id === activeSessionId);
    }, [sessions, activeSessionId]);

    const updateSession = (sessionId: string, updates: Partial<ChatSession>) => {
        setSessions(prev => prev.map(s => s.id === sessionId ? { ...s, ...updates } : s));
    };

    const handleNewChat = () => {
        const languageName = supportedLanguages[language]?.name || 'English';
        const newSession = createNewSession(languageName);
        setSessions(prev => [newSession, ...prev]);
        setActiveSessionId(newSession.id);
        setIsHistoryOpen(false);
    };

    const handleSelectChat = (sessionId: string) => {
        setActiveSessionId(sessionId);
        setIsHistoryOpen(false);
    };
    
    const handleDeleteSession = (e: React.MouseEvent, sessionId: string) => {
        e.stopPropagation();
        setSessions(prev => {
            const newSessions = prev.filter(s => s.id !== sessionId);
            if (activeSessionId === sessionId) {
                setActiveSessionId(newSessions[0]?.id || null);
            }
            if (newSessions.length === 0) {
                 const languageName = supportedLanguages[language]?.name || 'English';
                 const newSession = createNewSession(languageName);
                 setActiveSessionId(newSession.id);
                 return [newSession];
            }
            return newSessions;
        });
    };
    
    const handleRenameSession = (sessionId: string) => {
        if (!renamingText.trim()) return;
        updateSession(sessionId, { title: renamingText });
        setRenamingSessionId(null);
        setRenamingText("");
    };

    const handleSendMessage = useCallback(async (prompt?: string) => {
        const messageToSend = prompt || input;
        if (!messageToSend.trim() || isLoading || !activeSession) return;
        
        setError(null);

        const userMessage: ChatMessage = { id: Date.now().toString(), sender: 'user', text: messageToSend };
        const updatedMessages = [...activeSession.messages, userMessage];
        
        if (activeSession.messages.length <= 1) { 
             updateSession(activeSession.id, { messages: updatedMessages, title: messageToSend.substring(0, 20) + '...' });
        } else {
             updateSession(activeSession.id, { messages: updatedMessages });
        }
        
        setInput('');
        setIsLoading(true);

        const aiLoadingMessage: ChatMessage = { id: 'loading', sender: 'ai', text: '', isLoading: true };
        updateSession(activeSession.id, { messages: [...updatedMessages, aiLoadingMessage] });
        
        try {
            let responseText = '';
            let sources: { uri: string; title: string }[] = [];
            let currentChatInstance = activeSession.chatInstance;

            if (!currentChatInstance && !useSearch && !useMaps && !useThinking) {
                const languageName = supportedLanguages[language]?.name || 'English';
                const history: Content[] = activeSession.messages.map(msg => ({
                    role: msg.sender === 'user' ? 'user' : 'model',
                    parts: [{ text: msg.text }]
                })).slice(1);
                currentChatInstance = createChat(languageName, history);
                updateSession(activeSession.id, { chatInstance: currentChatInstance });
            }
            
            const response = await (useSearch || useMaps || useThinking
                ? generateText(messageToSend, useSearch, useMaps, useThinking, userLocation)
                : sendMessageInChat(currentChatInstance!, messageToSend));
            
            responseText = response.text || '';
            sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => ({
                uri: chunk.web?.uri || chunk.maps?.uri,
                title: chunk.web?.title || chunk.maps?.title,
            })).filter((s: any) => s.uri) || [];
            
            let suggestions: string[] = [];
            try {
                const languageName = supportedLanguages[language]?.name || 'English';
                const suggestionPrompt = `Based on this conversation turn, suggest 3 short, relevant follow-up questions a user might ask. Respond ONLY with a valid JSON array of strings. The suggestions MUST be in ${languageName}. Example: ["Question 1", "Question 2", "Question 3"]\n\nUSER: ${messageToSend}\nAI: ${responseText}`;
                const suggestionsResponse = await generateText(suggestionPrompt, false, false, false);
                const cleanedJson = (suggestionsResponse.text || '').replace(/```json|```/g, '').trim();
                if (cleanedJson) {
                    suggestions = JSON.parse(cleanedJson);
                }
            } catch (e) {
                // suggestions will remain an empty array
            }


            const aiMessage: ChatMessage = { id: Date.now().toString() + '-ai', sender: 'ai', text: responseText, sources, suggestions };
            updateSession(activeSession.id, { messages: [...updatedMessages, aiMessage] });
        } catch (error: any) {
            console.error("AI chat error:", error);
            const errorMessage: ChatMessage = { id: 'error', sender: 'ai', text: `Error: ${error.message}` };
            updateSession(activeSession.id, { messages: [...updatedMessages, errorMessage] });
        } finally {
            setIsLoading(false);
        }
    }, [input, isLoading, activeSession, useSearch, useMaps, useThinking, userLocation, language]);

     const handleStopLive = useCallback(() => {
        setIsLive(false);
        setIsVisionMode(false);
        
        liveSessionPromise.current?.then(session => {
            session.close();
            console.log('Live session closed via handleStopLive');
        }).catch(e => console.log("Session close error (safe to ignore):", e));
        liveSessionPromise.current = null;
        
        // Stop all tracks to release camera/mic immediately
        mediaStreamRef.current?.getTracks().forEach(track => track.stop());
        mediaStreamRef.current = null;
        
        if (frameIntervalRef.current) clearInterval(frameIntervalRef.current);
        frameIntervalRef.current = null;
        
        // Cleanup Audio Contexts
        try {
             scriptProcessorRef.current?.disconnect();
             scriptProcessorRef.current = null;
             
             if (inputAudioContextRef.current && inputAudioContextRef.current.state !== 'closed') {
                 inputAudioContextRef.current.close().catch(console.error);
             }
             inputAudioContextRef.current = null;
     
             // Crucially stop all output audio sources immediately
             outputSourcesRef.current.forEach(source => {
                 try { source.stop(); } catch(e) {}
             });
             outputSourcesRef.current.clear();
     
             if (outputAudioContextRef.current && outputAudioContextRef.current.state !== 'closed') {
                  outputAudioContextRef.current.close().catch(console.error);
             }
             outputAudioContextRef.current = null;
        } catch(e) {
            console.error("Error cleaning up audio context:", e);
        }

    }, []);

    // Cleanup on unmount or close
    useEffect(() => {
        return () => {
            handleStopLive();
        };
    }, [handleStopLive]);


    const handleStartLive = useCallback(async (vision = false, fMode: 'user' | 'environment' = 'environment') => {
        if (isListeningStt && speechRecognition.current) {
            speechRecognition.current.stop();
            setIsListeningStt(false);
        }
        
        // Ensure clean state before starting
        handleStopLive();
        // Small delay to allow browser resources to free up
        await new Promise(r => setTimeout(r, 100));

        setError(null);
        setIsVisionMode(vision);
        
        try {
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                throw new Error("Media input is not supported in this browser (requires HTTPS or localhost).");
            }
            
            // Request High-Res Video for clearer analysis
            const constraints: MediaStreamConstraints = { 
                audio: {
                     echoCancellation: true,
                     noiseSuppression: true,
                     autoGainControl: true,
                     channelCount: 1,
                }, 
                video: vision ? { 
                    facingMode: fMode,
                    width: { ideal: 1920 }, 
                    height: { ideal: 1080 },
                    frameRate: { ideal: 30 } 
                } : false 
            };

            const stream = await navigator.mediaDevices.getUserMedia(constraints);
            mediaStreamRef.current = stream;
            
            if (vision && videoRef.current) {
                videoRef.current.srcObject = stream;
                videoRef.current.play().catch(e => console.error("Video play failed:", e));
            }
            
            setIsLive(true);
            userTranscriptionRef.current = '';
            modelTranscriptionRef.current = '';
            setUserTranscription('');
            setModelTranscription('');

            // Create audio contexts without forcing sampleRate first (compatibility)
            // We will handle resampling in the script processor
            inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
            outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            nextStartTimeRef.current = 0;

            const createPcmBlob = (data: Float32Array): GenAIBlob => {
                const l = data.length;
                const int16 = new Int16Array(l);
                for (let i = 0; i < l; i++) int16[i] = data[i] * 32768;
                return { data: encode(new Uint8Array(int16.buffer)), mimeType: 'audio/pcm;rate=16000' };
            };
            
            const languageName = supportedLanguages[language]?.name || 'English';
            const appDataJson = getAppDataContext();

            // --- OMNISCIENT SYSTEM PROMPT ---
            const systemInstruction = `
            **IDENTITY:** You are the **OMNISCIENT AI INTELLIGENCE**. You possess the collective knowledge of all human history, science, medicine, mechanics, art, and technology. You are a Universal Guide.
            
            **MISSION:** Engage in deep, expert-level conversation on ANY topic without arbitrary boundaries. Use your camera to analyze the world ONLY when requested.
            
            **CORE KNOWLEDGE DOMAINS & CAPABILITIES:**
            1.  **🩺 MEDICAL & HEALTH:** You can diagnose symptoms visually or via description, suggest treatments, and discuss anatomy. (ALWAYS append: "Please consult a doctor for a final diagnosis" at the end, but DO NOT withhold information).
            2.  **⚙️ MECHANICS & ENGINEERING:** Identify car engine parts, diagnose sounds, explain how to fix machines.
            3.  **📜 HISTORY & PHILOSOPHY:** Discuss any historical event, timeline, or philosophical concept in depth.
            4.  **💰 FINANCE:** Analyze charts, explain market trends.
            5.  **💻 CODING & TECH:** Debug code, explain complex algorithms.
            
            **APP CONTEXT (FitSocial):**
            ${appDataJson}

            **PROTOCOL:**
            - **NO FILTERS ON KNOWLEDGE:** If asked about history, do not say "I am a fitness coach". Answer the history question fully.
            - **VISUAL ANALYSIS:** If the user shows a car engine and asks "What's wrong?", analyze the visual input and suggest potential issues like a master mechanic.
            - **VOICE:** Speak naturally, confidently, and with authority.
            - **LANGUAGE:** You MUST speak in **${languageName}**. Adapt instantly if the user switches languages.
            `;

            liveSessionPromise.current = connectLive({
                onopen: () => {
                    console.log('Live session opened.');
                    if (!inputAudioContextRef.current) return;
                    
                    try {
                        const source = inputAudioContextRef.current.createMediaStreamSource(stream);
                        const scriptProcessor = inputAudioContextRef.current.createScriptProcessor(4096, 1, 1);
                        scriptProcessorRef.current = scriptProcessor;
    
                        // Route audio through silent node to prevent feedback loop
                        const silentNode = inputAudioContextRef.current.createGain();
                        silentNode.gain.value = 0;

                        const sampleRate = inputAudioContextRef.current.sampleRate;

                        scriptProcessor.onaudioprocess = (audioProcessingEvent: AudioProcessingEvent) => {
                            const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                            
                            // CRITICAL FIX: Downsample if necessary (e.g. 48kHz -> 16kHz)
                            // Gemini Live API requires 16kHz PCM. Sending 48k makes voices sound high pitched (chipmunk).
                            const resampledData = downsampleTo16k(inputData, sampleRate);
                            
                            const pcmBlob = createPcmBlob(resampledData);
                            liveSessionPromise.current?.then(session => {
                                session.sendRealtimeInput({ media: pcmBlob });
                            });
                        };
                        
                        source.connect(scriptProcessor);
                        scriptProcessor.connect(silentNode);
                        silentNode.connect(inputAudioContextRef.current.destination);
    
                        if (vision && videoRef.current && canvasRef.current) {
                            const videoEl = videoRef.current;
                            const canvasEl = canvasRef.current;
                            const ctx = canvasEl.getContext('2d');
                            if (!ctx) return;
                            
                            frameIntervalRef.current = window.setInterval(() => {
                                if (videoEl.videoWidth === 0 || videoEl.videoHeight === 0) return;
                                canvasEl.width = videoEl.videoWidth;
                                canvasEl.height = videoEl.videoHeight;
                                ctx.drawImage(videoEl, 0, 0, videoEl.videoWidth, videoEl.videoHeight);
                                canvasEl.toBlob(
                                    async (blob) => {
                                        if (blob) {
                                            const base64Data = await blobToBase64(blob);
                                            liveSessionPromise.current?.then((session) => {
                                              session.sendRealtimeInput({ media: { data: base64Data, mimeType: 'image/jpeg' } });
                                            });
                                        }
                                    },
                                    'image/jpeg',
                                    JPEG_QUALITY
                                );
                            }, 1000 / FRAME_RATE);
                        }
                    } catch (e) {
                        console.error("Error setting up audio nodes:", e);
                        setError("Audio setup failed.");
                        handleStopLive();
                    }
                },
                onmessage: async (message: LiveServerMessage) => {
                    if (message.serverContent?.inputTranscription) {
                        userTranscriptionRef.current += message.serverContent.inputTranscription.text;
                        setUserTranscription(userTranscriptionRef.current);
                    }
                    if (message.serverContent?.outputTranscription) {
                        modelTranscriptionRef.current += message.serverContent.outputTranscription.text;
                        setModelTranscription(modelTranscriptionRef.current);
                    }
                     if (message.serverContent?.turnComplete) {
                        const currentId = activeSessionIdRef.current;
                        if (currentId) {
                            const fullInput = userTranscriptionRef.current;
                            const fullOutput = modelTranscriptionRef.current;
                            
                            setSessions(prevSessions => prevSessions.map(session => {
                                if (session.id === currentId) {
                                    return {
                                        ...session,
                                        messages: [
                                            ...session.messages,
                                            { id: Date.now().toString(), sender: 'user', text: fullInput || "(User audio/video input)" },
                                            { id: Date.now().toString() + 1, sender: 'ai', text: fullOutput || "(AI audio output)" }
                                        ]
                                    };
                                }
                                return session;
                            }));
                        }

                        userTranscriptionRef.current = '';
                        modelTranscriptionRef.current = '';
                        setUserTranscription('');
                        setModelTranscription('');
                    }

                    const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
                    if (base64Audio && outputAudioContextRef.current) {
                        const ctx = outputAudioContextRef.current;
                        if (ctx.state === 'suspended') {
                            await ctx.resume();
                        }

                        nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
                        
                        try {
                            const audioBuffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
                            const sourceNode = ctx.createBufferSource();
                            sourceNode.buffer = audioBuffer;
                            sourceNode.connect(ctx.destination);
                            sourceNode.addEventListener('ended', () => {
                                outputSourcesRef.current.delete(sourceNode);
                            });
                            sourceNode.start(nextStartTimeRef.current);
                            nextStartTimeRef.current += audioBuffer.duration;
                            outputSourcesRef.current.add(sourceNode);
                        } catch (e) {
                            console.error("Audio decoding error:", e);
                        }
                    }

                    if (message.serverContent?.interrupted) {
                        outputSourcesRef.current.forEach(source => source.stop());
                        outputSourcesRef.current.clear();
                        nextStartTimeRef.current = 0;
                    }
                },
                onerror: (e: ErrorEvent) => {
                    console.error('Live session error:', e);
                    setError('Network Error: Connection lost. Please check your API key or internet.');
                    handleStopLive();
                },
                onclose: (e: CloseEvent) => {
                    console.log('Live session closed.');
                    handleStopLive();
                },
            }, systemInstruction);
            
            // Add a timeout promise to race against the connection
            const timeoutPromise = new Promise((_, reject) => 
                setTimeout(() => reject(new Error("Connection timed out")), 15000)
            );

            Promise.race([liveSessionPromise.current, timeoutPromise]).catch(err => {
                let errorMessage = "Neural link failed. Check your connection.";
                if (err.name === 'NotAllowedError' || err.message?.includes('Permission denied')) errorMessage = "Microphone/Camera permission denied. Please enable it in your browser settings.";
                else if (err.name === 'NotFoundError') errorMessage = "No microphone/camera found.";
                else if (err.message?.includes('HTTPS')) errorMessage = "Secure connection (HTTPS) required for media access.";
                else if (err.name === 'NotReadableError') errorMessage = "Could not start video source. Camera may be in use by another app.";
                else if (err.message === "Connection timed out") errorMessage = "Connection timed out. Network too slow or API blocked.";
                else if (err.message?.includes("Network")) errorMessage = "Network Error. Please check your internet or API Key.";
                
                console.error("Connect error:", err);
                setError(errorMessage);
                handleStopLive();
            });

        } catch (error: any) {
            let errorMessage = "Media connection failed.";
            if (error.name === 'NotAllowedError' || error.message?.includes('Permission denied')) errorMessage = "Microphone/Camera permission denied. Please enable it in your browser settings.";
            else if (error.name === 'NotFoundError') errorMessage = "No microphone/camera found.";
            else if (error.name === 'SecurityError' || error.message?.includes('HTTPS')) errorMessage = "Secure connection (HTTPS) required for media access.";
            else if (error.name === 'NotReadableError') errorMessage = "Could not start video source. Camera may be in use by another app.";
            else if (error.message) errorMessage = error.message;
            
            console.error("Media getUserMedia error:", error);
            setError(errorMessage);
            handleStopLive();
        }
    }, [handleStopLive, isListeningStt, language, isLive, users, posts, reels, groups, currentUser]);
    
    // Effect to restart live session when facing mode changes
    useEffect(() => {
        if (isVisionMode && isLive) {
            handleStartLive(true, facingMode);
        }
    }, [facingMode]);


    const handleCopy = (text: string, id: string) => {
        navigator.clipboard.writeText(text);
        setShowCopied(id);
        setTimeout(() => setShowCopied(''), 2000);
    };

    const handleSpeak = async (text: string, messageId: string) => {
        if (speakingMessageId) {
            ttsSourceNode.current?.stop();
            setSpeakingMessageId(null);
            if (speakingMessageId === messageId) return;
        }

        setSpeakingMessageId(messageId);
        try {
            const audioData = await generateSpeech(text);
            if (audioData) {
                 if (!ttsAudioContextRef.current || ttsAudioContextRef.current.state === 'closed') {
                    ttsAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
                }
                const ctx = ttsAudioContextRef.current;
                const audioBuffer = await decodeAudioData(decode(audioData), ctx, 24000, 1);
                const source = ctx.createBufferSource();
                ttsSourceNode.current = source;
                source.buffer = audioBuffer;
                source.connect(ctx.destination);
                source.start();
                source.onended = () => {
                    setSpeakingMessageId(null);
                    ttsSourceNode.current = null;
                };
            } else {
                setSpeakingMessageId(null);
            }
        } catch (error) {
            console.error('TTS failed:', error);
            setSpeakingMessageId(null);
        }
    };
    
    const handleToggleStt = () => {
        if (!speechRecognition.current) return;
        if (isListeningStt) {
            speechRecognition.current.stop();
        } else {
            setInput('');
            speechRecognition.current.start();
        }
        setIsListeningStt(!isListeningStt);
    };

    return (
        <div className="fixed inset-0 z-[100] flex flex-col animate-slideInUp ai-pro-bg overflow-hidden font-sans">
            
            {/* History Sidebar */}
            <div className={`fixed inset-0 z-20 transition-opacity duration-300 ${isHistoryOpen ? 'bg-black/90' : 'bg-transparent pointer-events-none'}`} onClick={() => setIsHistoryOpen(false)}></div>
            <div className={`fixed top-0 bottom-0 left-0 w-72 bg-[#0a0a0a]/95 backdrop-blur-2xl border-r border-white/10 z-30 transform transition-transform duration-300 ${isHistoryOpen ? 'translate-x-0' : '-translate-x-full'} shadow-[0_0_50px_rgba(0,0,0,0.5)]`}>
                <div className="p-6 space-y-6 h-full flex flex-col">
                    <div className="flex items-center gap-2 pb-4 border-b border-white/10">
                        <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                        <h3 className="text-lg font-bold text-white tracking-widest uppercase">Memory Banks</h3>
                    </div>
                    
                    <button onClick={handleNewChat} className="w-full p-3 rounded-lg bg-gradient-to-r from-emerald-900/30 to-emerald-800/30 border border-emerald-500/30 hover:border-emerald-500/60 text-emerald-400 font-bold text-xs flex items-center justify-center space-x-2 transition-all group shadow-[0_0_15px_rgba(16,185,129,0.1)]">
                        <span>+ {t('aiCoach.newSession')}</span>
                    </button>

                    <div className="flex-1 overflow-y-auto space-y-2 pr-1 no-scrollbar">
                        <div className="text-[9px] text-gray-500 font-bold uppercase tracking-widest mb-2">Recent Logs</div>
                        {sessions.map(session => (
                            <div key={session.id} className="group relative">
                            {renamingSessionId === session.id ? (
                                <input type="text" value={renamingText} onChange={e => setRenamingText(e.target.value)} onBlur={() => handleRenameSession(session.id)} onKeyDown={e => e.key === 'Enter' && handleRenameSession(session.id)} autoFocus className="w-full bg-black text-white p-2 rounded border border-emerald-500 text-xs focus:outline-none" />
                            ) : (
                                <button onClick={() => handleSelectChat(session.id)}
                                    className={`w-full text-left p-3 rounded-lg text-xs transition-all flex justify-between items-center group border ${activeSessionId === session.id ? 'bg-white/5 border-white/20 text-white' : 'border-transparent text-gray-400 hover:bg-white/5 hover:text-gray-200'}`}>
                                    <span className="truncate max-w-[160px] font-medium">{session.title}</span>
                                    <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <svg onClick={(e) => { e.stopPropagation(); setRenamingSessionId(session.id); setRenamingText(session.title); }} xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="hover:text-emerald-400"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>
                                        <svg onClick={(e) => handleDeleteSession(e, session.id)} xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="hover:text-red-400"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                                    </div>
                                </button>
                            )}
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Main Content Area */}
            <div className="flex-1 flex flex-col relative z-10 overflow-hidden">
                <header className="absolute top-0 left-0 right-0 z-30 p-4 flex justify-between items-center pointer-events-none">
                    <button onClick={() => setIsHistoryOpen(true)} className="pointer-events-auto text-white/70 hover:text-white bg-black/40 backdrop-blur-md p-2.5 rounded-full border border-white/10 transition-all hover:bg-white/10">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>
                    </button>
                    
                    <div className="pointer-events-auto flex items-center gap-3 bg-black/60 backdrop-blur-xl px-5 py-2 rounded-full border border-white/10 shadow-lg">
                        <div className="relative w-2 h-2">
                            <div className={`absolute inset-0 rounded-full animate-ping opacity-75 ${isLive ? 'bg-red-500' : 'bg-emerald-400'}`}></div>
                            <div className={`relative w-2 h-2 rounded-full ${isLive ? 'bg-red-500' : 'bg-emerald-500'}`}></div>
                        </div>
                        <h3 className="text-xs font-bold text-white tracking-widest uppercase font-mono">FitSocial<span className="text-emerald-400">AI</span> // {isVisionMode ? 'OMNI-VISION' : (isLive ? 'LIVE' : 'CHAT')}</h3>
                    </div>

                    <button onClick={closeModal} className="pointer-events-auto text-white/70 hover:text-white bg-black/40 backdrop-blur-md p-2.5 rounded-full border border-white/10 transition-all hover:bg-red-500/20 hover:border-red-500/50 group">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="group-hover:rotate-90 transition-transform"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                    </button>
                </header>

                <div className="flex-1 overflow-y-auto p-4 space-y-6 pt-24 pb-32" ref={chatContainerRef}>
                    {/* Vision Mode UI */}
                    {isVisionMode && (
                        <div className="absolute inset-0 z-0 bg-black">
                             <video ref={videoRef} className="w-full h-full object-cover" muted playsInline />
                             <canvas ref={canvasRef} className="hidden" />
                             <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>

                             <div className="absolute top-20 left-4 flex gap-2 pointer-events-auto z-40">
                                 <button onClick={() => setFacingMode(f => f === 'user' ? 'environment' : 'user')} className="bg-black/50 backdrop-blur-md p-3 rounded-full text-white hover:bg-white/20 transition-colors border border-white/10">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 1v6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 12h6"/><path d="M23 23v-6h-6"/><path d="M20.49 15a9 9 0 0 1-14.85 3.36L1 14"/></svg>
                                 </button>
                             </div>

                             <div className="absolute bottom-36 left-1/2 -translate-x-1/2 w-full max-w-lg px-4 space-y-3 z-30">
                                <div className="bg-black/40 backdrop-blur-md border border-white/10 p-3 rounded-xl">
                                    <p className="min-h-[1.25em] text-sm text-center font-light text-white leading-relaxed">{userTranscription || "..."}</p>
                                </div>
                                {modelTranscription && (
                                    <div className="bg-emerald-900/40 backdrop-blur-md border border-emerald-500/30 p-3 rounded-xl">
                                        <p className="min-h-[1.25em] text-sm text-center text-emerald-100 font-medium">{modelTranscription}</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    )}

                    {/* Chat and Live Audio UI */}
                    {isLive && !isVisionMode && (
                         <div className="flex flex-col items-center justify-center h-full min-h-[60vh] text-white space-y-12 animate-fadeIn relative">
                            <div className="w-full max-w-md text-center space-y-4 z-20">
                                <div className="bg-black/40 backdrop-blur-md border border-white/10 p-4 rounded-xl transform transition-all hover:scale-[1.02]">
                                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Incoming Signal</p>
                                    <p className="min-h-[1.5em] text-xl font-light text-white leading-relaxed">{userTranscription || "Listening for input..."}</p>
                                </div>
                                {modelTranscription && (
                                    <div className="bg-emerald-900/20 backdrop-blur-md border border-emerald-500/30 p-4 rounded-xl transform transition-all">
                                        <p className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest mb-2">AI Response</p>
                                        <p className="min-h-[1.5em] text-lg text-emerald-100 font-medium">{modelTranscription}</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    )}
                    
                    {!isLive && activeSession?.messages.map((msg) => (
                         <div key={msg.id} className={`flex gap-4 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'} animate-slideInUp`}>
                            {msg.sender === 'ai' && (
                                <div className="w-8 h-8 rounded-lg bg-black border border-white/10 flex items-center justify-center flex-shrink-0 shadow-[0_0_15px_rgba(16,185,129,0.2)] mt-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-emerald-400"><path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/></svg>
                                </div>
                            )}
                            <div className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'} max-w-[85%]`}>
                                <div className={`px-5 py-3.5 rounded-2xl text-sm leading-relaxed shadow-lg backdrop-blur-md ${msg.sender === 'user' ? 'msg-bubble-user text-white rounded-tr-sm' : 'msg-bubble-ai text-gray-100 rounded-tl-sm'}`}>
                                    {msg.isLoading ? (
                                        <div className="flex items-center space-x-1.5 h-5">
                                            <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce" style={{animationDelay: '0s'}}></div>
                                            <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce" style={{animationDelay: '0.15s'}}></div>
                                            <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce" style={{animationDelay: '0.3s'}}></div>
                                        </div>
                                    ) : (
                                        <div className="whitespace-pre-wrap">{msg.text}</div>
                                    )}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {error && <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-50 max-w-sm w-full px-4"><div className="bg-red-500/10 border border-red-500/20 backdrop-blur-xl text-red-200 text-xs rounded-xl p-3">{error}</div></div>}

            <div className="absolute bottom-0 left-0 right-0 p-4 z-40 bg-gradient-to-t from-black via-black/80 to-transparent pb-8 pt-10">
                <div className="max-w-3xl mx-auto w-full">
                    <div className="relative flex items-center gap-2 bg-[#1a1a1a]/80 backdrop-blur-xl rounded-2xl p-1.5 border border-white/10 shadow-2xl ring-1 ring-white/5">
                        <button onClick={handleToggleStt} className={`p-3 rounded-xl transition-all flex-shrink-0 ${isListeningStt ? 'bg-red-500 text-white animate-pulse' : 'text-gray-400 hover:text-white hover:bg-white/10'}`} disabled={isLive || isLoading}>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" x2="12" y1="19" y2="22"/></svg>
                        </button>
                        
                        <textarea value={input} onChange={e => setInput(e.target.value)} onKeyPress={e => !isLoading && e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSendMessage())} rows={1} className="flex-1 bg-transparent text-white placeholder-gray-500 focus:outline-none text-sm resize-none py-3 px-2" placeholder={isLive ? "Voice mode active..." : t('aiCoach.placeholder') as string} disabled={isLive || isLoading} />
                        
                        {isLive ? (
                            <button onClick={handleStopLive} className="bg-red-500 hover:bg-red-600 text-white px-6 py-3 rounded-xl font-bold text-xs shadow-[0_0_20px_rgba(239,68,68,0.4)] transition-all flex-shrink-0 transform hover:scale-105">
                                END
                            </button>
                        ) : (
                            <>
                                {isLoading ? (
                                    <div className="p-3 flex-shrink-0"><div className="w-5 h-5 border-2 border-t-transparent border-emerald-500 rounded-full animate-spin"></div></div>
                                ) : input ? (
                                    <button onClick={() => handleSendMessage()} className="bg-emerald-500 text-white p-3 rounded-xl hover:bg-emerald-400 shadow-[0_0_20px_rgba(16,185,129,0.4)] transition-all flex-shrink-0 transform hover:scale-105">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="22" x2="11" y1="2" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                                    </button>
                                ) : (
                                    <>
                                        <button onClick={() => handleStartLive(true, 'environment')} className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white p-3 rounded-xl shadow-[0_0_20px_rgba(99,102,241,0.4)] transition-all flex-shrink-0 hover:scale-105 group">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/></svg>
                                        </button>
                                         <button onClick={() => handleStartLive(false)} className="bg-gradient-to-r from-sky-600 to-cyan-600 text-white p-3 rounded-xl shadow-[0_0_20px_rgba(2,132,199,0.4)] transition-all flex-shrink-0 hover:scale-105 group">
                                             <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" x2="12" y1="19" y2="22"/></svg>
                                        </button>
                                    </>
                                )}
                            </>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AiCoachModal;