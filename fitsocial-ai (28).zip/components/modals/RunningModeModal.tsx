import React, { useState, useEffect, useRef } from 'react';
import { ModalType } from '../../types';
import { generateText } from '../../services/geminiService';

interface RunningModeModalProps {
    closeModal: () => void;
    isProUser: boolean;
    openModal: (modal: ModalType, data?: any) => void;
}

const RunningModeModal: React.FC<RunningModeModalProps> = ({ closeModal, isProUser, openModal }) => {
    const [isRunning, setIsRunning] = useState(false);
    const [startTime, setStartTime] = useState<number | null>(null);
    const [elapsedTime, setElapsedTime] = useState(0);
    const [distance, setDistance] = useState(0); // Meters
    const [pace, setPace] = useState(0); // Minutes per km
    const [isFinishing, setIsFinishing] = useState(false);
    
    // GPS Data
    const [currentPos, setCurrentPos] = useState<{lat: number, lng: number} | null>(null);
    const [accuracy, setAccuracy] = useState<number>(0);
    const [altitude, setAltitude] = useState<number | null>(0);
    const [path, setPath] = useState<{lat: number, lng: number}[]>([]);
    const [gpsError, setGpsError] = useState<string | null>(null);
    
    // UI States
    const [isMapMode, setIsMapMode] = useState(true);
    const watchId = useRef<number | null>(null);

    // Helper: Haversine Distance
    const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
        const R = 6371e3; // metres
        const φ1 = lat1 * Math.PI/180;
        const φ2 = lat2 * Math.PI/180;
        const Δφ = (lat2-lat1) * Math.PI/180;
        const Δλ = (lon2-lon1) * Math.PI/180;

        const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
                Math.cos(φ1) * Math.cos(φ2) *
                Math.sin(Δλ/2) * Math.sin(Δλ/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return R * c;
    };

    // Timer Effect
    useEffect(() => {
        let interval: number;
        if (isRunning && startTime) {
            interval = window.setInterval(() => {
                setElapsedTime(Math.floor((Date.now() - startTime) / 1000));
            }, 1000);
        }
        return () => clearInterval(interval);
    }, [isRunning, startTime]);

    const startTracking = () => {
        setGpsError(null);
        
        if (!navigator.geolocation) {
            setGpsError("Geolocation not supported.");
            return;
        }

        // Request permission explicitly first
        navigator.geolocation.getCurrentPosition(
            (position) => {
                // Success - Start the run
                setIsRunning(true);
                setStartTime(Date.now());
                
                // Initial position
                const { latitude, longitude } = position.coords;
                setCurrentPos({ lat: latitude, lng: longitude });
                setPath([{ lat: latitude, lng: longitude }]);

                // Start Watching
                watchId.current = navigator.geolocation.watchPosition(
                    (pos) => {
                        const { latitude, longitude, accuracy, altitude } = pos.coords;
                        setAccuracy(accuracy);
                        setAltitude(altitude);

                        const newPoint = { lat: latitude, lng: longitude };
                        
                        setCurrentPos(prev => {
                            if (prev) {
                                const dist = calculateDistance(prev.lat, prev.lng, latitude, longitude);
                                // Filter tiny movements (GPS drift) based on accuracy
                                if (dist > 2 && accuracy < 30) { 
                                    setDistance(d => d + dist);
                                    setPath(p => [...p, newPoint]);
                                    
                                    // Update pace
                                    if (startTime) {
                                        const mins = (Date.now() - startTime) / 1000 / 60;
                                        const kms = (distance + dist) / 1000;
                                        if (kms > 0.05) setPace(mins / kms);
                                    }
                                }
                            }
                            return newPoint;
                        });
                    },
                    (err) => {
                        console.warn("GPS Watch Error:", err);
                        if (err.code === 1) setGpsError("Permission denied. Please enable location.");
                        else if (err.code === 2) setGpsError("Position unavailable. Checking GPS...");
                        else if (err.code === 3) setGpsError("Timeout. Retrying...");
                        // Safe string conversion to avoid object errors
                        else {
                            let msg = "Unknown error";
                            if (typeof err === 'string') msg = err;
                            else if (err instanceof Error) msg = err.message;
                            else if (err && typeof (err as any).message === 'string') msg = (err as any).message;
                            setGpsError(`GPS Error: ${msg}`);
                        }
                    },
                    { enableHighAccuracy: true, maximumAge: 0, timeout: 10000 }
                );
            },
            (err) => {
                console.error("Start Error:", err);
                let msg = "Unknown error";
                if (typeof err === 'string') msg = err;
                else if (err instanceof Error) msg = err.message;
                else if (err && typeof (err as any).message === 'string') msg = (err as any).message;
                setGpsError(`Location access required: ${msg}`);
            },
            { enableHighAccuracy: true }
        );
    };

    const stopTracking = () => {
        if (watchId.current !== null) {
            navigator.geolocation.clearWatch(watchId.current);
        }
        setIsRunning(false);
    };

    useEffect(() => {
        return () => {
            if (watchId.current !== null) navigator.geolocation.clearWatch(watchId.current);
        };
    }, []);

    const formatTime = (seconds: number) => {
        const h = Math.floor(seconds / 3600);
        const m = Math.floor((seconds % 3600) / 60);
        const s = seconds % 60;
        return h > 0 ? `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}` : `${m}:${s.toString().padStart(2, '0')}`;
    };

    const formatPace = (val: number) => {
        if (!isFinite(val) || val === 0) return "0:00";
        const mins = Math.floor(val);
        const secs = Math.round((val - mins) * 60);
        return `${mins}'${secs.toString().padStart(2, '0')}"`;
    };

    // Generate the finish summary image
    const handleFinish = async () => {
        stopTracking();
        setIsFinishing(true);
        
        let locationName = "Outdoor Run";
        
        // AI Reverse Geocoding
        if (currentPos) {
            try {
                // Use Google Maps Grounding to get precise location name
                const prompt = `Using Google Maps, identify the specific location name (Park, Neighborhood, or Landmark) for coordinates: ${currentPos.lat}, ${currentPos.lng}. Return ONLY the name. Keep it short.`;
                // Call generateText with useMaps=true
                const result = await generateText(prompt, false, true, false, { latitude: currentPos.lat, longitude: currentPos.lng });
                
                // Safely handle the response text
                if (result && typeof result.text === 'string') {
                    locationName = result.text.trim();
                }
            } catch (e) {
                console.error("Geocoding failed", e);
                locationName = `Lat: ${currentPos.lat.toFixed(4)}, Lng: ${currentPos.lng.toFixed(4)}`;
            }
        }

        const canvas = document.createElement('canvas');
        canvas.width = 1080;
        canvas.height = 1080;
        const ctx = canvas.getContext('2d');
        
        if(ctx) {
            // Background
            const grad = ctx.createLinearGradient(0,0,0,1080);
            grad.addColorStop(0, '#111827');
            grad.addColorStop(1, '#000000');
            ctx.fillStyle = grad;
            ctx.fillRect(0, 0, 1080, 1080);
            
            // Draw Path Visualization (Simple Projection)
            if (path.length > 1) {
                const lats = path.map(p => p.lat);
                const lngs = path.map(p => p.lng);
                const minLat = Math.min(...lats);
                const maxLat = Math.max(...lats);
                const minLng = Math.min(...lngs);
                const maxLng = Math.max(...lngs);
                const latSpan = maxLat - minLat || 0.0001;
                const lngSpan = maxLng - minLng || 0.0001;
                
                ctx.strokeStyle = '#10B981';
                ctx.lineWidth = 15;
                ctx.lineCap = 'round';
                ctx.lineJoin = 'round';
                ctx.shadowColor = '#10B981';
                ctx.shadowBlur = 20;
                
                ctx.beginPath();
                path.forEach((p, i) => {
                    const x = 100 + ((p.lng - minLng) / lngSpan) * 880;
                    const y = 900 - ((p.lat - minLat) / latSpan) * 600; // Invert Lat
                    if (i===0) ctx.moveTo(x, y);
                    else ctx.lineTo(x, y);
                });
                ctx.stroke();
            }

            // Stats Text
            ctx.shadowBlur = 0;
            ctx.fillStyle = '#FFFFFF';
            ctx.textAlign = 'center';
            
            ctx.font = 'bold 160px Inter';
            ctx.fillText(`${(distance/1000).toFixed(2)}`, 540, 400);
            
            ctx.font = 'bold 50px Inter';
            ctx.fillStyle = '#10B981';
            ctx.fillText('KILOMETERS', 540, 470);
            
            ctx.fillStyle = '#FFF';
            ctx.font = 'bold 80px Inter';
            ctx.fillText(formatTime(elapsedTime), 300, 800);
            ctx.fillText(formatPace(pace), 780, 800);
            
            ctx.fillStyle = '#6B7280';
            ctx.font = '30px Inter';
            ctx.fillText('DURATION', 300, 850);
            ctx.fillText('AVG PACE', 780, 850);
            
            // Location Label on Image
            ctx.font = 'bold 40px Inter';
            ctx.fillStyle = '#9CA3AF';
            ctx.fillText(`📍 ${locationName}`, 540, 950);
        }

        const blob = await new Promise<Blob | null>(r => canvas.toBlob(r));
        if (blob) {
            const url = URL.createObjectURL(blob);
            closeModal();
            openModal(ModalType.ProofOfWorkout, {
                initialMedia: url,
                initialActivity: 'Outdoor Run',
                initialDuration: {
                    hours: Math.floor(elapsedTime / 3600),
                    minutes: Math.floor((elapsedTime % 3600) / 60)
                },
                initialNotes: `Ran ${(distance/1000).toFixed(2)} km at ${locationName} with FitSocial! 🏃‍♂️💨 #Run #Fitness`,
                initialLocation: locationName // Pass real location
            });
        }
        setIsFinishing(false);
    };

    // Static map URL for iframe (OpenStreetMap)
    const getMapUrl = () => {
        if (!currentPos) return "";
        const { lat, lng } = currentPos;
        return `https://www.openstreetmap.org/export/embed.html?bbox=${lng-0.005},${lat-0.005},${lng+0.005},${lat+0.005}&layer=mapnik&marker=${lat},${lng}`;
    };

    return (
        <div className="fixed inset-0 bg-gray-900 z-[150] flex flex-col animate-fadeIn">
            {/* Header */}
            <header className="p-4 bg-black/50 backdrop-blur-md border-b border-white/10 flex justify-between items-center absolute top-0 w-full z-20">
                <div className="flex items-center gap-3">
                    <div className={`w-3 h-3 rounded-full ${isRunning ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}></div>
                    <div>
                        <h2 className="text-white font-bold leading-none">Outdoor Run</h2>
                        {isRunning && <span className="text-[10px] text-green-400 font-mono">GPS ACTIVE</span>}
                    </div>
                </div>
                <button onClick={closeModal} className="text-gray-400 hover:text-white p-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" x2="6" y1="6" y2="18"/><line x1="6" x2="18" y1="6" y2="18"/></svg>
                </button>
            </header>

            {/* Main Display */}
            <div className="flex-1 relative bg-black">
                {!isRunning ? (
                    <div className="absolute inset-0 flex flex-col items-center justify-center z-10 p-6">
                        <div className="w-32 h-32 bg-green-500/10 rounded-full flex items-center justify-center mb-6 animate-pulse">
                            <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#10B981" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
                        </div>
                        <h3 className="text-2xl font-bold text-white mb-2">Ready to Run?</h3>
                        <p className="text-gray-400 text-center mb-8 text-sm">We need your location to track distance and pace accurately.</p>
                        
                        {gpsError && (
                            <div className="bg-red-500/20 border border-red-500/50 text-red-200 p-3 rounded-lg text-xs mb-6 max-w-xs text-center">
                                {gpsError}
                            </div>
                        )}

                        <button 
                            onClick={startTracking}
                            className="bg-green-500 hover:bg-green-400 text-black font-bold py-4 px-12 rounded-full text-lg shadow-[0_0_30px_rgba(16,185,129,0.4)] transition-transform transform hover:scale-105 active:scale-95"
                        >
                            START TRACKING
                        </button>
                    </div>
                ) : (
                    <>
                        {/* Map Layer */}
                        {isMapMode && currentPos && (
                            <iframe 
                                src={getMapUrl()} 
                                className="w-full h-full opacity-60 grayscale invert"
                                frameBorder="0"
                                title="Map"
                            />
                        )}
                        
                        {/* Live Stats Overlay */}
                        <div className="absolute top-24 left-4 right-4 grid grid-cols-2 gap-2 pointer-events-none">
                            <div className="bg-black/60 backdrop-blur-md rounded-xl p-3 border border-white/10">
                                <p className="text-[10px] text-gray-400 uppercase font-bold">Latitude</p>
                                <p className="text-white font-mono text-sm">{currentPos?.lat.toFixed(6) || '--'}</p>
                            </div>
                            <div className="bg-black/60 backdrop-blur-md rounded-xl p-3 border border-white/10">
                                <p className="text-[10px] text-gray-400 uppercase font-bold">Longitude</p>
                                <p className="text-white font-mono text-sm">{currentPos?.lng.toFixed(6) || '--'}</p>
                            </div>
                            <div className="bg-black/60 backdrop-blur-md rounded-xl p-3 border border-white/10">
                                <p className="text-[10px] text-gray-400 uppercase font-bold">Accuracy</p>
                                <p className={`font-mono text-sm ${accuracy < 10 ? 'text-green-400' : accuracy < 30 ? 'text-yellow-400' : 'text-red-400'}`}>
                                    ±{accuracy.toFixed(1)}m
                                </p>
                            </div>
                            <div className="bg-black/60 backdrop-blur-md rounded-xl p-3 border border-white/10">
                                <p className="text-[10px] text-gray-400 uppercase font-bold">Altitude</p>
                                <p className="text-white font-mono text-sm">{altitude ? `${altitude.toFixed(1)}m` : '--'}</p>
                            </div>
                        </div>
                    </>
                )}
            </div>

            {/* Bottom Controller */}
            <div className="bg-[#1E1E1E] p-6 rounded-t-3xl border-t border-white/10 relative z-20 pb-10">
                <div className="w-12 h-1.5 bg-gray-700 rounded-full mx-auto mb-6"></div>
                
                <div className="grid grid-cols-3 gap-4 text-center mb-8">
                    <div>
                        <p className="text-xs text-gray-400 uppercase font-bold tracking-wider">Distance</p>
                        <p className="text-4xl font-black text-white font-mono mt-1">{(distance / 1000).toFixed(2)}</p>
                        <p className="text-xs text-gray-500">km</p>
                    </div>
                    <div className="border-l border-r border-white/10">
                        <p className="text-xs text-gray-400 uppercase font-bold tracking-wider">Time</p>
                        <p className="text-4xl font-black text-yellow-400 font-mono mt-1">{formatTime(elapsedTime)}</p>
                    </div>
                    <div>
                        <p className="text-xs text-gray-400 uppercase font-bold tracking-wider">Pace</p>
                        <p className="text-4xl font-black text-white font-mono mt-1">{formatPace(pace)}</p>
                        <p className="text-xs text-gray-500">/km</p>
                    </div>
                </div>

                {isRunning && (
                    <button 
                        onClick={handleFinish}
                        disabled={isFinishing}
                        className="w-full bg-red-600 hover:bg-red-500 text-white font-bold py-4 rounded-2xl text-lg shadow-lg transition-all active:scale-95 flex items-center justify-center gap-2 disabled:bg-gray-600"
                    >
                        {isFinishing ? (
                            <>
                                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                                SAVING...
                            </>
                        ) : (
                            <>
                                <div className="w-4 h-4 bg-white rounded-sm"></div>
                                FINISH & SHARE
                            </>
                        )}
                    </button>
                )}
            </div>
        </div>
    );
};

export default RunningModeModal;
