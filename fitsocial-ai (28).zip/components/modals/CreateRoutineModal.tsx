
import React, { useState } from 'react';
import Modal from '../ui/Modal';
import { ModalType, Exercise, RoutineExercise, WorkoutRoutine } from '../../types';
import { exercises } from '../../data/exercises';

interface CreateRoutineModalProps {
    closeModal: () => void;
    showNotification: (message: string, type?: 'success' | 'error') => void;
    openModal: (modal: ModalType, data?: any) => void;
    handleCreateRoutine: (routineData: Omit<WorkoutRoutine, 'id' | 'user' | 'savesCount' | 'likes' | 'comments' | 'isLiked' | 'rating' | 'ratingsCount'>) => void;
}

const CreateRoutineModal: React.FC<CreateRoutineModalProps> = ({ closeModal, showNotification, openModal, handleCreateRoutine }) => {
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [difficulty, setDifficulty] = useState<'Beginner' | 'Intermediate' | 'Advanced'>('Intermediate');
    const [duration, setDuration] = useState(45);
    const [tags, setTags] = useState('');
    const [addedExercises, setAddedExercises] = useState<RoutineExercise[]>([]);
    const [allowDownload, setAllowDownload] = useState(true);
    
    // Exercise Picker State within this modal to avoid closing/unmounting
    const [isSelectingExercise, setIsSelectingExercise] = useState(false);
    const [exerciseFilter, setExerciseFilter] = useState<'home' | 'gym'>('gym');
    const [muscleFilter, setMuscleFilter] = useState('All');

    const handleSaveAndShare = () => {
        if (!name.trim()) {
            showNotification("Please enter a name for your routine.", "error");
            return;
        }
        if (addedExercises.length === 0) {
            showNotification("Please add at least one exercise to your routine.", "error");
            return;
        }
        
        handleCreateRoutine({
            routineName: name,
            description: description || undefined,
            exercises: addedExercises,
            difficulty,
            duration,
            tags: tags.split(',').map(t => t.trim()).filter(Boolean),
            allowDownload,
        });
        closeModal();
    };
    
    const addExerciseToList = (exercise: Exercise) => {
        const newRoutineExercise: RoutineExercise = {
            exercise,
            sets: '3',
            reps: '8-12'
        };
        setAddedExercises(prev => [...prev, newRoutineExercise]);
        setIsSelectingExercise(false); // Return to main view
    };

    const handleUpdateField = (index: number, field: 'sets' | 'reps', value: string) => {
        setAddedExercises(prev => 
            prev.map((item, i) => i === index ? { ...item, [field]: value } : item)
        );
    };
    
    const handleRemoveExercise = (index: number) => {
        setAddedExercises(prev => prev.filter((_, i) => i !== index));
    }
    
    // -- Render Internal Exercise Picker --
    const renderExercisePicker = () => {
        const filteredExercises = exercises.filter(ex => 
            (muscleFilter === 'All' || ex.muscleGroup === muscleFilter) &&
            (ex.location === 'both' || ex.location === exerciseFilter)
        );

        return (
            <div className="flex flex-col h-[60vh]">
                <div className="flex justify-between items-center mb-4">
                     <button onClick={() => setIsSelectingExercise(false)} className="text-gray-400 hover:text-white flex items-center gap-1 text-sm">
                        ← Back
                    </button>
                    <h3 className="font-bold text-white">Select Exercise</h3>
                    <div className="w-10"></div>
                </div>
                
                <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
                    {['All', 'Chest', 'Back', 'Legs', 'Shoulders', 'Arms', 'Core', 'Cardio'].map(m => (
                        <button 
                            key={m} 
                            onClick={() => setMuscleFilter(m)}
                            className={`px-3 py-1 rounded-full text-xs font-bold whitespace-nowrap ${muscleFilter === m ? 'bg-green-500 text-white' : 'bg-gray-800 text-gray-400'}`}
                        >
                            {m}
                        </button>
                    ))}
                </div>

                 <div className="flex-1 overflow-y-auto space-y-2 pr-1">
                    {filteredExercises.map(exercise => (
                        <div 
                            key={exercise.id} 
                            onClick={() => addExerciseToList(exercise)}
                            className="flex items-center p-2 bg-gray-800 rounded-xl cursor-pointer hover:bg-gray-700 transition-colors"
                        >
                            <img src={exercise.thumbnailUrl} className="w-10 h-10 rounded object-cover bg-black mr-3" />
                            <div className="flex-1">
                                <h4 className="font-bold text-white text-sm">{exercise.name}</h4>
                                <p className="text-xs text-gray-500">{exercise.equipment}</p>
                            </div>
                            <button className="text-green-400 font-bold text-xl">+</button>
                        </div>
                    ))}
                </div>
            </div>
        )
    }

    return (
        <Modal title={isSelectingExercise ? "Library" : "📋 Build Routine"} closeModal={closeModal} show={true}>
            {isSelectingExercise ? renderExercisePicker() : (
                <div className="space-y-5 animate-fadeIn pb-2">
                    
                    {/* Header Info */}
                    <div className="bg-white/5 p-4 rounded-xl border border-white/5 space-y-4">
                        <div>
                            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Routine Name</label>
                            <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Titanium Chest"
                                className="w-full bg-transparent text-white text-lg font-bold placeholder-gray-600 border-b border-white/20 focus:border-white focus:outline-none transition-colors pb-1" />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Difficulty</label>
                                <select value={difficulty} onChange={e => setDifficulty(e.target.value as any)} className="w-full bg-black/30 text-white text-xs rounded-lg p-2 border border-white/10 focus:border-white/30 outline-none">
                                    <option>Beginner</option>
                                    <option>Intermediate</option>
                                    <option>Advanced</option>
                                </select>
                            </div>
                            <div>
                                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Duration (min)</label>
                                <input type="number" value={duration} onChange={e => setDuration(Number(e.target.value))} className="w-full bg-black/30 text-white text-xs rounded-lg p-2 border border-white/10 focus:border-white/30 outline-none font-mono" />
                            </div>
                        </div>
                    </div>

                    {/* Exercises List */}
                    <div>
                        <div className="flex justify-between items-center mb-2">
                            <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Sequence ({addedExercises.length})</h4>
                             <div className="flex bg-black/30 rounded-lg p-0.5 border border-white/10">
                                <button onClick={() => setExerciseFilter('home')} className={`px-3 py-1 rounded-md text-[10px] font-bold transition-all ${exerciseFilter === 'home' ? 'bg-white text-black' : 'text-gray-500'}`}>Home</button>
                                <button onClick={() => setExerciseFilter('gym')} className={`px-3 py-1 rounded-md text-[10px] font-bold transition-all ${exerciseFilter === 'gym' ? 'bg-white text-black' : 'text-gray-500'}`}>Gym</button>
                            </div>
                        </div>

                        <div className="space-y-2 max-h-60 overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-gray-700">
                            {addedExercises.map((item, index) => (
                                <div key={index} className="flex items-center gap-3 bg-[#1a1a1a] p-2 rounded-xl border border-white/5 hover:border-white/20 transition-colors group">
                                    <div className="font-mono text-gray-600 text-xs w-4 text-center">{index + 1}</div>
                                    <img src={item.exercise.thumbnailUrl} className="w-10 h-10 rounded-lg object-cover bg-black" />
                                    <div className="flex-1 min-w-0">
                                        <p className="text-xs font-bold text-white truncate">{item.exercise.name}</p>
                                        <p className="text-[10px] text-gray-500 truncate">{item.exercise.muscleGroup}</p>
                                    </div>
                                    <div className="flex gap-2">
                                        <input type="text" value={item.sets} onChange={e => handleUpdateField(index, 'sets', e.target.value)} className="w-10 bg-black border border-white/10 rounded text-center text-xs text-white py-1 focus:border-blue-500 outline-none" placeholder="Sets"/>
                                        <input type="text" value={item.reps} onChange={e => handleUpdateField(index, 'reps', e.target.value)} className="w-10 bg-black border border-white/10 rounded text-center text-xs text-white py-1 focus:border-blue-500 outline-none" placeholder="Reps"/>
                                    </div>
                                    <button onClick={() => handleRemoveExercise(index)} className="text-gray-600 hover:text-red-500 transition-colors px-1">
                                        &times;
                                    </button>
                                </div>
                            ))}
                            
                            <button onClick={() => setIsSelectingExercise(true)} className="w-full py-3 border-2 border-dashed border-gray-700 rounded-xl text-gray-500 text-xs font-bold hover:border-green-500 hover:text-green-500 transition-all flex items-center justify-center gap-2">
                                <span className="text-lg">+</span> Add Exercise
                            </button>
                        </div>
                    </div>

                    {/* Footer Options */}
                    <div className="pt-2 border-t border-white/10">
                        <div className="flex items-center gap-2 mb-4">
                            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Description</label>
                            <input type="text" value={description} onChange={e => setDescription(e.target.value)} placeholder="Brief workout notes..." className="flex-1 bg-transparent border-b border-gray-700 text-white text-xs py-1 focus:border-white outline-none"/>
                        </div>
                        
                        <button onClick={handleSaveAndShare} className="w-full bg-white text-black py-3 rounded-xl font-black text-sm uppercase tracking-widest shadow-lg hover:bg-gray-200 transition-all transform active:scale-95">
                            Publish Routine
                        </button>
                    </div>
                </div>
            )}
        </Modal>
    );
};

export default CreateRoutineModal;
