
import React, { useState } from 'react';
import { ProofOfWorkoutPost, UserProfile, ModalType } from '../../types';
import CommentsOverlay from '../ui/CommentsOverlay';

interface ProofOfWorkoutDetailModalProps {
    closeModal: () => void;
    post: ProofOfWorkoutPost;
    handleLikeProofOfWorkout: (id: string) => void;
    openModal: (modal: ModalType, data?: any) => void;
    onAddComment: (id: string, text: string) => void;
    viewUserProfile: (user: UserProfile) => void;
    users: UserProfile[];
    currentUser?: UserProfile;
}

// Pro Stat Box Component
const StatBox: React.FC<{ label: string; value: string; subValue?: string; icon: React.ReactNode; colorClass?: string }> = ({ label, value, subValue, icon, colorClass = 'text-white' }) => (
    <div className="bg-black/40 backdrop-blur-xl p-4 rounded-2xl border border-white/10 flex flex-col items-center justify-center text-center shadow-lg hover:bg-white/5 transition-colors group h-28">
        <div className="mb-2 opacity-80 group-hover:scale-110 transition-transform duration-300">
            {icon}
        </div>
        <p className="text-[10px] text-gray-400 uppercase font-bold tracking-widest mb-1">{label}</p>
        <p className={`text-lg font-black ${colorClass} leading-none`}>{value}</p>
        {subValue && <p className="text-[10px] text-gray-400 font-mono mt-1">{subValue}</p>}
    </div>
);

const ProofOfWorkoutDetailModal: React.FC<ProofOfWorkoutDetailModalProps> = ({
    closeModal,
    post,
    handleLikeProofOfWorkout,
    openModal,
    onAddComment,
    viewUserProfile,
    users,
    currentUser
}) => {
    const [showComments, setShowComments] = useState(false);

    const handleLike = (e: React.MouseEvent) => {
        e.stopPropagation();
        handleLikeProofOfWorkout(post.id);
    };

    const handleViewProfile = (e: React.MouseEvent) => {
        e.stopPropagation();
        viewUserProfile(post.user);
    };
    
    const handleCommentClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        setShowComments(true);
    };

    // Fallback current user if not passed (should be passed from App level for best practice)
    const effectiveCurrentUser = currentUser || post.user;

    // Dynamic color for effort
    const effortColor = post.effort >= 8 ? 'text-red-500' : post.effort >= 5 ? 'text-yellow-400' : 'text-emerald-400';
    const effortLabel = post.effort >= 8 ? 'Max Effort' : post.effort >= 5 ? 'Moderate' : 'Light';

    return (
        <div className="fixed inset-0 bg-black z-[200] flex flex-col animate-fadeIn">
            
            {/* Top Bar */}
            <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-center z-50 bg-gradient-to-b from-black/80 to-transparent pointer-events-none">
                <button 
                    onClick={closeModal} 
                    className="text-white drop-shadow-lg hover:scale-110 transition-transform p-2 rounded-full hover:bg-white/10 pointer-events-auto"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6"/></svg>
                </button>
                
                {post.isVerified && (
                    <div className="flex items-center gap-1.5 bg-emerald-500/20 backdrop-blur-md border border-emerald-500/50 px-3 py-1 rounded-full">
                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="#10B981" stroke="none"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
                        <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest">Verified Workout</span>
                    </div>
                )}
                <div className="w-8"></div> {/* Spacer for centering */}
            </div>

            {/* Main Media Area */}
            <div className="flex-1 relative w-full h-full bg-gray-900 flex items-center justify-center overflow-hidden" onClick={() => setShowComments(false)}>
                {post.mediaType === 'video' ? (
                    <video src={post.mediaUrl} className="w-full h-full object-cover" controls={false} autoPlay loop playsInline muted={false} />
                ) : (
                    <img src={post.mediaUrl} alt={post.activity} className="w-full h-full object-cover" />
                )}
                
                {/* Bottom Gradient for Readability */}
                <div className="absolute bottom-0 left-0 right-0 h-3/4 bg-gradient-to-t from-black via-black/60 to-transparent pointer-events-none"></div>

                {/* Right Side Actions (Instagram Style) */}
                <div className="absolute bottom-24 right-4 flex flex-col items-center gap-6 z-50 pointer-events-auto">
                    <button onClick={handleLike} className="flex flex-col items-center gap-1 group">
                        <div className="p-2 rounded-full group-active:scale-90 transition-transform">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill={post.isLiked ? "#ef4444" : "rgba(0,0,0,0.3)"} stroke={post.isLiked ? "#ef4444" : "white"} strokeWidth="2" className={`drop-shadow-lg ${post.isLiked ? 'scale-110' : ''}`}><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
                        </div>
                        <span className="text-xs font-bold text-white drop-shadow-md">{post.likes}</span>
                    </button>
                    
                    <button onClick={handleCommentClick} className="flex flex-col items-center gap-1 group">
                        <div className="p-2 rounded-full group-active:scale-90 transition-transform">
                            <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24" fill="rgba(0,0,0,0.3)" stroke="white" strokeWidth="2" className="drop-shadow-lg"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                        </div>
                        <span className="text-xs font-bold text-white drop-shadow-md">{post.comments.length}</span>
                    </button>

                    <button onClick={() => openModal(ModalType.SharePost, { mediaUrl: post.mediaUrl, author: post.user.username })} className="flex flex-col items-center gap-1 group">
                        <div className="p-2 rounded-full group-active:scale-90 transition-transform">
                            <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24" fill="rgba(0,0,0,0.3)" stroke="white" strokeWidth="2" className="drop-shadow-lg"><line x1="22" x2="11" y1="2" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                        </div>
                        <span className="text-xs font-bold text-white drop-shadow-md">Share</span>
                    </button>
                </div>

                {/* Bottom Info Overlay */}
                <div className="absolute bottom-0 left-0 right-0 p-6 pb-10 pointer-events-none z-40">
                    
                    {/* User Info */}
                    <div className="flex items-center gap-3 mb-4 pointer-events-auto w-fit" onClick={handleViewProfile}>
                        <div className="p-0.5 bg-gradient-to-tr from-yellow-400 to-purple-600 rounded-full">
                            <img src={post.user.avatarImage} className="w-10 h-10 rounded-full border-2 border-black" alt={post.user.username} />
                        </div>
                        <div className="flex flex-col">
                            <h3 className="text-white font-bold text-md leading-none shadow-black drop-shadow-md">{post.user.username}</h3>
                            <p className="text-gray-300 text-xs font-medium shadow-black drop-shadow-md mt-0.5">{post.activity}</p>
                        </div>
                        {!post.user.isVerified && (
                            <button className="ml-2 border border-white/30 bg-black/20 backdrop-blur-sm text-white text-[10px] font-bold px-3 py-1 rounded-lg hover:bg-white/20 transition-colors">Follow</button>
                        )}
                    </div>
                    
                    {post.notes && (
                        <p className="text-gray-200 text-sm leading-relaxed mb-6 line-clamp-2 shadow-black drop-shadow-md max-w-[80%]">{post.notes}</p>
                    )}

                    {/* 2x2 PRO GRID */}
                    <div className="grid grid-cols-2 gap-3 pointer-events-auto pr-16">
                        {/* Box 1: Duration */}
                        <StatBox 
                            label="Duration" 
                            value={`${post.duration.hours}h ${post.duration.minutes}m`} 
                            icon={<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-blue-400"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>}
                        />
                        
                        {/* Box 2: Intensity/Effort */}
                        <StatBox 
                            label="Intensity" 
                            value={`${post.effort}/10`} 
                            subValue={effortLabel}
                            icon={<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={effortColor}><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>}
                            colorClass={effortColor}
                        />
                        
                        {/* Box 3: Volume (Sets/Reps) */}
                        <StatBox 
                            label="Session Volume" 
                            value={post.sets ? `${post.sets} Sets` : "N/A"}
                            subValue={post.reps ? `${post.reps} Reps` : "Full Body"}
                            icon={<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-purple-400"><path d="M6 4h12"/><path d="M6 20h12"/><rect x="4" y="8" width="16" height="8" rx="2"/></svg>}
                        />
                        
                        {/* Box 4: Location/Zone */}
                        <StatBox 
                            label="Workout Zone" 
                            value={post.location || "Gym"} 
                            icon={<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-orange-400"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>}
                        />
                    </div>
                </div>
             </div>

             {/* Comments Overlay */}
             <CommentsOverlay 
                isOpen={showComments}
                onClose={() => setShowComments(false)}
                comments={post.comments}
                currentUser={effectiveCurrentUser}
                users={users}
                onAddComment={(text) => onAddComment(post.id, text)}
            />
        </div>
    );
};

export default ProofOfWorkoutDetailModal;
