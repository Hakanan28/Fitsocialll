import React, { useState } from 'react';
import Modal from '../ui/Modal';
import { generateWorkoutPlan } from '../../services/geminiService';
import { ModalType, UserProfile } from '../../types';
import { useTranslation, supportedLanguages } from '../../hooks/i18n';

interface AiWorkoutGeneratorModalProps {
    closeModal: () => void;
    openModal: (modal: ModalType, data?: any) => void;
    currentUser: UserProfile;
}

const AiWorkoutGeneratorModal: React.FC<AiWorkoutGeneratorModalProps> = ({ closeModal, openModal, currentUser }) => {
    const { t, language } = useTranslation();
    const [step, setStep] = useState(1);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    // Step 1 State
    const [primaryGoal, setPrimaryGoal] = useState('build_muscle');
    
    // Step 2 State
    const [fitnessLevel, setFitnessLevel] = useState('intermediate');
    const [gender, setGender] = useState<'male' | 'female'>('male');
    const [somatotype, setSomatotype] = useState('mesomorph');
    const [fatDistribution, setFatDistribution] = useState('apple');
    const [location, setLocation] = useState('gym');
    const [injuries, setInjuries] = useState('');
    const [height, setHeight] = useState(175);
    const [weight, setWeight] = useState(75);
    const [targetWeight, setTargetWeight] = useState(70);
    const [dateOfBirth, setDateOfBirth] = useState('1990-01-01');

    // Step 3 State
    const [daysPerWeek, setDaysPerWeek] = useState(4);
    const [durationPerSession, setDurationPerSession] = useState(60);

    // Step 4 State
    const [equipment, setEquipment] = useState<string[]>(["fullgym"]);

    const equipmentOptionsHome = [
        { key: "bodyweight", label: t('aiWorkoutGenerator.equipment.bodyweight') },
        { key: "dumbbells", label: t('aiWorkoutGenerator.equipment.dumbbells') },
        { key: "bands", label: t('aiWorkoutGenerator.equipment.bands') },
        { key: "kettlebells", label: t('aiWorkoutGenerator.equipment.kettlebells') },
        { key: "pullup", label: t('aiWorkoutGenerator.equipment.pullup') },
    ];
    const equipmentOptionsGym = [
        { key: "barbell", label: t('aiWorkoutGenerator.equipment.barbell') },
        { key: "dumbbells", label: t('aiWorkoutGenerator.equipment.dumbbells') },
        { key: "kettlebells", label: t('aiWorkoutGenerator.equipment.kettlebells') },
        { key: "cable", label: t('aiWorkoutGenerator.equipment.cable') },
        { key: "legpress", label: t('aiWorkoutGenerator.equipment.legpress') },
        { key: "pullup", label: t('aiWorkoutGenerator.equipment.pullup') },
        { key: "fullgym", label: t('aiWorkoutGenerator.equipment.fullgym') },
    ];

    const handleSubmit = async () => {
        if (equipment.length === 0) {
            setError("Please select at least one equipment option.");
            return;
        }
        setIsLoading(true);
        setError(null);

        const englishMappings = {
            goals: { 'lose_weight': 'Lose Weight', 'build_muscle': 'Build Lean Muscle' },
            somatotypes: { 'ectomorph': 'Ectomorph', 'mesomorph': 'Mesomorph', 'endomorph': 'Endomorph' },
            fatDistributions: { 'apple': 'Apple', 'pear': 'Pear' },
            levels: { 'beginner': 'Beginner', 'intermediate': 'Intermediate', 'advanced': 'Advanced' },
            locations: { 'home': 'Home', 'gym': 'Gym' },
            equipment: {
                'bodyweight': 'Bodyweight Only', 'dumbbells': 'Dumbbells', 'bands': 'Resistance Bands',
                'kettlebells': 'Kettlebells', 'pullup': 'Pull-up Bar', 'barbell': 'Barbell',
                'cable': 'Cable Machine', 'legpress': 'Leg Press', 'fullgym': 'Full Gym Access'
            }
        };

        try {
            const planOptions = {
                primaryGoal: englishMappings.goals[primaryGoal as keyof typeof englishMappings.goals],
                gender: gender.charAt(0).toUpperCase() + gender.slice(1),
                somatotype: englishMappings.somatotypes[somatotype as keyof typeof englishMappings.somatotypes],
                fatDistribution: englishMappings.fatDistributions[fatDistribution as keyof typeof englishMappings.fatDistributions],
                fitnessLevel: englishMappings.levels[fitnessLevel as keyof typeof englishMappings.levels],
                location: englishMappings.locations[location as keyof typeof englishMappings.locations],
                injuries: injuries || 'none',
                daysPerWeek,
                durationPerSession,
                equipment: equipment.map(key => englishMappings.equipment[key as keyof typeof englishMappings.equipment]),
                userName: currentUser.username,
                height,
                weight,
                targetWeight,
                dateOfBirth
            };
            
            const languageName = supportedLanguages[language]?.name || 'English';

            const plan = await generateWorkoutPlan(planOptions, languageName);
            openModal(ModalType.WorkoutPlan, plan);
        } catch (err) {
            console.error("Failed to generate workout plan:", err);
            setError(t('aiWorkoutGenerator.error') as string);
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleEquipmentChange = (optionKey: string) => {
        setEquipment(prev =>
            prev.includes(optionKey) ? prev.filter(item => item !== optionKey) : [...prev, optionKey]
        );
    };

    const nextStep = () => setStep(s => s + 1);
    const prevStep = () => setStep(s => s - 1);
    
    const ProgressBar = () => (
        <div className="w-full bg-gray-700 rounded-full h-2 mb-6">
            <div className="bg-green-500 h-2 rounded-full transition-all duration-300" style={{ width: `${(step / 5) * 100}%` }}></div>
        </div>
    );

    const RadioButton: React.FC<{ value: string; label: string; name: string; checked: boolean; onChange: (val: string) => void; }> = ({ value, label, name, checked, onChange }) => (
        <label className={`w-full p-4 rounded-xl text-center font-semibold cursor-pointer transition-all border-2 ${checked ? 'bg-green-500/20 border-green-500 text-white' : 'bg-gray-800 border-gray-700 text-gray-300 hover:border-gray-500'}`}>
            <input type="radio" name={name} value={value} checked={checked} onChange={(e) => onChange(e.target.value)} className="hidden" />
            {label}
        </label>
    );

    const bodyTypeImages = {
        male: {
            ectomorph: 'https://i.ibb.co/C21g4z2/male-ectomorph.png',
            mesomorph: 'https://i.ibb.co/yQxGzH6/male-mesomorph.png',
            endomorph: 'https://i.ibb.co/C5f8kS3/male-endomorph.png'
        },
        female: {
            ectomorph: 'https://i.ibb.co/d6x1fWj/female-ectomorph.png',
            mesomorph: 'https://i.ibb.co/N1zD19M/female-mesomorph.png',
            endomorph: 'https://i.ibb.co/hKxHk0n/female-endomorph.png'
        }
    };
    const somatotypeOptions = ['ectomorph', 'mesomorph', 'endomorph'];

    return (
        <Modal title={t('aiWorkoutGenerator.title') as string} closeModal={closeModal} show={true}>
            <ProgressBar />
            <div className="flex-grow overflow-y-auto max-h-[60vh] p-1">
            {step === 1 && (
                <div className="space-y-6 animate-fadeIn">
                    <h3 className="text-lg font-bold text-white text-center">{t('aiWorkoutGenerator.step1.primaryGoalTitle')}</h3>
                    <div className="flex flex-col sm:flex-row gap-4">
                        <RadioButton value="lose_weight" label={`💪 ${t('aiWorkoutGenerator.step1.goalLoseWeight')}`} name="primaryGoal" checked={primaryGoal === 'lose_weight'} onChange={setPrimaryGoal} />
                        <RadioButton value="build_muscle" label={`🔥 ${t('aiWorkoutGenerator.step1.goalBuildMuscle')}`} name="primaryGoal" checked={primaryGoal === 'build_muscle'} onChange={setPrimaryGoal} />
                    </div>
                </div>
            )}
            {step === 2 && (
                <div className="space-y-4 animate-fadeIn">
                    <h3 className="text-lg font-bold text-white text-center">{t('aiWorkoutGenerator.step2.experienceTitle')}</h3>
                     <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <RadioButton value="beginner" label={t('aiWorkoutGenerator.step2.levelBeginner') as string} name="fitnessLevel" checked={fitnessLevel === 'beginner'} onChange={setFitnessLevel} />
                        <RadioButton value="intermediate" label={t('aiWorkoutGenerator.step2.levelIntermediate') as string} name="fitnessLevel" checked={fitnessLevel === 'intermediate'} onChange={setFitnessLevel} />
                        <RadioButton value="advanced" label={t('aiWorkoutGenerator.step2.levelAdvanced') as string} name="fitnessLevel" checked={fitnessLevel === 'advanced'} onChange={setFitnessLevel} />
                    </div>
                    
                    <h3 className="text-lg font-bold text-white text-center pt-4">{t('aiWorkoutGenerator.step2.genderTitle')}</h3>
                    <div className="flex gap-4">
                        <RadioButton value="male" label={`♂️ ${t('aiWorkoutGenerator.step2.genderMale')}`} name="gender" checked={gender === 'male'} onChange={setGender as (val: string) => void} />
                        <RadioButton value="female" label={`♀️ ${t('aiWorkoutGenerator.step2.genderFemale')}`} name="gender" checked={gender === 'female'} onChange={setGender as (val: string) => void} />
                    </div>

                    <h3 className="text-lg font-bold text-white text-center pt-4">{t('aiWorkoutGenerator.step2.somatotypeTitle')}</h3>
                    <div className="grid grid-cols-3 gap-2">
                        {somatotypeOptions.map(type => (
                            <label key={type} className={`relative rounded-xl text-center font-semibold cursor-pointer transition-all border-2 overflow-hidden ${somatotype === type ? 'border-green-500' : 'border-gray-700 hover:border-gray-500'}`}>
                                <input type="radio" name="somatotype" value={type} checked={somatotype === type} onChange={(e) => setSomatotype(e.target.value)} className="hidden" />
                                <img src={bodyTypeImages[gender][type as keyof typeof bodyTypeImages['male']]} alt={type} className="w-full h-32 object-cover object-top" />
                                <div className={`absolute bottom-0 left-0 right-0 p-1 text-xs font-bold transition-colors ${somatotype === type ? 'bg-green-500 text-white' : 'bg-black/50 text-gray-200'}`}>
                                    {t(`aiWorkoutGenerator.step2.somatotype${type.charAt(0).toUpperCase() + type.slice(1)}`)}
                                </div>
                            </label>
                        ))}
                    </div>

                    <h3 className="text-lg font-bold text-white text-center pt-4">{t('aiWorkoutGenerator.step2.fatDistributionTitle')}</h3>
                    <div className="flex gap-4">
                        <RadioButton value="apple" label={t('aiWorkoutGenerator.step2.fatDistributionApple') as string} name="fatDistribution" checked={fatDistribution === 'apple'} onChange={setFatDistribution} />
                        <RadioButton value="pear" label={t('aiWorkoutGenerator.step2.fatDistributionPear') as string} name="fatDistribution" checked={fatDistribution === 'pear'} onChange={setFatDistribution} />
                    </div>

                    <h3 className="text-lg font-bold text-white text-center pt-4">{t('aiWorkoutGenerator.step2.locationTitle')}</h3>
                    <div className="flex gap-4">
                        <RadioButton value="home" label={`🏠 ${t('aiWorkoutGenerator.step2.locationHome')}`} name="location" checked={location === 'home'} onChange={(val) => {setLocation(val); setEquipment(['bodyweight']);}} />
                        <RadioButton value="gym" label={`🏢 ${t('aiWorkoutGenerator.step2.locationGym')}`} name="location" checked={location === 'gym'} onChange={(val) => {setLocation(val); setEquipment(['fullgym']);}} />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 pt-4">
                        <div>
                            <label className="text-sm font-bold text-gray-300 block mb-1">{t('aiWorkoutGenerator.step2.heightTitle')}</label>
                            <input type="number" value={height} onChange={e => setHeight(Number(e.target.value))} className="w-full p-3 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-green-500 text-sm"/>
                        </div>
                        <div>
                            <label className="text-sm font-bold text-gray-300 block mb-1">{t('aiWorkoutGenerator.step2.weightTitle')}</label>
                            <input type="number" value={weight} onChange={e => setWeight(Number(e.target.value))} className="w-full p-3 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-green-500 text-sm"/>
                        </div>
                    </div>
                    <div>
                        <label className="text-sm font-bold text-gray-300 block mb-1">{t('aiWorkoutGenerator.step2.targetWeightTitle')}</label>
                        <input type="number" value={targetWeight} onChange={e => setTargetWeight(Number(e.target.value))} className="w-full p-3 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-green-500 text-sm"/>
                    </div>
                    <div>
                        <label className="text-sm font-bold text-gray-300 block mb-1">{t('aiWorkoutGenerator.step2.dateOfBirthTitle')}</label>
                        <input type="date" value={dateOfBirth} onChange={e => setDateOfBirth(e.target.value)} className="w-full p-3 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-green-500 text-sm"/>
                    </div>
                    <div>
                        <label className="text-sm font-bold text-gray-300 block mb-1">{t('aiWorkoutGenerator.step2.injuriesTitle')}</label>
                        <textarea value={injuries} onChange={e => setInjuries(e.target.value)} rows={2} placeholder={t('aiWorkoutGenerator.step2.injuriesPlaceholder') as string} className="w-full p-3 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-green-500 text-sm"/>
                    </div>
                </div>
            )}
            {step === 3 && (
                 <div className="space-y-6 animate-fadeIn">
                    <div>
                        <label className="text-lg font-bold text-white block text-center mb-2">{t('aiWorkoutGenerator.step3.daysTitle')}</label>
                        <select value={daysPerWeek} onChange={e => setDaysPerWeek(Number(e.target.value))} className="w-full p-3 bg-gray-800 text-white text-center rounded-xl border border-gray-700 text-lg">
                            {[2,3,4,5,6].map(d => <option key={d} value={d}>{t('aiWorkoutGenerator.step3.daysOption', { count: d })}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className="text-lg font-bold text-white block text-center mb-2">{t('aiWorkoutGenerator.step3.durationTitle')}</label>
                         <select value={durationPerSession} onChange={e => setDurationPerSession(Number(e.target.value))} className="w-full p-3 bg-gray-800 text-white text-center rounded-xl border border-gray-700 text-lg">
                            <option value={30}>{t('aiWorkoutGenerator.step3.durationOption', { count: 30 })}</option>
                            <option value={45}>{t('aiWorkoutGenerator.step3.durationOption', { count: 45 })}</option>
                            <option value={60}>{t('aiWorkoutGenerator.step3.durationOption', { count: 60 })}</option>
                            <option value={75}>{t('aiWorkoutGenerator.step3.durationOption', { count: 75 })}</option>
                            <option value={90}>{t('aiWorkoutGenerator.step3.durationOption', { count: 90 })}</option>
                        </select>
                    </div>
                 </div>
            )}
            {step === 4 && (
                <div className="space-y-6 animate-fadeIn">
                    <h3 className="text-lg font-bold text-white text-center">{t('aiWorkoutGenerator.step4.equipmentTitle')}</h3>
                    <div className="grid grid-cols-2 gap-3">
                        {(location === 'home' ? equipmentOptionsHome : equipmentOptionsGym).map(option => (
                            <label key={option.key} className={`p-3 rounded-lg text-center text-sm cursor-pointer transition-colors border-2 ${equipment.includes(option.key) ? 'bg-teal-500/20 border-teal-500 text-white' : 'bg-gray-800 border-gray-700 text-gray-300'}`}>
                                <input type="checkbox" className="hidden" checked={equipment.includes(option.key)} onChange={() => handleEquipmentChange(option.key)} />
                                {option.label}
                            </label>
                        ))}
                    </div>
                </div>
            )}
             {step === 5 && (
                <div className="space-y-4 animate-fadeIn">
                    <h3 className="text-xl font-bold text-white text-center">{t('aiWorkoutGenerator.step5.readyTitle')}</h3>
                    <p className="text-sm text-gray-400 text-center">{t('aiWorkoutGenerator.step5.summary')}</p>
                    <div className="p-4 bg-gray-800 rounded-xl space-y-2 text-sm">
                        <div className="flex justify-between"><span className="text-gray-400">{t('aiWorkoutGenerator.step5.summaryGoal')}:</span> <span className="font-semibold text-white">{t(`aiWorkoutGenerator.step1.goal${primaryGoal === 'lose_weight' ? 'LoseWeight' : 'BuildMuscle'}`)}</span></div>
                        <div className="flex justify-between"><span className="text-gray-400">{t('aiWorkoutGenerator.step5.summaryGender')}:</span> <span className="font-semibold text-white">{t(`aiWorkoutGenerator.step2.gender${gender.charAt(0).toUpperCase() + gender.slice(1)}`)}</span></div>
                        <div className="flex justify-between"><span className="text-gray-400">{t('aiWorkoutGenerator.step5.summaryBodyType')}:</span> <span className="font-semibold text-white">{t(`aiWorkoutGenerator.step2.somatotype${somatotype.charAt(0).toUpperCase() + somatotype.slice(1)}`)}</span></div>
                        <div className="flex justify-between"><span className="text-gray-400">{t('aiWorkoutGenerator.step5.summaryFatDistribution')}:</span> <span className="font-semibold text-white">{t(`aiWorkoutGenerator.step2.fatDistribution${fatDistribution.charAt(0).toUpperCase() + fatDistribution.slice(1)}`)}</span></div>
                        <div className="flex justify-between"><span className="text-gray-400">{t('aiWorkoutGenerator.step5.summaryLevel')}:</span> <span className="font-semibold text-white">{t(`aiWorkoutGenerator.step2.level${fitnessLevel.charAt(0).toUpperCase() + fitnessLevel.slice(1)}`)}</span></div>
                        <div className="flex justify-between"><span className="text-gray-400">{t('aiWorkoutGenerator.step5.summaryLocation')}:</span> <span className="font-semibold text-white">{t(`aiWorkoutGenerator.step2.location${location.charAt(0).toUpperCase() + location.slice(1)}`)}</span></div>
                        <div className="flex justify-between"><span className="text-gray-400">{t('aiWorkoutGenerator.step5.summarySchedule')}:</span> <span className="font-semibold text-white">{t('aiWorkoutGenerator.step3.daysOption', { count: daysPerWeek })}, {t('aiWorkoutGenerator.step3.durationOption', { count: durationPerSession })}</span></div>
                        <div className="flex justify-between items-start"><span className="text-gray-400">{t('aiWorkoutGenerator.step5.summaryEquipment')}:</span> <span className="font-semibold text-white text-right max-w-[60%]">{equipment.map(key => t(`aiWorkoutGenerator.equipment.${key}`)).join(', ')}</span></div>
                        {injuries && <div className="flex justify-between"><span className="text-gray-400">{t('aiWorkoutGenerator.step5.summaryInjuries')}:</span> <span className="font-semibold text-white">{injuries}</span></div>}
                    </div>
                    {error && <p className="text-red-400 text-sm text-center">{error}</p>}
                </div>
             )}
             </div>

            <div className="mt-6 pt-4 border-t border-gray-700 flex gap-4">
                {step > 1 && <button onClick={prevStep} type="button" className="w-full bg-gray-600 text-white font-bold py-3 rounded-xl hover:bg-gray-700 transition-colors">{t('common.back')}</button>}
                {step < 5 && <button onClick={nextStep} type="button" className="w-full bg-green-500 text-white font-bold py-3 rounded-xl hover:bg-green-600 transition-colors">{t('common.next')}</button>}
                {step === 5 && (
                    <button onClick={handleSubmit} type="button" disabled={isLoading} className="w-full bg-teal-600 text-white font-bold py-3 rounded-xl hover:bg-teal-700 transition-all transform hover:scale-105 disabled:bg-gray-500 flex items-center justify-center">
                        {isLoading ? (
                            <>
                                <div className="w-5 h-5 border-2 border-t-transparent border-white rounded-full animate-spin mr-2"></div>
                                <span>{t('aiWorkoutGenerator.step5.generatingButton')}</span>
                            </>
                        ) : ( t('aiWorkoutGenerator.step5.generateButton') )}
                    </button>
                )}
            </div>
        </Modal>
    );
};

export default AiWorkoutGeneratorModal;