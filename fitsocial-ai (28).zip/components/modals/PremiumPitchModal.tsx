import React, { useState } from 'react';
import Modal from '../ui/Modal';
import { useTranslation } from '../../hooks/i18n';

interface PremiumPitchModalProps {
    closeModal: () => void;
}

type Status = 'idle' | 'loading' | 'ready' | 'error' | 'permission_denied';

const PremiumPitchModal: React.FC<PremiumPitchModalProps> = ({ closeModal }) => {
    const { t } = useTranslation();
    const [status, setStatus] = useState<Status>('idle');
    const [priceInfo, setPriceInfo] = useState<{ price: number; currency: string }>({ price: 10, currency: '£' });
    const [error, setError] = useState<string | null>(null);

    const handleCheckRegionalPricing = () => {
        setStatus('loading');
        setError(null);

        if (!navigator.geolocation) {
            setError(t('premium.geoNotSupported') as string);
            setStatus('error');
            setPriceInfo({ price: 10, currency: '£' });
            return;
        }

        navigator.geolocation.getCurrentPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                // Simplified check for Turkey
                const isTurkeyCoords = latitude >= 36 && latitude <= 42 && longitude >= 26 && longitude <= 45;
                
                if (isTurkeyCoords) {
                    setPriceInfo({ price: 50, currency: 'TL' });
                } else {
                    setPriceInfo({ price: 10, currency: '£' });
                }
                setStatus('ready');
            },
            (geoError) => {
                console.warn(`Geolocation error (${geoError.code}): ${geoError.message}`);
                if (geoError.code === 1) { // PERMISSION_DENIED
                    const isMobile = /Mobi|Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
                    setError(t(isMobile ? 'premium.permissionDeniedMobile' : 'premium.permissionDeniedDesktop') as string);
                    setStatus('permission_denied');
                } else {
                    setError(t('premium.locationError') as string);
                    setStatus('error');
                }
                // Revert to default price for display, but don't lock the user in.
                setPriceInfo({ price: 10, currency: '£' });
            },
            { timeout: 10000, enableHighAccuracy: false }
        );
    };

    const handlePrimaryAction = () => {
        if (status === 'ready') {
            // This is the second click after a successful price check, confirms subscription.
            alert('PRO Subscription Activated! (Simulated)');
            closeModal();
        } else {
            // For 'idle', 'permission_denied', or 'error' states, always (re)try the location check.
            // This allows the user to try again if they change their mind or fix settings.
            handleCheckRegionalPricing();
        }
    };

    const priceString = priceInfo.currency === 'TL' 
        ? `${priceInfo.price} ${priceInfo.currency}` 
        : `${priceInfo.currency}${priceInfo.price}`;
    
    const renderButtonContent = () => {
        switch (status) {
            case 'loading':
                return (
                    <div className="flex items-center justify-center">
                        <div className="w-6 h-6 border-4 border-gray-800 border-t-black rounded-full animate-spin mr-3"></div>
                        {t('premium.checking')}
                    </div>
                );
            case 'ready':
                // After successful location check, button becomes a confirmation.
                return t('premium.confirm', { price: priceString });
            case 'permission_denied':
            case 'error':
            case 'idle':
            default:
                // In all other cases, the button's action is to request/re-request location.
                return t('premium.goPro', { price: priceString });
        }
    };

    const featuresList = t('premium.features') as string[];


    return (
        <Modal title={t('premium.title') as string} closeModal={closeModal} show={true}>
            <div className="text-center">
                <span className="text-5xl">🌟</span>
                <p className="text-sm text-gray-300 my-4">{t('premium.unlock')}</p>
                <ul className="space-y-3 text-left text-sm font-medium">
                    {featuresList.map((feature, i) => (
                        <li key={i} className="flex items-center">
                            <span className="w-5 h-5 bg-green-500 text-white rounded-full flex items-center justify-center mr-3 font-extrabold">✓</span>
                            {feature}
                        </li>
                    ))}
                </ul>
                
                <div className="mt-6">
                    <button
                        onClick={handlePrimaryAction}
                        disabled={status === 'loading'}
                        className="w-full bg-yellow-500 text-black py-3 rounded-xl font-bold text-lg shadow-lg shadow-yellow-700/50 hover:bg-yellow-400 transition-colors transform hover:scale-105 disabled:bg-gray-500 disabled:cursor-not-allowed disabled:transform-none"
                    >
                        {renderButtonContent()}
                    </button>
                    
                    {error && (
                        <div className="mt-3 p-3 bg-yellow-900/50 border border-yellow-700 rounded-lg text-yellow-300 text-sm">
                            {error}
                        </div>
                    )}
                </div>
            </div>
        </Modal>
    );
};

export default PremiumPitchModal;