
import React, { useState, useRef, useEffect } from 'react';
import Modal from '../ui/Modal';
import { ProofOfWorkoutPost } from '../../types';
import { generateText } from '../../services/geminiService';

interface ProofOfWorkoutModalProps {
    closeModal: () => void;
    showNotification: (message: string, type?: 'success' | 'error') => void;
    handleCreateProofOfWorkout: (newPostData: Omit<ProofOfWorkoutPost, 'id' | 'user' | 'isVerified' | 'mediaUrl' | 'likes' | 'comments' | 'isLiked'> & { mediaBlobUrl: string, location?: string }) => void;
    modalData?: {
        initialMedia?: string;
        initialActivity?: string;
        initialDuration?: { hours: number; minutes: number };
        initialNotes?: string;
        initialLocation?: string;
    };
}

const ProofOfWorkoutModal: React.FC<ProofOfWorkoutModalProps> = ({ closeModal, showNotification, handleCreateProofOfWorkout, modalData }) => {
    const [file, setFile] = useState<File | null>(null);
    const [mediaPreview, setMediaPreview] = useState<string | null>(null);
    const [activity, setActivity] = useState('');
    const [location, setLocation] = useState('');
    const [effort, setEffort] = useState(5); // 1-10 scale
    const [durationHours, setDurationHours] = useState(1);
    const [durationMinutes, setDurationMinutes] = useState(0);
    const [notes, setNotes] = useState('');
    const [sets, setSets] = useState('');
    const [reps, setReps] = useState('');
    const [allowDownload, setAllowDownload] = useState(true);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isLocating, setIsLocating] = useState(false);

    useEffect(() => {
        if (modalData) {
            if (modalData.initialMedia) setMediaPreview(modalData.initialMedia);
            if (modalData.initialActivity) setActivity(modalData.initialActivity);
            if (modalData.initialDuration) {
                setDurationHours(modalData.initialDuration.hours);
                setDurationMinutes(modalData.initialDuration.minutes);
            }
            if (modalData.initialNotes) setNotes(modalData.initialNotes);
            if (modalData.initialLocation) setLocation(modalData.initialLocation);
        }
    }, [modalData]);

    const handleFileSelect = (selectedFile: File | null) => {
        if (selectedFile && (selectedFile.type.startsWith('image/') || selectedFile.type.startsWith('video/'))) {
            setFile(selectedFile);
            setMediaPreview(URL.createObjectURL(selectedFile));
        } else if (selectedFile) {
            showNotification("Please select a valid image or video file.", "error");
        }
    };

    const handleGetLocation = () => {
        if (!navigator.geolocation) {
            showNotification("Geolocation not supported.", "error");
            return;
        }
        setIsLocating(true);
        navigator.geolocation.getCurrentPosition(async (pos) => {
            const { latitude, longitude } = pos.coords;
            try {
                const prompt = `Using Google Maps, identify the specific place name (Gym, Park, Landmark, or Neighborhood) for these coordinates: ${latitude}, ${longitude}. Return ONLY the name. Keep it short.`;
                const result = await generateText(prompt, false, true, false, { latitude, longitude });
                const locationName = typeof result.text === 'string' ? result.text.trim() : '';
                if (locationName) setLocation(locationName);
                else setLocation(`${latitude.toFixed(4)}, ${longitude.toFixed(4)}`);
            } catch (e) {
                console.error("Location fetch failed:", e);
                setLocation(`${latitude.toFixed(4)}, ${longitude.toFixed(4)}`);
            } finally {
                setIsLocating(false);
            }
        }, (err) => {
            let msg = typeof err === 'string' ? err : (err instanceof Error ? err.message : (err as any).message);
            showNotification(`Could not get location: ${msg}`, "error");
            setIsLocating(false);
        });
    };

    const handleSubmit = () => {
        if (!mediaPreview) {
            showNotification("Please upload a photo or video.", "error");
            return;
        }
        if (!activity.trim()) {
             showNotification("Please enter an activity name.", "error");
             return;
        }

        setIsSubmitting(true);

        try {
            let mediaType: 'image' | 'video' = 'image';
            if (file) {
                mediaType = file.type.startsWith('image/') ? 'image' : 'video';
            }

            handleCreateProofOfWorkout({
                mediaBlobUrl: mediaPreview,
                mediaType: mediaType,
                activity: activity.trim(),
                notes: notes.trim(),
                effort: Math.ceil(effort / 2), // Convert 1-10 scale to 1-5 scale
                duration: { hours: durationHours, minutes: durationMinutes },
                sets: sets || undefined,
                reps: reps || undefined,
                allowDownload,
                location: location.trim() || undefined
            });

            showNotification("Proof of Workout shared!", "success");
            closeModal();
        } catch (error) {
            console.error("Error creating PoW:", error);
            showNotification("Failed to share workout. Please try again.", "error");
            setIsSubmitting(false);
        }
    };

    return (
        <Modal title="Log Workout" closeModal={closeModal} show={true}>
            <div className="space-y-5">
                
                {/* Media Upload Area */}
                <div 
                    onClick={() => !mediaPreview && fileInputRef.current?.click()}
                    className="relative w-full h-48 rounded-xl overflow-hidden bg-[#0A0A0A] border-2 border-dashed border-gray-700 hover:border-emerald-500 cursor-pointer flex flex-col items-center justify-center group transition-colors"
                >
                    {mediaPreview ? (
                        <>
                           {file?.type.startsWith('video/') ? (
                                <video src={mediaPreview} controls className="w-full h-full object-contain" />
                            ) : (
                                <img src={mediaPreview} alt="Preview" className="w-full h-full object-contain" />
                            )}
                             <button onClick={(e) => { e.stopPropagation(); setMediaPreview(null); setFile(null); if(fileInputRef.current) fileInputRef.current.value = ""; }} className="absolute top-2 right-2 bg-black/60 text-white p-1.5 rounded-full hover:bg-red-600 transition-colors">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                             </button>
                        </>
                    ) : (
                        <div className="text-center text-gray-500">
                            <div className="w-12 h-12 rounded-full bg-gray-800 flex items-center justify-center mx-auto mb-2 group-hover:bg-emerald-900/30 transition-colors">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/></svg>
                            </div>
                            <p className="text-sm font-bold">Upload Photo/Video</p>
                        </div>
                    )}
                </div>
                <input type="file" ref={fileInputRef} onChange={(e) => handleFileSelect(e.target.files ? e.target.files[0] : null)} accept="image/*,video/*" className="hidden" />

                {/* Activity Name */}
                <div>
                    <label className="text-sm font-bold text-gray-400 block mb-1">Activity Name</label>
                    <input type="text" value={activity} onChange={e => setActivity(e.target.value)} placeholder="e.g. Chest Press, 5k Run" className="w-full p-3 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all" />
                </div>

                {/* Location */}
                <div className="flex gap-2">
                    <div className="flex-1">
                        <label className="text-sm font-bold text-gray-400 block mb-1">Location (Optional)</label>
                        <input type="text" value={location} onChange={e => setLocation(e.target.value)} placeholder="Gym name or city" className="w-full p-3 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-emerald-500 transition-all" />
                    </div>
                    <div className="flex items-end">
                        <button onClick={handleGetLocation} disabled={isLocating} className="bg-gray-800 text-emerald-400 p-3 rounded-xl border border-gray-700 hover:bg-gray-700 transition-colors h-[46px] w-[46px] flex items-center justify-center">
                            {isLocating ? <div className="w-4 h-4 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin"></div> : <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>}
                        </button>
                    </div>
                </div>

                {/* Sets & Reps - EXPLICIT ROW */}
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="text-sm font-bold text-gray-300 block mb-1">Sets</label>
                        <input 
                            type="number" 
                            value={sets} 
                            onChange={(e) => setSets(e.target.value)} 
                            placeholder="e.g. 4" 
                            className="w-full p-3 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-emerald-500 text-center font-mono" 
                        />
                    </div>
                    <div>
                        <label className="text-sm font-bold text-gray-300 block mb-1">Reps / Count</label>
                        <input 
                            type="number" 
                            value={reps} 
                            onChange={(e) => setReps(e.target.value)} 
                            placeholder="e.g. 12" 
                            className="w-full p-3 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-emerald-500 text-center font-mono" 
                        />
                    </div>
                </div>

                {/* Duration */}
                <div>
                    <label className="text-sm font-bold text-gray-400 block mb-1">Duration</label>
                    <div className="flex gap-2">
                        <div className="relative flex-1">
                            <input type="number" min="0" value={durationHours} onChange={e => setDurationHours(Math.max(0, Number(e.target.value)))} className="w-full p-3 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-emerald-500 text-center font-mono" />
                            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-xs">hr</span>
                        </div>
                        <div className="relative flex-1">
                            <input type="number" min="0" max="59" value={durationMinutes} onChange={e => setDurationMinutes(Math.max(0, Math.min(59, Number(e.target.value))))} className="w-full p-3 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-emerald-500 text-center font-mono" />
                            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-xs">min</span>
                        </div>
                    </div>
                </div>

                {/* Effort Slider */}
                <div>
                    <div className="flex justify-between mb-1">
                        <label className="text-sm font-bold text-gray-400">Effort Level</label>
                        <span className="text-emerald-400 font-bold">{effort}/10</span>
                    </div>
                    <input type="range" min="1" max="10" value={effort} onChange={e => setEffort(Number(e.target.value))} className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-emerald-500" />
                </div>

                {/* Notes */}
                <div>
                    <label className="text-sm font-bold text-gray-400 block mb-1">Notes</label>
                    <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} placeholder="How did it feel? Personal records?" className="w-full p-3 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-emerald-500 resize-none text-sm" />
                </div>
                
                <button 
                    onClick={handleSubmit} 
                    disabled={isSubmitting}
                    className="w-full bg-emerald-600 hover:bg-emerald-500 text-white py-4 rounded-xl font-bold text-lg shadow-lg transition-all transform hover:scale-[1.02] active:scale-95 disabled:opacity-50 disabled:transform-none flex items-center justify-center gap-2"
                >
                    {isSubmitting ? (
                        <>
                           <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                           <span>Sharing...</span>
                        </>
                    ) : (
                        <span>Share Workout</span>
                    )}
                </button>
            </div>
        </Modal>
    );
};

export default ProofOfWorkoutModal;
