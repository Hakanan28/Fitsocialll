import React from 'react';
import Modal from '../ui/Modal';
import { ModalType, Exercise } from '../../types';
import { exercises } from '../../data/exercises';

interface ExerciseListModalProps {
    closeModal: () => void;
    openModal: (modal: ModalType, data?: any) => void;
    modalData: {
        muscleGroup: string;
        filter: 'home' | 'gym';
        onExerciseSelect?: (exercise: Exercise) => void;
        showNotification?: (message: string, type?: 'success' | 'error') => void;
    };
}

const ExerciseListModal: React.FC<ExerciseListModalProps> = ({ closeModal, openModal, modalData }) => {
    if (!modalData?.filter) return null;

    const { muscleGroup, filter, onExerciseSelect, showNotification } = modalData;
    const filteredExercises = exercises.filter(ex => 
        (muscleGroup === 'All' || ex.muscleGroup === muscleGroup) &&
        (ex.location === 'both' || ex.location === filter)
    );

    const handleSelectExercise = (exercise: Exercise) => {
        if (onExerciseSelect) {
            onExerciseSelect(exercise);
            if(showNotification) {
                showNotification(`${exercise.name} added to routine!`, 'success');
            }
            // Do not close the modal, allow user to select more exercises.
        } else if (exercise.muscleGroup === 'Cardio') {
            openModal(ModalType.RunningMode);
            closeModal();
        } else {
            openModal(ModalType.ExerciseDetail, exercise);
        }
    };

    const title = muscleGroup === 'All'
        ? `All Exercises (${filter === 'home' ? 'At Home' : 'Gym'})`
        : `${muscleGroup} Exercises (${filter === 'home' ? 'At Home' : 'Gym'})`;

    return (
        <Modal title={title} closeModal={closeModal} show={true}>
            <div className="space-y-3">
                {filteredExercises.length > 0 ? (
                    filteredExercises.map(exercise => (
                        <div 
                            key={exercise.id} 
                            onClick={() => handleSelectExercise(exercise)}
                            className="flex items-center p-3 bg-gray-800 rounded-xl shadow-lg cursor-pointer hover:bg-gray-700 transition-colors transform hover:scale-[1.02]"
                        >
                            <div className="flex-1">
                                <h3 className="font-bold text-white text-lg">{exercise.name}</h3>
                                <p className="text-sm text-gray-400">{exercise.equipment}</p>
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="text-gray-500"><path d="m9 18 6-6-6-6"/></svg>
                        </div>
                    ))
                ) : (
                    <p className="text-center text-gray-400 py-8">No exercises found for this category and location.</p>
                )}
            </div>
        </Modal>
    );
};

export default ExerciseListModal;