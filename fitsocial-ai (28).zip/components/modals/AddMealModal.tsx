import React, { useState } from 'react';
import Modal from '../ui/Modal';
import { ModalType } from '../../types';
import { analyzeMealForNutrition } from '../../services/geminiService';

interface AddMealModalProps {
    closeModal: () => void;
    onAddMacros: (macrosToAdd: any, date: string, foodName?: string) => void;
    isProUser: boolean;
    openModal: (modal: ModalType) => void;
    currentDate?: string; 
}

const getLocalDateString = (): string => {
    const d = new Date();
    const year = d.getFullYear();
    const month = (d.getMonth() + 1).toString().padStart(2, '0');
    const day = d.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
};

const MOCK_FOOD_DB = {
    "tavuk": { name: "Chicken Breast", cal: 165, pro: 31, carb: 0, fat: 3.6, fiber: 0, sugar: 0, sodium: 74, potassium: 256, saturatedFat: 1 },
    "pirinc": { name: "Rice (White)", cal: 130, pro: 2.7, carb: 28, fat: 0.3, fiber: 0.4, sugar: 0.1, sodium: 1, potassium: 35, saturatedFat: 0.1 },
    "yumurta": { name: "Egg (Large)", cal: 78, pro: 6, carb: 0.6, fat: 5, fiber: 0, sugar: 0.6, sodium: 62, potassium: 63, saturatedFat: 1.6 },
    "badem": { name: "Almonds", cal: 579, pro: 21, carb: 22, fat: 49, fiber: 12.5, sugar: 4.4, sodium: 1, potassium: 733, saturatedFat: 3.8 },
    "proteinTozu": { name: "Protein Powder (Scoop)", cal: 120, pro: 24, carb: 3, fat: 1, fiber: 1, sugar: 1, sodium: 150, potassium: 150, saturatedFat: 0.5 }
};

const AddMealModal: React.FC<AddMealModalProps> = ({ closeModal, onAddMacros, isProUser, openModal, currentDate }) => {
    const [activeTab, setActiveTab] = useState<'manual' | 'ai'>('manual');
    
    // Manual tab state
    const [foodKey, setFoodKey] = useState('tavuk');
    const [quantity, setQuantity] = useState(100);

    // AI tab state
    const [aiInput, setAiInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [analysisResult, setAnalysisResult] = useState<any | null>(null);
    const [error, setError] = useState('');

    const addMacrosToTotal = (macrosToAdd: any, foodName: string) => {
        onAddMacros(macrosToAdd, currentDate || getLocalDateString(), foodName);
        closeModal();
    };

    const handleAddManualFood = () => {
        const foodData = MOCK_FOOD_DB[foodKey as keyof typeof MOCK_FOOD_DB];
        if (!foodData || quantity <= 0) return;

        let multiplier = quantity / 100;
        if (foodKey === 'yumurta' || foodKey === 'proteinTozu') {
            multiplier = quantity; // Treat as unit
        }

        const macrosToAdd = {
            cal: foodData.cal * multiplier,
            pro: foodData.pro * multiplier,
            carb: foodData.carb * multiplier,
            fat: foodData.fat * multiplier,
            fiber: (foodData.fiber || 0) * multiplier,
            sugar: (foodData.sugar || 0) * multiplier,
            sodium: (foodData.sodium || 0) * multiplier,
            potassium: (foodData.potassium || 0) * multiplier,
            saturatedFat: (foodData.saturatedFat || 0) * multiplier,
        };

        const displayUnit = (foodKey === 'yumurta' || foodKey === 'proteinTozu') ? 'x' : 'g';
        const name = `${foodData.name} (${quantity}${displayUnit})`;

        addMacrosToTotal(macrosToAdd, name);
    };

    const handleAiAnalyze = async () => {
        if (!aiInput.trim() || !isProUser) return;
        setIsLoading(true);
        setError('');
        setAnalysisResult(null);
        try {
            const result = await analyzeMealForNutrition(aiInput);
            setAnalysisResult(result);
        } catch (e) {
            console.error(e);
            setError("Analysis failed. Please try a different description.");
        } finally {
            setIsLoading(false);
        }
    };
    
    const renderManualTab = () => (
        <div className="space-y-4">
            <div>
                <label htmlFor="food-select" className="text-sm font-bold text-gray-300 block mb-1">Select Food</label>
                <select id="food-select" value={foodKey} onChange={e => setFoodKey(e.target.value)} className="w-full p-3 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-green-500 focus:ring-2 focus:ring-green-500/50 transition-all">
                    {Object.entries(MOCK_FOOD_DB).map(([key, value]) => <option key={key} value={key}>{value.name}</option>)}
                </select>
            </div>
            <div>
                <label htmlFor="food-grams" className="text-sm font-bold text-gray-300 block mb-1">Grams / Quantity</label>
                <input type="number" id="food-grams" value={quantity} onChange={e => setQuantity(parseInt(e.target.value))} className="w-full p-3 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-green-500 focus:ring-2 focus:ring-green-500/50 transition-all"/>
            </div>
            <button onClick={handleAddManualFood} className="w-full bg-green-500 text-white py-3 rounded-xl font-bold mt-4 hover:bg-green-600 transition-colors transform hover:scale-105">Add to Daily Log</button>
        </div>
    );
    
    const renderAiTab = () => (
        <div className="space-y-4">
            {!isProUser ? (
                 <div className="h-48 flex flex-col items-center justify-center bg-gray-800 rounded-xl shadow-inner text-center p-4">
                    <span className="text-4xl">⭐️</span>
                    <p className="text-md font-bold text-yellow-400 mt-3">AI Meal Analysis is a PRO Feature</p>
                    <button onClick={() => { closeModal(); openModal(ModalType.PremiumPitch); }} className="bg-yellow-500 text-black text-sm font-bold py-2 px-4 rounded-xl mt-4 shadow-md hover:bg-yellow-400 transition-colors transform hover:scale-105">Go PRO</button>
                </div>
            ) : (
                <>
                    <textarea 
                        value={aiInput}
                        onChange={e => setAiInput(e.target.value)}
                        rows={4}
                        className="w-full p-3 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-blue-500 transition-colors"
                        placeholder="e.g., 150g grilled chicken breast, a cup of white rice, and a side of steamed broccoli"
                    />
                    <button onClick={handleAiAnalyze} disabled={isLoading || !aiInput.trim()} className="w-full bg-blue-500 text-white py-3 rounded-xl font-bold flex items-center justify-center space-x-2 hover:bg-blue-600 transition-colors transform hover:scale-105 disabled:bg-gray-500">
                        {isLoading ? (
                             <div className="w-5 h-5 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
                        ) : (
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-sparkles"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/><path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/></svg>
                        )}
                        <span>{isLoading ? 'Analyzing...' : 'Analyze with AI'}</span>
                    </button>
                    {error && <p className="text-red-400 text-sm text-center">{error}</p>}
                    {analysisResult && (
                        <div className="p-3 bg-gray-800 rounded-xl space-y-2 animate-fadeIn">
                            <h4 className="font-bold text-white text-center mb-2">Analysis Results</h4>
                             <div className="grid grid-cols-3 gap-x-2 gap-y-1 text-xs text-center">
                                <p><strong className="text-green-400 block">{analysisResult.cal.toFixed(0)}</strong> kcal</p>
                                <p><strong className="text-sky-400 block">{analysisResult.pro.toFixed(1)}g</strong> Protein</p>
                                <p><strong className="text-orange-400 block">{analysisResult.carb.toFixed(1)}g</strong> Carbs</p>
                                <p><strong className="text-yellow-400 block">{analysisResult.fat.toFixed(1)}g</strong> Fat</p>
                                <p><strong className="text-lime-400 block">{analysisResult.fiber.toFixed(1)}g</strong> Fiber</p>
                                <p><strong className="text-pink-400 block">{analysisResult.sugar.toFixed(1)}g</strong> Sugar</p>
                            </div>
                            <button onClick={() => addMacrosToTotal(analysisResult, aiInput.substring(0, 25) + (aiInput.length>25 ? '...' : ''))} className="w-full bg-green-500 text-white py-2 rounded-lg font-bold mt-2 hover:bg-green-600 transition-colors text-sm">Add to Daily Log</button>
                        </div>
                    )}
                </>
            )}
        </div>
    );


    return (
        <Modal title="Log a Meal / Food" closeModal={closeModal} show={true}>
            <div className="mb-4 flex p-1 bg-gray-800 rounded-xl font-semibold">
                <button onClick={() => setActiveTab('manual')} className={`w-1/2 py-2 rounded-lg transition-colors text-sm ${activeTab === 'manual' ? 'bg-green-500 text-white' : 'text-gray-400'}`}>
                    Manual Entry
                </button>
                <button onClick={() => setActiveTab('ai')} className={`w-1/2 py-2 rounded-lg transition-colors text-sm ${activeTab === 'ai' ? 'bg-blue-500 text-white' : 'text-gray-400'}`}>
                    AI Analysis ✨
                </button>
            </div>
            <div key={activeTab} className="animate-fadeIn">
                {activeTab === 'manual' ? renderManualTab() : renderAiTab()}
            </div>
        </Modal>
    );
};

export default AddMealModal;