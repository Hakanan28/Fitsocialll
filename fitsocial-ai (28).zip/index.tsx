
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { TranslationProvider } from './hooks/i18n';

// Suppress ResizeObserver loop limit exceeded error
// This is often a benign error in development/testing with libraries like Chart.js
const resizeObserverLoopErr = /ResizeObserver loop completed with undelivered notifications/;
const originalError = console.error;
console.error = (...args) => {
  if (typeof args[0] === 'string' && resizeObserverLoopErr.test(args[0])) {
    return;
  }
  originalError(...args);
};

window.addEventListener('error', (e) => {
    if (resizeObserverLoopErr.test(e.message)) {
        e.stopImmediatePropagation();
        e.preventDefault();
    }
});

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <TranslationProvider>
      <App />
    </TranslationProvider>
  </React.StrictMode>
);
