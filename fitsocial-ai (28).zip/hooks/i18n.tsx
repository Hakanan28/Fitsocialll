
import React, { createContext, useState, useContext, useEffect, useCallback } from 'react';

// Define the shape of the context
interface TranslationContextType {
    language: string;
    setLanguage: (language: string) => void;
    t: (key: string, options?: { [key: string]: string | number }) => string | string[];
    dir: 'ltr' | 'rtl';
}

// Create the context
const TranslationContext = createContext<TranslationContextType | undefined>(undefined);

// Define supported languages
export const supportedLanguages: { [key: string]: { name: string, dir: 'ltr' | 'rtl' } } = {
    'en': { name: 'English', dir: 'ltr' },
    'fr': { name: 'Français', dir: 'ltr' },
    'de': { name: 'Deutsch', dir: 'ltr' },
    'nl': { name: 'Nederlands', dir: 'ltr' },
    'ar': { name: 'العربية', dir: 'rtl' },
    'tr': { name: 'Türkçe', dir: 'ltr' },
    'uk': { name: 'Українська', dir: 'ltr' },
    'ru': { name: 'Русский', dir: 'ltr' }
};

// Provider component
export const TranslationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [language, setLanguageState] = useState<string>(localStorage.getItem('appLanguage') || 'en');
    const [translations, setTranslations] = useState<any>({});

    useEffect(() => {
        const fetchTranslations = async () => {
            // Check cache first - Bumped to v3 to fix stale content keys
            const cacheKey = `translations_v3_${language}`;
            const cachedTranslations = localStorage.getItem(cacheKey);
            if (cachedTranslations) {
                try {
                    setTranslations(JSON.parse(cachedTranslations));
                    console.log(`Loaded translations for ${language} from cache.`);
                    return;
                } catch (e) {
                    console.error("Failed to parse cached translations, fetching again.", e);
                    localStorage.removeItem(cacheKey);
                }
            }

            // Fetch the appropriate language file
            try {
                const response = await fetch(`locales/${language}.json`);
                if (!response.ok) {
                    throw new Error(`Could not load locale file for: ${language}`);
                }
                const data = await response.json();
                setTranslations(data);
                localStorage.setItem(cacheKey, JSON.stringify(data));
            } catch (error) {
                console.error(error);
                // Fallback to English if the fetch fails
                try {
                    const enResponse = await fetch('locales/en.json');
                    const enData = await enResponse.json();
                    setTranslations(enData);
                } catch (enError) {
                    console.error("Failed to load even the fallback English locale:", enError);
                }
            }
        };

        fetchTranslations();
    }, [language]);

    const setLanguage = (lang: string) => {
        if (supportedLanguages[lang as keyof typeof supportedLanguages]) {
            localStorage.setItem('appLanguage', lang);
            setLanguageState(lang);
        }
    };

    const t = useCallback((key: string, options?: { [key: string]: string | number }): string | string[] => {
        const keys = key.split('.');
        let result: any = keys.reduce((acc, currentKey) => acc && acc[currentKey], translations);
        
        if (result === undefined) {
            console.warn(`Translation key not found: ${key}`);
            return key;
        }

        if (typeof result === 'string') {
            if (options) {
                Object.keys(options).forEach(optionKey => {
                    result = result.replace(new RegExp(`{{${optionKey}}}`, 'g'), String(options[optionKey]));
                });
            }
            return result;
        }

        if (Array.isArray(result) && result.every(item => typeof item === 'string')) {
            return result;
        }
        
        console.warn(`Translation for key '${key}' is not a string or string array.`);
        return key;
    }, [translations]);

    const dir = supportedLanguages[language as keyof typeof supportedLanguages]?.dir || 'ltr';

    return (
        <TranslationContext.Provider value={{ language, setLanguage, t, dir }}>
            {children}
        </TranslationContext.Provider>
    );
};

// Custom hook to use the translation context
export const useTranslation = (): TranslationContextType => {
    const context = useContext(TranslationContext);
    if (context === undefined) {
        throw new Error('useTranslation must be used within a TranslationProvider');
    }
    return context;
};
