
import React, { useState, useEffect, useMemo } from 'react';
import { Page, ModalType, UserProfile, Post, Reel, Story, Coin, NFT, GearItem, Group, Notification, GroupMessage, CallLog, ProofOfWorkoutPost, WorkoutRoutine, BadgeNFT, CustomTheme, CartItem, Review } from './types';
import { currentUserProfile, allUsers } from './data/users';
import { initialReelData } from './data/reels';
import { initialNftData } from './data/nfts';
import { initialGearItems } from './data/marketplace';
import { getCoins } from './services/cryptoService';
import { useActivityHistory } from './hooks/useActivityHistory';
import { initialGroupData, initialDmData, initialCallLogs } from './data/groups';
import { generateAdvancedDietPlan } from './services/geminiService';

// Components
import Header from './components/layout/Header';
import NavBar from './components/layout/NavBar';
import HomePage from './components/pages/HomePage';
import ExplorePage from './components/pages/ExplorePage';
import ReelsPage from './components/pages/ReelsPage';
import ExercisePage from './components/pages/ExercisePage';
import { ProfilePage } from './components/pages/ProfilePage';
import WalletPage from './components/pages/WalletPage'; 

// Modals
import Modal from './components/ui/Modal';
import AiCoachModal from './components/modals/AiCoachModal';
import VideoGenerationModal from './components/modals/VideoGenerationModal';
import ImageGenerationModal from './components/modals/ImageGenerationModal';
import ContentAnalysisModal from './components/modals/ContentAnalysisModal';
import ImageEditingModal from './components/modals/ImageEditingModal';
import UnifiedCreateModal from './components/modals/CreatePostModal';
import DmModals from './components/modals/DmModals';
import NotificationsModal from './components/modals/NotificationsModal';
import PremiumPitchModal from './components/modals/PremiumPitchModal';
import SettingsModal from './components/modals/SettingsModal';
import StoryViewerModal from './components/modals/StoryViewerModal';
import DataEntryModal from './components/modals/DataEntryModal';
import AddMealModal from './components/modals/AddMealModal';
import CreateRoutineModal from './components/modals/CreateRoutineModal';
import ReactionTestModal from './components/modals/ReactionTestModal';
import AdaptiveWorkoutModal from './components/modals/AdaptiveWorkoutModal';
import WorkoutModeModal from './components/modals/WorkoutModeModal';
import RunningModeModal from './components/modals/RunningModeModal';
import HolographicFormModal from './components/modals/HolographicFormModal';
import NeuralLinkModal from './components/modals/NeuralLinkModal';
import QuantumHrvModal from './components/modals/QuantumHrvModal';
import BodyMapModal from './components/modals/BodyMapModal';
import CryptoRewardsModal from './components/modals/CryptoRewardsModal';
import StakeChallengeModal from './components/modals/StakeChallengeModal';
import MetaGymModal from './components/modals/MetaGymModal';
import AiWorkoutGeneratorModal from './components/modals/AiWorkoutGeneratorModal';
import WorkoutPlanModal from './components/modals/WorkoutPlanModal';
import WorkoutVideoGeneratorModal from './components/modals/WorkoutVideoGeneratorModal';
import CoinDetailModal from './components/modals/Wallet/CoinDetailModal';
import SendModal from './components/modals/Wallet/SendModal';
import ReceiveModal from './components/modals/Wallet/ReceiveModal';
import AddTokenModal from './components/modals/Wallet/AddTokenModal';
import NftDetailModal from './components/modals/Wallet/NftDetailModal';
import PostAnalysisModal from './components/modals/PostAnalysisModal';
import ReelEditorModal from './components/modals/ReelEditorModal';
import SpeechToTextModal from './components/modals/SpeechToTextModal';
import StoryEditorModal from './components/modals/StoryEditorModal';
import PostImageEditorModal from './components/modals/PostImageEditorModal';
import VideoEditorModal from './components/modals/VideoEditorModal';
import GroupJoinModal from './components/modals/GroupJoinModal';
import GroupProfileModal from './components/modals/GroupProfileModal';
import CreateHighlightModal from './components/modals/CreateHighlightModal';
import FollowListModal from './components/modals/FollowListModal';
import CreateChallengeModal from './components/modals/CreateChallengeModal';
import ProofOfWorkoutModal from './components/modals/ProofOfWorkoutModal';
import ProofOfWorkoutDetailModal from './components/modals/ProofOfWorkoutDetailModal';
import DailyNutritionModal from './components/modals/DailyNutritionModal';
import CreateGroupModal from './components/modals/CreateGroupModal';
import GroupChatModal from './components/modals/GroupChatModal';
import TextToSpeechModal from './components/modals/TextToSpeechModal';
import AiReelGeneratorModal from './components/modals/AiReelGeneratorModal';
import ProductDetailModal from './components/modals/ProductDetailModal';
import PostDetailModal from './components/modals/PostDetailModal';
import SharePostModal from './components/modals/SharePostModal';
import CommentsModal from './components/modals/CommentsModal';
import ExerciseListModal from './components/modals/ExerciseListModal';
import ExerciseDetailModal from './components/modals/ExerciseDetailModal';
import DetailsModal from './components/modals/DetailsModal';
import EditProfileModal from './components/modals/EditProfileModal';
import AuthModal from './components/modals/AuthModal';
import ThemeCustomizationModal from './components/modals/ThemeCustomizationModal';
import AiRecipeModal from './components/modals/AiRecipeModal';
import CreateListingModal from './components/modals/CreateListingModal';
import CartModal from './components/modals/CartModal';

import { useAchievements } from './hooks/useAchievements';
import { useCvsScore } from './hooks/useCvsScore';
import { badgeData } from './data/badges';

const App: React.FC = () => {
    const [currentPage, setCurrentPage] = useState<Page>(Page.Home);
    const [modal, setModal] = useState<{ type: ModalType | null; data?: any }>({ type: null });
    const [currentUser, setCurrentUser] = useState<UserProfile>(currentUserProfile);
    const [users, setUsers] = useState<UserProfile[]>(allUsers);
    const [posts, setPosts] = useState<Post[]>([]);
    const [reels, setReels] = useState<Reel[]>(initialReelData);
    const [stories, setStories] = useState<Record<string, Story[]>>({});
    const [notifications, setNotifications] = useState<Notification[]>([]);
    const [coins, setCoins] = useState<Coin[]>(getCoins());
    const [nfts, setNfts] = useState<NFT[]>(initialNftData);
    const [gearItems, setGearItems] = useState<GearItem[]>(initialGearItems);
    const [fitTokenBalance, setFitTokenBalance] = useState<number>(1250);
    const [theme, setTheme] = useState<'light' | 'dark'>('dark');
    const [customTheme, setCustomTheme] = useState<any>(null);
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    
    const [proofOfWorkouts, setProofOfWorkouts] = useState<ProofOfWorkoutPost[]>([]);
    const [workoutRoutines, setWorkoutRoutines] = useState<WorkoutRoutine[]>([]);
    const [groups, setGroups] = useState<Group[]>(initialGroupData);
    const [messages, setMessages] = useState<Record<string, GroupMessage[]>>(initialDmData);
    const [callLogs, setCallLogs] = useState<CallLog[]>(initialCallLogs);
    const [challenges, setChallenges] = useState<any[]>([]);
    
    // CART STATE
    const [cart, setCart] = useState<CartItem[]>([]);
    
    const [userProfileData, setUserProfileData] = useState<any>({
        height: 175, weight: 75, targetWeight: 70, age: 28, activity: 1.55, gender: 'male', 
        somatotype: 'mesomorph', fatDistribution: 'apple', fitnessGoal: 'build_muscle',
        activeSports: []
    });
    const [nutritionHistory, setNutritionHistory] = useState<{ date: string, macros: any }[]>([]);
    const [nutritionGoals, setNutritionGoals] = useState({ cal: 2500, pro: 180, carb: 250, fat: 80 });
    const [foodLog, setFoodLog] = useState<any[]>([]);
    const [waterCount, setWaterCount] = useState(0);
    // Initialize stats to 0 to support real counting
    const [stepStats, setStepStats] = useState({ steps: 0, distance: 0, calories: 0 });
    const [isStepCounterActive, setIsStepCounterActive] = useState(false);
    const [stepCounterPermissionState, setStepCounterPermissionState] = useState<'prompt' | 'granted' | 'denied' | 'unsupported'>('prompt');

    const { activityHistory, updateTodayRecord } = useActivityHistory();
    const { earnedBadgeIds, getBadgeProgress } = useAchievements(currentUser, activityHistory, posts, reels, proofOfWorkouts, workoutRoutines, fitTokenBalance, true);
    const cvsScore = useCvsScore(currentUser, posts, reels, proofOfWorkouts, workoutRoutines, activityHistory);
    const earnedBadges = useMemo(() => badgeData.filter(b => earnedBadgeIds.has(b.id)), [earnedBadgeIds]);

    useEffect(() => {
        if (currentUser.cvsScore !== cvsScore) {
            setCurrentUser(prev => ({ ...prev, cvsScore }));
        }
    }, [cvsScore]);

    // Pedometer Logic
    useEffect(() => {
        let motionHandler: any;

        if (isStepCounterActive) {
            let lastX = 0, lastY = 0, lastZ = 0;
            let lastTime = 0;
            const THRESHOLD = 10; // Sensitivity threshold for step detection
            const DELAY = 400; // Minimum time between steps in ms

            motionHandler = (event: DeviceMotionEvent) => {
                const acc = event.accelerationIncludingGravity;
                if (!acc) return;

                const currentTime = Date.now();
                if ((currentTime - lastTime) > 100) {
                    const diff = Math.abs(acc.x! + acc.y! + acc.z! - lastX - lastY - lastZ);
                    
                    if (diff > THRESHOLD) {
                         if ((currentTime - lastTime) > DELAY) {
                             // Step Detected
                             setStepStats(prev => ({
                                 steps: prev.steps + 1,
                                 distance: prev.distance + 0.00076, // Approx 0.76m per step
                                 calories: prev.calories + 0.04 // Approx 0.04 kcal per step
                             }));
                             lastTime = currentTime;
                         }
                    }

                    lastX = acc.x!;
                    lastY = acc.y!;
                    lastZ = acc.z!;
                }
            };

            window.addEventListener('devicemotion', motionHandler);
        } else {
            if (motionHandler) {
                window.removeEventListener('devicemotion', motionHandler);
            }
        }

        return () => {
            if (motionHandler) {
                window.removeEventListener('devicemotion', motionHandler);
            }
        };
    }, [isStepCounterActive]);

    const openModal = (type: ModalType, data?: any) => setModal({ type, data });
    const closeModal = () => setModal({ type: null });
    const showNotification = (message: string, type: 'success' | 'error' = 'success') => {
        console.log(`[${type.toUpperCase()}] ${message}`);
        // In a real app, you'd trigger a toast notification here
    };

    const handleToggleFollow = (username: string) => {
        setCurrentUser(prev => {
            const isFollowing = prev.following.includes(username);
            return {
                ...prev,
                following: isFollowing ? prev.following.filter(u => u !== username) : [...prev.following, username]
            };
        });
    };
    
    const handleToggleStepCounter = async () => {
        if (isStepCounterActive) {
            setIsStepCounterActive(false);
            return;
        }

        // Check for iOS 13+ permission requirement
        if (typeof (DeviceMotionEvent as any).requestPermission === 'function') {
            try {
                const permissionState = await (DeviceMotionEvent as any).requestPermission();
                if (permissionState === 'granted') {
                    setStepCounterPermissionState('granted');
                    setIsStepCounterActive(true);
                } else {
                    setStepCounterPermissionState('denied');
                    showNotification("Motion permission denied.", "error");
                }
            } catch (e) {
                console.error(e);
                setStepCounterPermissionState('denied');
            }
        } else {
            // Non-iOS or older devices usually don't need explicit permission
             setStepCounterPermissionState('granted');
             setIsStepCounterActive(true);
        }
    };

    const handleCreatePost = (postData: any) => {
        const newPost: Post = { ...postData, id: Date.now(), author: currentUser.username, avatarText: currentUser.avatarText, likes: 0, comments: [], savesCount: 0, shareCount: 0 };
        setPosts(prev => [newPost, ...prev]);
        showNotification("Post created!", "success");
    };

    const handleCreateReel = (reelData: any) => {
        const newReel: Reel = { ...reelData, id: Date.now(), user: currentUser.username, likes: 0, comments: [], isLiked: false, savesCount: 0, shareCount: 0, watchTimePercentage: 0, timestamp: Date.now(), category: 'General' };
        setReels(prev => [newReel, ...prev]);
        showNotification("Reel created!", "success");
    };

    const handleCreateStory = (storyData: any) => {
        const newStory: Story = { ...storyData, user: currentUser.username, avatarImage: currentUser.avatarImage };
        setStories(prev => ({
            ...prev,
            [currentUser.username]: [...(prev[currentUser.username] || []), newStory]
        }));
        showNotification("Story posted!", "success");
    };

    const handleLikePost = (postId: number) => {
        setPosts(posts.map(p => p.id === postId ? { ...p, isLiked: !p.isLiked, likes: p.isLiked ? p.likes - 1 : p.likes + 1 } : p));
    };

    const handleLikeReel = (reelId: number) => {
        setReels(reels.map(r => r.id === reelId ? { ...r, isLiked: !r.isLiked, likes: r.isLiked ? r.likes - 1 : r.likes + 1 } : r));
    };

    // FIXED: Implemented logic for creating PoW posts
    const handleCreateProofOfWorkout = (powData: any) => {
        const newPow: ProofOfWorkoutPost = {
            ...powData,
            id: Date.now().toString(),
            user: currentUser,
            isVerified: false,
            likes: 0,
            comments: [],
            isLiked: false,
            mediaUrl: powData.mediaBlobUrl // Map the blob URL
        };
        setProofOfWorkouts(prev => [newPow, ...prev]);
        // Add to general activity feed too for global visibility
        const newPost: Post = {
            id: Date.now(),
            author: currentUser.username,
            avatarText: currentUser.avatarText,
            mediaUrl: powData.mediaBlobUrl,
            mediaType: powData.mediaType,
            caption: `${powData.activity} - ${powData.notes}`,
            likes: 0,
            comments: [],
            savesCount: 0,
            shareCount: 0,
            type: 'proofOfWorkout',
            powDetails: {
                activity: powData.activity,
                duration: powData.duration,
                effort: powData.effort,
                sets: powData.sets,
                reps: powData.reps
            }
        };
        setPosts(prev => [newPost, ...prev]);
        showNotification("Proof of Workout posted successfully!", "success");
    };

    // FIXED: Implemented logic for creating routines
    const handleCreateRoutine = (routineData: any) => {
        const newRoutine: WorkoutRoutine = {
            ...routineData,
            id: Date.now().toString(),
            user: currentUser,
            savesCount: 0,
            likes: 0,
            comments: [],
            isLiked: false,
            rating: 0,
            ratingsCount: 0
        };
        setWorkoutRoutines(prev => [newRoutine, ...prev]);
        showNotification("Workout Routine published!", "success");
    };

    // FIXED: Implemented logic for liking PoW posts
    const handleLikeProofOfWorkout = (postId: string) => {
        setProofOfWorkouts(prev => prev.map(p => 
            p.id === postId 
            ? { ...p, isLiked: !p.isLiked, likes: p.isLiked ? p.likes - 1 : p.likes + 1 } 
            : p
        ));
    };

    // FIXED: Implemented logic for liking Routines
    const handleLikeWorkoutRoutine = (routineId: string) => {
        setWorkoutRoutines(prev => prev.map(r => 
            r.id === routineId 
            ? { ...r, isLiked: !r.isLiked, likes: r.isLiked ? r.likes - 1 : r.likes + 1 } 
            : r
        ));
    };

    // --- CART LOGIC ---
    const handleAddToCart = (product: GearItem, quantity: number, variant?: string) => {
        setCart(prev => {
            const existingIndex = prev.findIndex(item => item.product.id === product.id && item.selectedVariant === variant);
            if (existingIndex > -1) {
                const newCart = [...prev];
                newCart[existingIndex].quantity += quantity;
                return newCart;
            }
            return [...prev, { id: `${product.id}-${Date.now()}`, product, quantity, selectedVariant: variant }];
        });
        showNotification(`${product.title} added to cart!`, 'success');
    };

    const handleUpdateCartQuantity = (cartItemId: string, delta: number) => {
        setCart(prev => prev.map(item => {
            if (item.id === cartItemId) {
                const newQty = Math.max(0, item.quantity + delta);
                return { ...item, quantity: newQty };
            }
            return item;
        }).filter(item => item.quantity > 0));
    };

    const handleRemoveFromCart = (cartItemId: string) => {
        setCart(prev => prev.filter(item => item.id !== cartItemId));
    };
    
    const handleReviewSubmit = (itemId: string, review: Review) => {
        setGearItems(prev => prev.map(item => {
            if (item.id === itemId) {
                return {
                    ...item,
                    reviews: [review, ...(item.reviews || [])]
                };
            }
            return item;
        }));
        showNotification("Review submitted successfully!", "success");
    };
    
    // --- WALLET LOGIC (REAL SIMULATION) ---
    const handleTransaction = (type: 'send' | 'receive', coinId: string, amount: number, address?: string) => {
        setCoins(prevCoins => prevCoins.map(c => {
            if (c.id === coinId || c.symbol === coinId) {
                let newBalance = c.balance;
                if (type === 'send') {
                    if (c.balance < amount) {
                         showNotification(`Insufficient ${c.symbol} balance!`, 'error');
                         return c;
                    }
                    newBalance -= amount;
                } else {
                    newBalance += amount;
                }
                
                // Add Transaction record
                const newTx = {
                    id: `tx-${Date.now()}`,
                    type: type === 'send' ? 'sent' : 'received',
                    amount: amount,
                    date: new Date().toISOString().split('T')[0],
                    address: address || (type === 'send' ? 'External' : 'Faucet')
                };
                
                return { ...c, balance: newBalance, transactions: [newTx as any, ...c.transactions] };
            }
            return c;
        }));
        
        if (type === 'send') showNotification(`Sent ${amount} successfully!`, 'success');
        else showNotification(`Received ${amount} successfully!`, 'success');
    };

    const viewUserProfile = (user: UserProfile) => {
        openModal(ModalType.Profile, user);
    };

    const onNavigateToReel = (reelId: number) => {
        openModal(ModalType.ReelPlayer, { initialReelId: reelId });
    };

    const onPostDownloaded = () => {};
    const handleCreateGroup = (groupData: Partial<Group>) => {
      const newGroup: Group = {
        id: `group-${Date.now()}`,
        name: groupData.name || 'New Tribe',
        description: groupData.description || '',
        motto: groupData.motto || '',
        coverImage: groupData.coverImage,
        tags: groupData.tags,
        admin: currentUser,
        members: [currentUser],
        memberCount: 1,
        theme: groupData.theme!,
        goal: groupData.goal,
        requirements: groupData.requirements,
        socialLinks: groupData.socialLinks,
        entryQuestion: groupData.entryQuestion || '',
        pendingRequests: [],
        messages: [],
        isPrivate: groupData.isPrivate || false,
        location: groupData.location,
    };
    setGroups(prev => [newGroup, ...prev]);
    };
    const onSendMessage = () => {};
    const onSendDm = () => {};
    const onPinMessage = () => {};
    const onAddCallLog = () => {};
    const handleJoinChallenge = () => {};
    const handleOpenGroup = (group: Group) => openModal(ModalType.GroupChat, group);
    const onAddMeal = () => {};
    const onUpdateProfile = () => {};
    const onCreateHighlight = () => {};
    const handleBlockUser = () => {};
    const handleLogout = () => setIsAuthenticated(false);
    
    const onUpdateUserProfileData = async (newData: any) => {
        // 1. Immediate optimistic update of basic data
        setUserProfileData((prev: any) => ({ ...prev, ...newData }));

        // 2. Call AI for scientific analysis
        try {
            const languageName = 'English'; 
            const aiResult = await generateAdvancedDietPlan(newData, languageName);

            // 3. Update state with AI results
            setUserProfileData((prev: any) => ({
                ...prev,
                aiDietPlan: aiResult
            }));

            // 4. Update Nutrition Goals
            if (aiResult.macros) {
                setNutritionGoals({
                    cal: aiResult.targetCalories,
                    pro: aiResult.macros.protein,
                    carb: aiResult.macros.carbs,
                    fat: aiResult.macros.fat
                });
            }
             showNotification("Profile & Diet Plan Updated by AI!", "success");
        } catch (error) {
            console.error("AI Plan Error:", error);
            showNotification("Failed to update AI plan.", "error");
        }
    };
    const onAddToken = () => {};
    
    const handleCreateNFT = (newNft: NFT) => {
        setNfts(prevNfts => [newNft, ...prevNfts]);
        showNotification("NFT successfully listed on the marketplace!", "success");
    };

    const handleCreateGear = (newGear: GearItem) => {
        setGearItems(prevGear => [newGear, ...prevGear]);
        showNotification("Gear listing created successfully!", "success");
    };

    const handleMediaSelected = (file: File, type: 'post' | 'reel' | 'story') => {
        const mediaType = file.type.startsWith('video/') ? 'video' : 'image';
        
        closeModal(); // Close the create selection modal

        if (type === 'story') {
            openModal(ModalType.StoryEditor, { mediaFile: file });
        } else if (type === 'reel') {
            openModal(ModalType.ReelEditor, { mediaFile: file });
        } else if (type === 'post') {
            if (mediaType === 'video') {
                openModal(ModalType.VideoEditor, { mediaFile: file });
            } else {
                openModal(ModalType.PostImageEditor, { mediaFile: file });
            }
        }
    };
    
    const markAsRead = (id: string) => {
        setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
    };
    const markAllAsRead = () => {
        setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
    };
    const onAddComment = (mediaId: number | string, commentText: string, mediaType: 'post' | 'reel' | 'pow' | 'routine') => {
        const newComment = { id: Date.now(), user: currentUser.username, text: commentText };
        // Logic to update the specific content type's state
        if (mediaType === 'pow') {
             setProofOfWorkouts(prev => prev.map(p => p.id === mediaId ? { ...p, comments: [...p.comments, newComment] } : p));
        } else if (mediaType === 'routine') {
             setWorkoutRoutines(prev => prev.map(r => r.id === mediaId ? { ...r, comments: [...r.comments, newComment] } : r));
        } else if (mediaType === 'post') {
             setPosts(prev => prev.map(p => p.id === mediaId ? { ...p, comments: [...p.comments, newComment] } : p));
        } else if (mediaType === 'reel') {
             setReels(prev => prev.map(r => r.id === mediaId ? { ...r, comments: [...r.comments, newComment] } : r));
        }
        showNotification("Comment posted!");
    };
    
    const onPostShared = (content: Post | Reel | NFT, recipientUsername: string) => {
        const isNft = 'collection' in content;
        const newMessage: GroupMessage = {
            id: Date.now().toString(),
            sender: currentUser,
            type: isNft ? 'nft_share' : 'post_share',
            timestamp: Date.now(),
            sharedNft: isNft ? content : undefined,
            sharedPost: !isNft ? content : undefined,
        };
        setMessages(prev => ({
            ...prev,
            [recipientUsername]: [...(prev[recipientUsername] || []), newMessage]
        }));
        openModal(ModalType.GroupChat);
    };

    const onClaim = (amount: number) => {
        setFitTokenBalance(prev => prev + amount);
    };
     const onVideoGenerated = (url: string) => {
        fetch(url)
            .then(res => res.blob())
            .then(blob => {
                const file = new File([blob], "ai_generated_video.mp4", { type: blob.type });
                openModal(ModalType.ReelEditor, { mediaFile: file });
            });
    };

    const renderPage = () => {
        switch (currentPage) {
            case Page.Home: return <HomePage posts={posts} stories={stories} openModal={openModal} language="en" currentUser={currentUser} handleToggleFollow={handleToggleFollow} handleLikePost={handleLikePost} viewUserProfile={viewUserProfile} users={users} onPostDownloaded={() => {}} onNavigateToReel={onNavigateToReel} showNotification={showNotification} />;
            case Page.Explore: return <ExplorePage openModal={openModal} onViewReelsFeed={() => {}} isProUser={true} fitTokenBalance={fitTokenBalance} setFitTokenBalance={setFitTokenBalance} setNfts={setNfts} nfts={nfts} viewUserProfile={viewUserProfile} currentUser={currentUser} handleToggleFollow={handleToggleFollow} users={users} posts={posts} reels={reels} proofOfWorkouts={proofOfWorkouts} workoutRoutines={workoutRoutines} handleLikeProofOfWorkout={handleLikeProofOfWorkout} handleLikeWorkoutRoutine={handleLikeWorkoutRoutine} earnedNfts={[]} challenges={challenges} handleJoinChallenge={() => {}} groups={groups} handleOpenGroup={handleOpenGroup} onAddMeal={() => {}} userProfileData={userProfileData} nutritionHistory={nutritionHistory} foodLog={foodLog} nutritionGoals={nutritionGoals} gearItems={gearItems} setGearItems={setGearItems} cartItemCount={cart.reduce((acc, item) => acc + item.quantity, 0)} />;
            case Page.Reels: return <ReelsPage language="en" openModal={openModal} reels={reels} currentUser={currentUser} handleToggleFollow={handleToggleFollow} handleLikeReel={handleLikeReel} viewUserProfile={viewUserProfile} users={users} onPostDownloaded={() => {}} />;
            case Page.Exercise: return <ExercisePage openModal={openModal} isProUser={true} />;
            case Page.Profile: return <ProfilePage openModal={openModal} isProUser={true} fitTokenBalance={fitTokenBalance} userProfileData={userProfileData} nutritionHistory={nutritionHistory} nutritionGoals={nutritionGoals} setFitTokenBalance={setFitTokenBalance} showNotification={showNotification} currentUser={currentUser} handleToggleFollow={handleToggleFollow} handleBlockUser={() => {}} profile={currentUser} coins={coins} nfts={nfts} posts={posts} reels={reels} proofOfWorkouts={proofOfWorkouts} workoutRoutines={workoutRoutines} stepStats={stepStats} isStepCounterActive={isStepCounterActive} stepCounterPermissionState={stepCounterPermissionState} onToggleStepCounter={handleToggleStepCounter} activityHistory={activityHistory} waterCount={waterCount} setWaterCount={setWaterCount} theme={theme} onUpdateProfile={() => {}} onCreateHighlight={() => {}} badgeData={badgeData} earnedBadgeIds={earnedBadgeIds} getBadgeProgress={getBadgeProgress} onUpdateUserProfileData={onUpdateUserProfileData} />;
            default: return <HomePage posts={posts} stories={stories} openModal={openModal} language="en" currentUser={currentUser} handleToggleFollow={handleToggleFollow} handleLikePost={handleLikePost} viewUserProfile={viewUserProfile} users={users} onPostDownloaded={() => {}} onNavigateToReel={onNavigateToReel} showNotification={showNotification} />;
        }
    };
    
    const renderModal = () => {
        if (!modal.type) return null;
        const props = { closeModal, openModal, modalData: modal.data, currentUser, users };
        switch (modal.type) {
            case ModalType.AiCoach: return <AiCoachModal closeModal={closeModal} currentUser={currentUser} users={users} posts={posts} reels={reels} groups={groups} />;
            case ModalType.VideoGeneration: return <VideoGenerationModal closeModal={closeModal} />;
            case ModalType.ImageGeneration: return <ImageGenerationModal closeModal={closeModal} />;
            case ModalType.ContentAnalysis: return <ContentAnalysisModal closeModal={closeModal} modalData={modal.data} />;
            case ModalType.CreatePost: return <UnifiedCreateModal {...props} onMediaSelected={handleMediaSelected} handleCreatePost={handleCreatePost} handleCreateReel={handleCreateReel} handleCreateStory={handleCreateStory} />;
            case ModalType.ReelEditor: return <ReelEditorModal closeModal={closeModal} handleCreateReel={handleCreateReel} modalData={modal.data} openModal={openModal} />;
            case ModalType.StoryEditor: return <StoryEditorModal closeModal={closeModal} handleCreateStory={handleCreateStory} modalData={modal.data} />;
            case ModalType.PostImageEditor: return <PostImageEditorModal closeModal={closeModal} onSave={handleCreatePost} modalData={modal.data} />;
            case ModalType.VideoEditor: return <VideoEditorModal closeModal={closeModal} onSave={handleCreatePost} mode="post" modalData={modal.data} />;
            case ModalType.GroupChat: return <GroupChatModal {...props} joinedGroups={groups} messages={messages} onSendMessage={onSendMessage} onSendDm={onSendDm} onPinMessage={onPinMessage} fitTokenBalance={fitTokenBalance} setCurrentPage={setCurrentPage} handleToggleFollow={handleToggleFollow} showNotification={showNotification} handleBlockUser={handleBlockUser} callLogs={callLogs} onAddCallLog={onAddCallLog} />;
            case ModalType.CreateGroup: return <CreateGroupModal closeModal={closeModal} handleCreateGroup={handleCreateGroup} />;
            
            // Updated: Pass Cart Handler and Review Handler
            case ModalType.ProductDetail: 
                // If opening from modal.data, ensure it reflects the latest state if it's a gear item
                const currentItem = gearItems.find(g => g.id === modal.data.id) || modal.data;
                return <ProductDetailModal item={currentItem} {...props} onAddToCart={handleAddToCart} onReviewSubmit={handleReviewSubmit} />;
            
            case ModalType.CreateListing: return <CreateListingModal {...props} handleCreateNFT={handleCreateNFT} handleCreateGear={handleCreateGear} />;
            
            // NEW: Cart Modal
            case ModalType.Cart: return <CartModal closeModal={closeModal} cart={cart} updateQuantity={handleUpdateCartQuantity} removeFromCart={handleRemoveFromCart} />;
            
            // AI Modals
            case ModalType.ImageEditing: return <ImageEditingModal {...props} onSave={handleCreatePost} />;
            case ModalType.TextToSpeech: return <TextToSpeechModal closeModal={closeModal} />;
            case ModalType.SpeechToText: return <SpeechToTextModal closeModal={closeModal} />;
            case ModalType.AdaptiveWorkout: return <AdaptiveWorkoutModal closeModal={closeModal} openModal={openModal} activityHistory={activityHistory} userProfileData={userProfileData} currentUser={currentUser} />;
            case ModalType.HolographicForm: return <HolographicFormModal closeModal={closeModal} openModal={openModal} />;
            case ModalType.NeuralLink: return <NeuralLinkModal closeModal={closeModal} />;
            case ModalType.QuantumHrv: return <QuantumHrvModal closeModal={closeModal} />;
            case ModalType.BodyMap: return <BodyMapModal closeModal={closeModal} fitTokenBalance={fitTokenBalance} setFitTokenBalance={setFitTokenBalance} />;
            case ModalType.AiWorkoutGenerator: return <AiWorkoutGeneratorModal closeModal={closeModal} openModal={openModal} currentUser={currentUser} />;
            case ModalType.WorkoutPlan: return <WorkoutPlanModal closeModal={closeModal} plan={modal.data} />;
            case ModalType.WorkoutVideoGeneration: return <WorkoutVideoGeneratorModal closeModal={closeModal} />;
            case ModalType.AiReelGenerator: return <AiReelGeneratorModal closeModal={closeModal} onVideoGenerated={onVideoGenerated} />;
            case ModalType.AiRecipe: return <AiRecipeModal closeModal={closeModal} userProfileData={userProfileData} foodLog={foodLog} />;
            case ModalType.PostAnalysis: return <PostAnalysisModal closeModal={closeModal} isLoading={false} analysisResult={modal.data} error={null} />;

            // Other Functional Modals
            case ModalType.Notifications: return <NotificationsModal closeModal={closeModal} notifications={notifications} users={users} markAsRead={markAsRead} markAllAsRead={markAllAsRead} openModal={openModal} />;
            case ModalType.PremiumPitch: return <PremiumPitchModal closeModal={closeModal} />;
            case ModalType.Settings: return <SettingsModal closeModal={closeModal} theme={theme} setTheme={setTheme} showNotification={showNotification} fitTokenBalance={fitTokenBalance} handleLogout={handleLogout} openModal={openModal} customTheme={customTheme} setCustomTheme={setCustomTheme} currentUser={currentUser} onUpdateProfile={onUpdateProfile as any} />;
            case ModalType.StoryViewer: return <StoryViewerModal stories={modal.data.stories} closeModal={closeModal} startIndex={modal.data.startIndex} openModal={openModal} users={users} />;
            case ModalType.DataEntry: return <DataEntryModal closeModal={closeModal} currentData={userProfileData} onSave={onUpdateUserProfileData} />;
            case ModalType.AddMeal: return <AddMealModal closeModal={closeModal} onAddMacros={onAddMeal as any} isProUser={true} openModal={openModal} currentDate={modal.data?.date} />;
            case ModalType.CreateRoutine: return <CreateRoutineModal closeModal={closeModal} showNotification={showNotification} openModal={openModal} handleCreateRoutine={handleCreateRoutine} />;
            case ModalType.ReactionTest: return <ReactionTestModal closeModal={closeModal} />;
            case ModalType.WorkoutMode: return <WorkoutModeModal closeModal={closeModal} isProUser={true} openModal={openModal} />;
            case ModalType.RunningMode: return <RunningModeModal closeModal={closeModal} isProUser={true} openModal={openModal} />;
            case ModalType.CryptoRewards: return <CryptoRewardsModal closeModal={closeModal} fitTokenBalance={fitTokenBalance} onClaim={onClaim} data={modal.data} />;
            case ModalType.StakeChallenge: return <StakeChallengeModal closeModal={closeModal} currentBalance={fitTokenBalance} onStake={(details) => console.log('Staking', details)} openModal={openModal} />;
            case ModalType.MetaGym: return <MetaGymModal closeModal={closeModal} users={users} currentUser={currentUser} />;
            case ModalType.SharePost: return <SharePostModal {...props} showNotification={showNotification} onPostShared={onPostShared} />;
            case ModalType.Comments: return <CommentsModal {...props} comments={modal.data.comments || []} onAddComment={onAddComment as any} />;
            // Pass Coin Detail and Transaction Handlers
            case ModalType.CoinDetails: return <CoinDetailModal closeModal={closeModal} openModal={openModal} coin={modal.data} />;
            case ModalType.NftDetails: return <NftDetailModal closeModal={closeModal} nft={modal.data} />;
            case ModalType.SendCoin: 
                // Ensure we are working with the live coin object from state to reflect balance updates
                const coinToSend = coins.find(c => c.id === modal.data?.id) || modal.data;
                return <SendModal closeModal={closeModal} coin={coinToSend} showNotification={showNotification} onSendTransaction={(amount, address) => handleTransaction('send', coinToSend.id, amount, address)} />;
            case ModalType.ReceiveCoin: return <ReceiveModal closeModal={closeModal} onReceiveTransaction={(amount) => handleTransaction('receive', 'ETH', amount)} />; // Defaulting to ETH for quick demo
            
            case ModalType.AddToken: return <AddTokenModal closeModal={closeModal} onAddToken={onAddToken as any} showNotification={showNotification} />;
            case ModalType.ExerciseList: return <ExerciseListModal closeModal={closeModal} openModal={openModal} modalData={modal.data} />;
            case ModalType.ExerciseDetail: return <ExerciseDetailModal closeModal={closeModal} modalData={modal.data} />;
            case ModalType.EditProfile: return <EditProfileModal closeModal={closeModal} currentUser={currentUser} onUpdateProfile={onUpdateProfile as any} />;
            case ModalType.CreateHighlight: return <CreateHighlightModal closeModal={closeModal} onCreateHighlight={onCreateHighlight as any} />;
            case ModalType.FollowList: return <FollowListModal {...props} type={modal.data.type} profile={modal.data.profile} allUsers={users} handleToggleFollow={handleToggleFollow} viewUserProfile={viewUserProfile} />;
            case ModalType.CreateChallenge: return <CreateChallengeModal closeModal={closeModal} showNotification={showNotification} handleCreateChallenge={handleJoinChallenge as any} currentUser={currentUser} />;
            case ModalType.ProofOfWorkout: return <ProofOfWorkoutModal closeModal={closeModal} showNotification={showNotification} handleCreateProofOfWorkout={handleCreateProofOfWorkout} modalData={modal.data} />;
            
            // FIX: Pass live proofOfWorkout post from state to modal to ensure reactivity
            case ModalType.ProofOfWorkoutDetail: 
                const livePow = proofOfWorkouts.find(p => p.id === modal.data.id) || modal.data;
                return <ProofOfWorkoutDetailModal {...props} post={livePow} handleLikeProofOfWorkout={handleLikeProofOfWorkout} onAddComment={(id, text) => onAddComment(id, text, 'pow')} viewUserProfile={viewUserProfile} currentUser={currentUser} />;
            
            case ModalType.ThemeCustomization: return <ThemeCustomizationModal closeModal={closeModal} setCustomTheme={setCustomTheme} />;
            
            // FIX: Pass live post from state to modal to ensure reactivity
            case ModalType.PostDetail: 
                const livePost = posts.find(p => p.id === modal.data.id) || modal.data;
                return <PostDetailModal {...props} post={livePost} handleLikePost={handleLikePost} onAddComment={(id, text) => onAddComment(id, text, 'post')} viewUserProfile={viewUserProfile} currentUser={currentUser} />;
            
            case ModalType.DailyNutritionDetail: return <DailyNutritionModal closeModal={closeModal} foodLog={foodLog} date={modal.data.date} totalMacros={nutritionHistory.find(h => h.date === modal.data.date)?.macros || {cal:0,pro:0,carb:0,fat:0}} goals={nutritionGoals} />;
            case ModalType.GroupJoin: return <GroupJoinModal closeModal={closeModal} group={modal.data} handleJoin={(group) => console.log('joining', group)} fitTokenBalance={fitTokenBalance} currentUser={currentUser} openModal={openModal} />;
            case ModalType.GroupProfile: return <GroupProfileModal {...props} groups={groups} fitTokenBalance={fitTokenBalance} />;
            case ModalType.ReelPlayer: return <ReelsPage language="en" openModal={openModal} reels={reels} initialReelId={modal.data.initialReelId} currentUser={currentUser} handleToggleFollow={handleToggleFollow} handleLikeReel={handleLikeReel} viewUserProfile={viewUserProfile} users={users} onPostDownloaded={onPostDownloaded} />;
            case ModalType.ProgramDetails: 
            case ModalType.RoutineDetails:
            case ModalType.ChallengeDetails: return <DetailsModal closeModal={closeModal} type={modal.type.split('-')[0] as any} data={modal.data} />;

            default: return null;
        }
    };

    if (!isAuthenticated) {
        return <AuthModal onLoginSuccess={(user) => { setCurrentUser(user); setIsAuthenticated(true); }} onSignUp={(newUser) => setUsers(prev => [...prev, newUser])} existingUsers={users} />;
    }

    return (
        <div className="h-full w-full bg-black flex flex-col font-sans relative">
            {!modal.type || ![ModalType.GroupChat].includes(modal.type) ? <Header openModal={openModal} unreadCount={notifications.length} /> : null}
            <main className="flex-1 overflow-y-auto w-full max-w-screen-lg mx-auto">
                {renderPage()}
            </main>
            {/* Floating AI Coach Button */}
            {!modal.type && (
                <button 
                    onClick={() => openModal(ModalType.AiCoach)}
                    className="absolute bottom-24 right-4 z-40 w-16 h-16 bg-gradient-to-br from-emerald-500 to-cyan-500 rounded-full flex items-center justify-center shadow-2xl shadow-emerald-500/30 transform hover:scale-110 transition-transform animate-pulsate"
                    aria-label="Open AI Coach"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/><path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/></svg>
                </button>
            )}
            {!modal.type || ![ModalType.GroupChat].includes(modal.type) ? <NavBar currentPage={currentPage} setCurrentPage={setCurrentPage} /> : null}
            {renderModal()}
        </div>
    );
};

export default App;
