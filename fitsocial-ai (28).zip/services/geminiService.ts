import { GoogleGenAI, Type, Schema, LiveServerMessage, Modality, Content, Part } from "@google/genai";
import { ActivityRecord, AdaptiveWorkoutPlan, AiRecipeResponse, DetailedUserProfileData, FoodLogEntry, WorkoutRoutine, AiDietPlan } from '../types';

// --- Models ---
// Using widely available stable models to prevent 404 errors
const MODEL_TEXT = 'gemini-2.5-flash'; 
const MODEL_IMAGE = 'gemini-2.5-flash-image';
const MODEL_VIDEO = 'veo-3.1-fast-generate-preview';
const MODEL_SPEECH = 'gemini-2.5-flash-preview-tts';
const MODEL_LIVE = 'gemini-2.5-flash-native-audio-preview-09-2025';

// --- Helpers ---

const getAiClient = () => {
    const API_KEY = process.env.API_KEY;
    if (!API_KEY) {
        console.error("API_KEY environment variable not set");
        // We don't throw immediately to allow UI to handle the missing key gracefully via error states
    }
    return new GoogleGenAI({ apiKey: API_KEY });
};

const cleanJsonString = (text: string): string => {
    return text.replace(/```json|```/g, '').trim();
};

// --- Chat Service ---

export const createChat = (language: string = 'English', history: Content[] = []) => {
    const ai = getAiClient();
    return ai.chats.create({
        model: MODEL_TEXT,
        messages: history,
        config: {
            systemInstruction: `You are FitSocial AI, an elite fitness and health coach. 
            Your persona is professional yet motivating, slightly futuristic (Cyberpunk/High-tech).
            **IMPORTANT:** You must initialize your conversation and responses in **${language}**.
            However, if the user switches to a different language during the conversation, you must immediately adapt and respond in that new language.
            Keep responses concise and actionable.`,
        }
    });
};

export const sendMessageInChat = async (chatSession: any, message: string) => {
    const response = await chatSession.sendMessage({ message });
    return response;
};

// --- Text Generation Services ---

export const generateText = async (prompt: string, useSearch: boolean, useMaps: boolean, useThinking: boolean, userLocation?: { latitude: number, longitude: number } | null) => {
    const ai = getAiClient();
    const tools: any[] = [];
    if (useSearch) tools.push({ googleSearch: {} });
    if (useMaps) tools.push({ googleMaps: {} });

    const config: any = {
        tools: tools.length > 0 ? tools : undefined,
    };

    if (useMaps && userLocation) {
        config.toolConfig = {
            retrievalConfig: {
                latLng: {
                    latitude: userLocation.latitude,
                    longitude: userLocation.longitude
                }
            }
        };
    }
    
    const response = await ai.models.generateContent({
        model: MODEL_TEXT,
        contents: prompt,
        config: config
    });

    return response;
};

export const translateText = async (text: string, targetLanguage: string): Promise<string> => {
    const ai = getAiClient();
    const response = await ai.models.generateContent({
        model: MODEL_TEXT,
        contents: `Translate the following text to ${targetLanguage}. Return ONLY the translation, nothing else.\n\nText: "${text}"`
    });
    return response.text?.trim() || text;
};

// --- Analysis Services ---

export const analyzeContent = async (prompt: string, base64Data: string, mimeType: string): Promise<string> => {
    const ai = getAiClient();
    try {
        // We use the text model (flash) because it handles multimodal input via GenerateContent.
        // CRITICAL SPEED FIX: Explicitly set thinkingBudget to 0 to disable the reasoning chain.
        // This makes the model respond almost instantly for video/image analysis.
        const response = await ai.models.generateContent({
            model: MODEL_TEXT, 
            contents: {
                parts: [
                    { inlineData: { mimeType, data: base64Data } },
                    { text: prompt }
                ]
            },
            config: {
                thinkingConfig: { thinkingBudget: 0 } // Disable thinking for max speed
            }
        });
        return response.text || "Analysis yielded no text results.";
    } catch (e: any) {
        console.error("Gemini Analysis Error:", e);
        if (e.message?.includes('413')) {
            throw new Error("The media file is too large for the browser to handle directly. Please use a smaller file or shorter duration for this demo.");
        }
        throw e;
    }
};

export const analyzeUserPosts = async (captions: string[], language: string): Promise<string> => {
    const ai = getAiClient();
    const prompt = `Analyze these social media posts and provide a psychological profile and fitness personality assessment. 
    Respond in ${language}. Format in Markdown.
    
    Posts:
    ${captions.join('\n')}
    `;
    const response = await ai.models.generateContent({ model: MODEL_TEXT, contents: prompt });
    return response.text || "Could not analyze posts.";
};

export const generateActivitySummary = async (history: ActivityRecord[], language: string): Promise<string> => {
    const ai = getAiClient();
    const prompt = `Analyze this 7-day activity history and provide a brief, motivating summary in ${language}.
    
    Data: ${JSON.stringify(history)}
    `;
    const response = await ai.models.generateContent({ model: MODEL_TEXT, contents: prompt });
    return response.text || "No summary available.";
};

export const generateNutritionSummary = async (macros: any, goals: any, language: string): Promise<string> => {
    const ai = getAiClient();
    const prompt = `Compare these daily macros to the goals and give 1 sentence of advice in ${language}.
    Consumed: ${JSON.stringify(macros)}
    Goal: ${JSON.stringify(goals)}
    `;
    const response = await ai.models.generateContent({ model: MODEL_TEXT, contents: prompt });
    return response.text || "Keep eating healthy!";
};

export const analyzeMealForNutrition = async (description: string): Promise<any> => {
    const ai = getAiClient();
    const schema: Schema = {
        type: Type.OBJECT,
        properties: {
            cal: { type: Type.NUMBER },
            pro: { type: Type.NUMBER },
            carb: { type: Type.NUMBER },
            fat: { type: Type.NUMBER },
            fiber: { type: Type.NUMBER },
            sugar: { type: Type.NUMBER },
            sodium: { type: Type.NUMBER },
            potassium: { type: Type.NUMBER },
            saturatedFat: { type: Type.NUMBER },
            vitamins: { type: Type.STRING, description: "Key vitamins present" }
        },
        required: ["cal", "pro", "carb", "fat"]
    };

    const response = await ai.models.generateContent({
        model: MODEL_TEXT,
        contents: `Analyze the nutrition of: "${description}". Return JSON.`,
        config: {
            responseMimeType: "application/json",
            responseSchema: schema
        }
    });

    // FIX: response.text is a property, not a method.
    const jsonStr = cleanJsonString(response.text || "{}");
    return JSON.parse(jsonStr);
};

// --- Plan Generation Services ---

export const generateAdvancedDietPlan = async (userProfile: DetailedUserProfileData, language: string): Promise<AiDietPlan> => {
    const ai = getAiClient();
    const prompt = `
        ACT AS AN ELITE SPORTS PHYSIOLOGIST AND REGISTERED DIETITIAN.
        Calculate scientifically accurate daily calorie/macro needs for the user.
        
        **CRITICAL RULES FOR REALISM:**
        1. **Protein Cap:** Protein should NOT exceed 2.2g per kg of bodyweight unless the user is an elite bodybuilder on gear. A safe range is 1.6g - 2.2g/kg for muscle gain.
        2. **Fat Range:** Fat should be around 0.8g - 1.0g per kg of bodyweight.
        3. **Calorie Logic:** TDEE = BMR * Activity. Do NOT suggest 3000+ calories unless the user is very heavy and extremely active. For a standard 75kg male, maintenance is ~2500.
        4. **Weight Loss:** If goal is weight loss, subtract 300-500 kcal from TDEE.
        5. **Muscle Gain:** If goal is muscle gain, add 200-300 kcal to TDEE.
        6. **MET Values:** Use accurate MET values for sports (e.g. Tennis ~7.3 METs).

        **USER DATA:**
        - Weight: ${userProfile.weight} kg
        - Height: ${userProfile.height} cm
        - Age: ${userProfile.age} years
        - Gender: ${userProfile.gender}
        - Activity Multiplier: ${userProfile.activity}
        - Goal: ${userProfile.fitnessGoal}
        - Active Sports: ${JSON.stringify(userProfile.activeSports || [])}

        **OUTPUT FORMAT:**
        Return ONLY raw JSON matching the schema. Do not include Markdown.
    `;

    const schema: Schema = {
        type: Type.OBJECT,
        properties: {
            bmr: { type: Type.NUMBER },
            baseBurn: { type: Type.NUMBER },
            sportsBurn: { type: Type.NUMBER },
            workoutBurnPerSession: { type: Type.NUMBER },
            tdee: { type: Type.NUMBER },
            targetCalories: { type: Type.NUMBER },
            calorieStrategy: { type: Type.STRING },
            calorieAdjustment: { type: Type.NUMBER },
            macros: {
                type: Type.OBJECT,
                properties: {
                    protein: { type: Type.NUMBER },
                    carbs: { type: Type.NUMBER },
                    fat: { type: Type.NUMBER },
                }
            },
            sportsBreakdown: {
                type: Type.ARRAY,
                items: {
                    type: Type.OBJECT,
                    properties: {
                        name: { type: Type.STRING },
                        calories: { type: Type.NUMBER },
                        hourlyBurn: { type: Type.NUMBER }
                    }
                }
            },
            advice: { type: Type.STRING },
        },
        required: ["bmr", "baseBurn", "sportsBurn", "workoutBurnPerSession", "tdee", "targetCalories", "calorieStrategy", "macros", "sportsBreakdown", "advice"]
    };

    const response = await ai.models.generateContent({
        model: MODEL_TEXT,
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: schema,
            thinkingConfig: { thinkingBudget: 0 } // Disable thinking for max speed
        }
    });

    // FIX: response.text is a property, not a method.
    return JSON.parse(cleanJsonString(response.text || "{}"));
};

export const generateDailyChallenge = async (language: string): Promise<{ title: string, description: string, goal: string }> => {
    const ai = getAiClient();
    const schema: Schema = {
        type: Type.OBJECT,
        properties: {
            title: { type: Type.STRING },
            description: { type: Type.STRING },
            goal: { type: Type.STRING },
        },
        required: ["title", "description", "goal"]
    };

    const response = await ai.models.generateContent({
        model: MODEL_TEXT,
        contents: `Generate a fun, single-day fitness challenge in ${language}.`,
        config: {
            responseMimeType: "application/json",
            responseSchema: schema
        }
    });
    
    // FIX: response.text is a property, not a method.
    return JSON.parse(cleanJsonString(response.text || "{}"));
};

export const generateWorkoutPlan = async (options: any, language: string): Promise<any> => {
    const ai = getAiClient();
    const prompt = `Generate a 4-week workout plan based on this profile: ${JSON.stringify(options)}. Language: ${language}`;
    
    const schema: Schema = {
        type: Type.OBJECT,
        properties: {
            planName: { type: Type.STRING },
            description: { type: Type.STRING },
            weeks: {
                type: Type.ARRAY,
                items: {
                    type: Type.OBJECT,
                    properties: {
                        week: { type: Type.INTEGER },
                        dailySchedule: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    day: { type: Type.STRING },
                                    focus: { type: Type.STRING },
                                    exercises: {
                                        type: Type.ARRAY,
                                        items: {
                                            type: Type.OBJECT,
                                            properties: {
                                                name: { type: Type.STRING },
                                                sets: { type: Type.STRING },
                                                reps: { type: Type.STRING },
                                                rest: { type: Type.STRING },
                                                notes: { type: Type.STRING }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    };

    const response = await ai.models.generateContent({
        model: MODEL_TEXT,
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: schema
        }
    });
    
    // FIX: response.text is a property, not a method.
    return JSON.parse(cleanJsonString(response.text || "{}"));
};

export const generateAdaptiveWorkout = async (options: any, language: string): Promise<AdaptiveWorkoutPlan> => {
    const ai = getAiClient();
    const prompt = `Create a single workout session based on user's current state: ${JSON.stringify(options)}. Language: ${language}`;
    
    const schema: Schema = {
        type: Type.OBJECT,
        properties: {
            workoutTitle: { type: Type.STRING },
            aiRationale: { type: Type.STRING },
            warmup: {
                type: Type.ARRAY,
                items: {
                    type: Type.OBJECT,
                    properties: { name: { type: Type.STRING }, duration: { type: Type.STRING } }
                }
            },
            exercises: {
                type: Type.ARRAY,
                items: {
                    type: Type.OBJECT,
                    properties: { 
                        name: { type: Type.STRING }, 
                        sets: { type: Type.STRING }, 
                        reps: { type: Type.STRING }, 
                        rest: { type: Type.STRING } 
                    }
                }
            },
            cooldown: {
                type: Type.ARRAY,
                items: {
                    type: Type.OBJECT,
                    properties: { name: { type: Type.STRING }, duration: { type: Type.STRING } }
                }
            }
        }
    };

    const response = await ai.models.generateContent({
        model: MODEL_TEXT,
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: schema
        }
    });

    // FIX: response.text is a property, not a method.
    return JSON.parse(cleanJsonString(response.text || "{}"));
};

export const generateAiKitchenPlan = async (type: 'pantry' | 'meal_plan', userProfile: DetailedUserProfileData, input: string[], language: string, eatenToday: FoodLogEntry[] = [], eatenYesterday: FoodLogEntry[] = []): Promise<AiRecipeResponse> => {
    const ai = getAiClient();
    const formatMeals = (logs: FoodLogEntry[]) => logs.map(e => `[${e.mealType}]: ${e.name}`).join(', ');

    const historyContext = `
        HISTORY CONTEXT:
        - YESTERDAY the user ate: ${eatenYesterday.length > 0 ? formatMeals(eatenYesterday) : 'Unknown/Nothing logged'}.
        - TODAY the user has already eaten: ${eatenToday.length > 0 ? formatMeals(eatenToday) : 'Nothing yet'}.
        
        CRITICAL INSTRUCTION: 
        1. Avoid repeating the exact same main meal sources from YESTERDAY to ensure nutritional variety (e.g., if yesterday breakfast was Eggs, suggest Oatmeal or Yoghurt today). 
        2. Provide DIFFERENT proteins and mineral sources than yesterday.
        3. Ensure suggestions are appropriate for the requested meal type (Breakfast items for Breakfast, etc).
    `;

    const prompt = type === 'pantry' 
        ? `Create a recipe using these ingredients: ${input.join(', ')}. User profile: ${JSON.stringify(userProfile)}. ${historyContext} Language: ${language}. Be precise with nutritional values.`
        : `Create a daily meal plan for this user: ${JSON.stringify(userProfile)}. ${historyContext} Language: ${language}. Be precise with nutritional values.`;
        
    const schema: Schema = {
        type: Type.OBJECT,
        properties: {
            planName: { type: Type.STRING },
            aiAnalysis: { type: Type.STRING },
            meals: {
                type: Type.ARRAY,
                items: {
                    type: Type.OBJECT,
                    properties: {
                        type: { type: Type.STRING, description: "Meal type (Breakfast, Lunch, Dinner, Snack)" },
                        name: { type: Type.STRING },
                        ingredients: { type: Type.ARRAY, items: { type: Type.STRING } },
                        missingIngredients: { type: Type.ARRAY, items: { type: Type.STRING } },
                        instructions: { type: Type.ARRAY, items: { type: Type.STRING } },
                        macros: {
                            type: Type.OBJECT,
                            properties: {
                                calories: { type: Type.NUMBER },
                                protein: { type: Type.NUMBER },
                                carbs: { type: Type.NUMBER },
                                fat: { type: Type.NUMBER },
                                fiber: { type: Type.NUMBER },
                                sugar: { type: Type.NUMBER },
                                sodium: { type: Type.NUMBER },
                                potassium: { type: Type.NUMBER },
                                saturatedFat: { type: Type.NUMBER },
                                vitamins: { type: Type.STRING }
                            }
                        }
                    }
                }
            }
        }
    };

    const response = await ai.models.generateContent({
        model: MODEL_TEXT,
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: schema
        }
    });

    // FIX: response.text is a property, not a method.
    return JSON.parse(cleanJsonString(response.text || "{}"));
};

// --- Media Generation Services ---

export const generateImage = async (prompt: string): Promise<string> => {
    const ai = getAiClient();
    // Enhanced prompt for creativity and realism
    const enhancedPrompt = `
    GENERATE A HYPER-REALISTIC, CREATIVE IMAGE.
    User Request: "${prompt}"
    
    Guidelines:
    - Use cinematic lighting (ray tracing, global illumination).
    - High definition textures (8k resolution style).
    - If humans are present, ensure anatomical correctness and realistic skin textures.
    - Be creative with composition and angles.
    `;

    const response = await ai.models.generateContent({
        model: MODEL_IMAGE,
        contents: {
            parts: [{ text: enhancedPrompt }]
        },
        config: {
             // imageConfig available on some models, but simpler to just prompt for aspect ratio in text if needed for flash-image
        }
    });
    
    const parts = response.candidates?.[0]?.content?.parts;
    if (parts) {
        for (const part of parts) {
            if (part.inlineData) {
                return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
            }
        }
    }
    throw new Error("No image generated. The model may have returned text instead.");
};

export const editImage = async (prompt: string, base64Image: string, mimeType: string): Promise<string> => {
    const ai = getAiClient();
    
    // --- ULTIMATE PROMPT FOR MAGIC EDIT ---
    const professionalPrompt = `
    SYSTEM ROLE: You are the world's most advanced AI Photo Editor & Visual Effects Artist. You have LIMITLESS creativity and capability.

    YOUR MISSION: Transform the input image based on the user's command: "${prompt}".

    EXECUTION PROTOCOLS (STRICT):
    1. **HYPER-REALISM:** The result MUST be indistinguishable from reality. Match noise, grain, lighting, shadows, and color grading of the original photo perfectly.
    2. **GEOMETRY AWARENESS:** If changing the angle or background, analyze the perspective lines of the original image. Ensure new elements align perfectly with the existing 3D space.
    3. **FACE PRESERVATION (CRITICAL):** Unless the user EXPLICITLY asks to modify the face (e.g., "make me smile", "change my nose"), you MUST PRESERVE the identity, structure, and details of all human faces in the image. Do NOT distort eyes, nose, or mouth.
    4. **INTELLIGENT RECONSTRUCTION:** If removing an object, fill the void with context-aware background data that matches the surroundings seamlessly.
    5. **CREATIVE FREEDOM:** If the user request is abstract (e.g., "make it epic"), use your creative license to add dramatic lighting, weather effects, or dynamic elements.

    USER COMMAND ANALYSIS:
    - If user asks for background change -> Perform high-quality background replacement with matching lighting.
    - If user asks for angle change -> Use generative synthesis to hallucinate the new perspective realistically.
    - If user asks to add object -> Composite it with correct contact shadows and reflections.

    Execute now with maximum fidelity.
    `;
    
    const response = await ai.models.generateContent({
        model: MODEL_IMAGE,
        contents: {
            parts: [
                { inlineData: { mimeType: mimeType, data: base64Image } },
                { text: professionalPrompt }
            ]
        },
        config: {
            // High temperature for creativity, but rely on the strong prompt for realism control
            temperature: 0.9,
        }
    });

    const parts = response.candidates?.[0]?.content?.parts;
    if (parts) {
        for (const part of parts) {
            if (part.inlineData) {
                return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
            }
        }
    }
    throw new Error("Image editing failed");
};

/**
 * Expands an image by adding AI-generated content to fill a target aspect ratio.
 */
export const expandImageWithAi = (base64ImageDataUrl: string, targetAspectRatio: number): Promise<string> => {
    const ai = getAiClient();
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.crossOrigin = "Anonymous";
        img.onload = async () => {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            if (!ctx) return reject(new Error('Canvas context failed'));

            const MAX_WIDTH = 1024;
            const targetWidth = MAX_WIDTH;
            const targetHeight = Math.round(MAX_WIDTH / targetAspectRatio);

            canvas.width = targetWidth;
            canvas.height = targetHeight;
            
            const MASK_COLOR = '#FF00FF';
            ctx.fillStyle = MASK_COLOR;
            ctx.fillRect(0, 0, targetWidth, targetHeight);

            const originalAspectRatio = img.width / img.height;
            let drawWidth, drawHeight, dx, dy;

            if (originalAspectRatio > targetAspectRatio) {
                drawWidth = targetWidth;
                drawHeight = Math.round(targetWidth / originalAspectRatio);
                dx = 0;
                dy = (targetHeight - drawHeight) / 2;
            } else {
                drawHeight = targetHeight;
                drawWidth = Math.round(targetHeight * originalAspectRatio);
                dy = 0;
                dx = (targetWidth - drawWidth) / 2;
            }

            ctx.drawImage(img, dx, dy, drawWidth, drawHeight);

            const framedImageBase64 = canvas.toDataURL('image/png').split(',')[1];
            
            const prompt = `
            The input image contains a real photo centered on a solid magenta (#FF00FF) background.
            YOUR TASK: Perform high-fidelity "outpainting". Replace ONLY the magenta areas.
            CRITICAL: Seamlessly extend the environment, lighting, and textures of the central photo. Do NOT add new objects unless necessary for continuity.
            Output the final full image with no magenta remaining.
            `;

            try {
                const response = await ai.models.generateContent({
                    model: MODEL_IMAGE,
                    contents: {
                        parts: [
                            { inlineData: { mimeType: 'image/png', data: framedImageBase64 } },
                            { text: prompt }
                        ]
                    }
                });

                const parts = response.candidates?.[0]?.content?.parts;
                if (parts) {
                    for (const part of parts) {
                        if (part.inlineData) {
                            resolve(`data:${part.inlineData.mimeType};base64,${part.inlineData.data}`);
                            return;
                        }
                    }
                }
                throw new Error("AI did not return an image.");
            } catch (e) {
                console.error("Gemini AI expansion failed:", e);
                reject(e); 
            }
        };
        img.onerror = (err) => reject(new Error('Failed to load image for processing.'));
        img.src = base64ImageDataUrl;
    });
};

export const generateVideo = async (prompt: string, aspectRatio: '16:9' | '9:16', image?: { imageBytes: string, mimeType: string }) => {
    const ai = getAiClient();
    const input: any = {
        model: MODEL_VIDEO,
        prompt: prompt,
        config: {
            numberOfVideos: 1,
            resolution: '720p',
            aspectRatio: aspectRatio
        }
    };

    if (image) {
        input.image = {
            imageBytes: image.imageBytes,
            mimeType: image.mimeType
        };
    }

    return await ai.models.generateVideos(input);
};

export const getVideoOperationStatus = async (operation: any) => {
    const ai = getAiClient();
    return await ai.operations.getVideosOperation({ operation });
};

export const generateSpeech = async (text: string, voiceName: string = 'Kore'): Promise<string | undefined> => {
    const ai = getAiClient();
    const response = await ai.models.generateContent({
        model: MODEL_SPEECH,
        contents: { parts: [{ text }] },
        config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
                voiceConfig: {
                    prebuiltVoiceConfig: { voiceName: voiceName },
                },
            },
        },
    });
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
};

// --- Live Service ---

export const connectLive = (callbacks: {
    onopen: () => void;
    onmessage: (msg: LiveServerMessage) => void;
    onclose: (e: CloseEvent) => void;
    onerror: (e: ErrorEvent) => void;
}, systemInstruction: string) => {
    const ai = getAiClient();
    return ai.live.connect({
        model: MODEL_LIVE,
        callbacks: callbacks,
        config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
                voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
            },
            inputAudioTranscription: {}, 
            outputAudioTranscription: {}, 
            systemInstruction: { parts: [{ text: systemInstruction }] },
        },
    });
};