import { Reel, UserProfile } from '../types';

// Helper to simulate user interests based on their likes (in a real app, this would be a complex model)
const getUserInterests = (currentUser: UserProfile, allReels: Reel[]): string[] => {
    // This is a simulation. In reality, you'd look at liked posts, past watch history, etc.
    // For this simulation, we'll assume the current user (Zeynep) has shown interest in Cardio and Yoga.
    return ['Cardio', 'Yoga'];
};

/**
 * Sorts the reels feed based on a multi-factor algorithm.
 * @param currentUser The user for whom the feed is being generated.
 * @param allReels An array of all available reels.
 * @param allUsers An array of all users.
 * @returns A sorted array of reels for the user's feed.
 */
export const getReelsFeed = (currentUser: UserProfile, allReels: Reel[], allUsers: UserProfile[]): Reel[] => {
    const userInterests = getUserInterests(currentUser, allReels);
    const now = Date.now();

    const scoredReels = allReels.map(reel => {
        // --- 1. Relevance Score (Weight: 55%) ---
        let relevanceScore = 0;
        // High priority for reels from followed users
        if (currentUser.following.includes(reel.user)) {
            relevanceScore += 40;
        }
        // Boost for reels matching user's interests
        if (userInterests.includes(reel.category)) {
            relevanceScore += 15;
        }

        // --- 2. Popularity/Virality Score (Weight: 30%) ---
        let popularityScore = 0;
        // Watch time completion is a critical metric (up to 15 points)
        popularityScore += (reel.watchTimePercentage / 100) * 15;
        
        // Interaction velocity (up to 15 points)
        // Heavier weight for comments and shares
        const totalInteractions = reel.likes + (reel.comments.length * 2) + (reel.shareCount * 3);
        const ageInHours = Math.max(1, (now - reel.timestamp) / (1000 * 60 * 60)); // Ensure age is at least 1 to avoid division by zero/infinity
        
        // A simple velocity score: interactions per hour. Capped to prevent extreme values from old viral posts.
        const velocity = totalInteractions / ageInHours;
        popularityScore += Math.min(velocity, 15);

        // --- 3. Diversity & Novelty Score (Weight: 15%) ---
        // A small random boost to ensure new or less popular content gets a chance.
        const noveltyScore = Math.random() * 15;
        
        // Combine scores based on weights
        const totalScore = relevanceScore + popularityScore + noveltyScore;

        return { reel, score: totalScore };
    });

    // Sort by the final score in descending order
    const sortedReels = scoredReels
        .sort((a, b) => b.score - a.score)
        .map(item => item.reel);

    return sortedReels;
};
