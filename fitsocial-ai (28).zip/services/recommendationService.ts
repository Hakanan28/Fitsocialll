
import { UserProfile, Group } from '../types';

export interface RecommendationItem {
    type: 'user' | 'group';
    data: UserProfile | Group;
    reason: string;
    score: number;
}

/**
 * Generates a list of recommended users and groups based on the current user's context.
 */
export const getRecommendations = (
    currentUser: UserProfile,
    allUsers: UserProfile[],
    allGroups: Group[]
): RecommendationItem[] => {
    const recommendations: RecommendationItem[] = [];
    const followingSet = new Set(currentUser.following);
    const joinedGroupIds = new Set(allGroups.filter(g => g.members.some(m => m.username === currentUser.username)).map(g => g.id));

    const myBio = (currentUser.bio || '').toLowerCase();
    
    // Common keywords for heuristics (In a real app, this would be database fields)
    const commonLocations = ['istanbul', 'ankara', 'izmir', 'london', 'new york', 'berlin', 'bursa', 'antalya'];
    const interestKeywords = ['yoga', 'running', 'crossfit', 'bodybuilding', 'pilates', 'hiking', 'football', 'basketball', 'tennis', 'swimming', 'boxing', 'mma'];

    // 1. Analyze Users
    allUsers.forEach(user => {
        if (user.username === currentUser.username) return; // Skip self
        if (followingSet.has(user.username)) return; // Skip already followed

        let score = 0;
        let reason = '';
        const theirBio = (user.bio || '').toLowerCase();

        // Factor 1: Mutual Connections
        const mutualFollowing = user.following.filter(u => followingSet.has(u));
        
        if (mutualFollowing.length > 0) {
            score += mutualFollowing.length * 5;
            reason = `Followed by ${mutualFollowing[0]}${mutualFollowing.length > 1 ? ` +${mutualFollowing.length - 1}` : ''}`;
        }

        // Factor 2: Location Match (Heuristic based on Bio)
        const locationMatch = commonLocations.find(loc => 
            myBio.includes(loc) && theirBio.includes(loc)
        );
        
        if (locationMatch) {
            score += 4;
            if (!reason) {
                // Capitalize first letter for display
                const locDisplay = locationMatch.charAt(0).toUpperCase() + locationMatch.slice(1);
                reason = `Lives in ${locDisplay}`;
            }
        }

        // Factor 3: Interest Match (Heuristic based on Bio)
        const interestMatch = interestKeywords.find(interest => 
            myBio.includes(interest) && theirBio.includes(interest)
        );

        if (interestMatch) {
            score += 3;
            if (!reason) {
                const interestDisplay = interestMatch.charAt(0).toUpperCase() + interestMatch.slice(1);
                reason = `Also likes ${interestDisplay}`;
            }
        }

        // Factor 4: High CVS Score (Popularity/Authority)
        if (user.cvsScore > 8.0) {
            score += 2; // Lower weight if no location/interest match
            if (!reason) reason = 'Top Rated Athlete';
        } else if (user.isVerified) {
            score += 2;
            if (!reason) reason = 'Verified Coach';
        }

        // Factor 5: New User Boost
        if (user.posts.length < 3 && user.followers > 5) {
            score += 1;
            if (!reason) reason = 'New to FitSocial';
        }

        if (score > 0 || !reason) {
             // Fallback reason if score accumulated but no string set
             if(!reason) {
                 reason = 'Suggested for you';
                 score = 1;
             }
             recommendations.push({ type: 'user', data: user, reason, score });
        }
    });

    // 2. Analyze Groups
    allGroups.forEach(group => {
        if (joinedGroupIds.has(group.id)) return; // Skip joined groups

        let score = 0;
        let reason = '';
        const groupLoc = (group.location || '').toLowerCase();
        const groupDesc = (group.description || '').toLowerCase();

        // Factor 1: Location Match
        const locationMatch = commonLocations.find(loc => 
            myBio.includes(loc) && (groupLoc.includes(loc) || groupDesc.includes(loc))
        );

        if (locationMatch) {
             score += 5; // High priority for local groups
             const locDisplay = locationMatch.charAt(0).toUpperCase() + locationMatch.slice(1);
             reason = `Popular in ${locDisplay}`;
        }

        // Factor 2: Interest Match (Tags or Description)
        const interestMatch = interestKeywords.find(interest => 
            myBio.includes(interest) && 
            (groupDesc.includes(interest) || (group.tags && group.tags.some(t => t.toLowerCase().includes(interest))))
        );

        if (interestMatch) {
            score += 4;
            if (!reason) {
                const interestDisplay = interestMatch.charAt(0).toUpperCase() + interestMatch.slice(1);
                reason = `${interestDisplay} Community`;
            }
        }

        // Factor 3: Popularity
        if (group.memberCount > 500) {
            score += 2;
            if (!reason) reason = 'Trending Tribe';
        }

        // Factor 4: Friends in Group
        const friendsInGroup = group.members.filter(m => followingSet.has(m.username));
        if (friendsInGroup.length > 0) {
            score += friendsInGroup.length * 6; // Highest priority
            reason = `${friendsInGroup[0].username} is a member`;
        }

        if (score > 0) {
            recommendations.push({ type: 'group', data: group, reason, score });
        }
    });

    // Sort by score descending and return top results
    return recommendations.sort((a, b) => b.score - a.score).slice(0, 10);
};
