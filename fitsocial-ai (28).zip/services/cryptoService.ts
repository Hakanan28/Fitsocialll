
import { Coin, NFT, Transaction, NewsItem } from '../types';

// Helper function to generate mock sparkline data (fallback)
const generateSparkline = (startPrice: number, change: number): number[] => {
    const data: number[] = [];
    let price = startPrice * (1 - change / 100); // Start from yesterday's price
    for (let i = 0; i < 30; i++) {
        data.push(price);
        // More volatile, realistic movement
        price += (Math.random() - 0.48) * startPrice * 0.08; 
    }
    // Ensure the last point reflects the current price
    data[29] = startPrice;
    return data;
};

// Mapping for symbols to Binance tickers
const symbolMap: Record<string, string> = {
    'ETH': 'ETHUSDT',
    'SOL': 'SOLUSDT',
    'BNB': 'BNBUSDT',
    'MATIC': 'MATICUSDT', 
    'AVAX': 'AVAXUSDT',
    'SUI': 'SUIUSDT',
    'APT': 'APTUSDT',
    'OP': 'OPUSDT',
    'ARB': 'ARBUSDT',
    'APE': 'APEUSDT',
    'XRP': 'XRPUSDT',
    'XLM': 'XLMUSDT',
    'BASE': 'ETHUSDT', // Base L2 -> ETH price as proxy
    'UNI': 'UNIUSDT',
    'DAI': 'DAIUSDT', 
    'LINK': 'LINKUSDT',
    'SHIB': 'SHIBUSDT',
    'BTC': 'BTCUSDT'
};

// --- Mock Generators for Fallback ---

const getMockCandles = (basePrice: number) => {
    const candles = [];
    let currentPrice = basePrice;
    const now = Date.now();
    const hour = 3600 * 1000;
    
    for(let i = 50; i >= 0; i--) {
        const time = now - (i * hour);
        const volatility = currentPrice * 0.02; // 2% volatility
        const change = (Math.random() - 0.5) * volatility;
        
        const open = currentPrice;
        const close = currentPrice + change;
        const high = Math.max(open, close) + Math.random() * volatility * 0.5;
        const low = Math.min(open, close) - Math.random() * volatility * 0.5;
        
        candles.push({
            x: time,
            y: [open, high, low, close]
        });
        
        currentPrice = close;
    }
    return candles;
};

const getMockNews = (symbol: string): NewsItem[] => [
    {
        id: '1',
        title: `${symbol} Breaks New Resistance Levels`,
        body: 'Market analysts predict a bullish trend as volume increases.',
        url: '#',
        imageurl: 'https://images.unsplash.com/photo-1621761191319-c6fb62004040?auto=format&fit=crop&w=300&q=80',
        source: 'CryptoDaily',
        published_on: Math.floor(Date.now() / 1000) - 3600
    },
    {
        id: '2',
        title: 'Global Adoption Rising',
        body: 'New regulations pave the way for institutional investment.',
        url: '#',
        imageurl: 'https://images.unsplash.com/photo-1622630998477-20aa696fa4a5?auto=format&fit=crop&w=300&q=80',
        source: 'CoinWire',
        published_on: Math.floor(Date.now() / 1000) - 7200
    },
    {
        id: '3',
        title: `Top 10 Reasons to Watch ${symbol}`,
        body: 'A deep dive into the ecosystem and future roadmap.',
        url: '#',
        imageurl: 'https://images.unsplash.com/photo-1518546305927-5a555bb7020d?auto=format&fit=crop&w=300&q=80',
        source: 'BlockNews',
        published_on: Math.floor(Date.now() / 1000) - 15000
    }
];

// --- Real API Functions ---

export const fetchRealCoinStats = async (): Promise<Record<string, { price: number, change: number }>> => {
    try {
        // Fetch all 24hr ticker price change statistics
        const response = await fetch('https://api.binance.com/api/v3/ticker/24hr');
        if (!response.ok) throw new Error('Binance API Error');
        const data = await response.json();
        
        const stats: Record<string, { price: number, change: number }> = {};
        
        data.forEach((ticker: any) => {
            stats[ticker.symbol] = {
                price: parseFloat(ticker.lastPrice),
                change: parseFloat(ticker.priceChangePercent)
            };
        });
        return stats;
    } catch (e) {
        console.warn("Failed to fetch real crypto stats, using realistic simulation.");
        // Generate simulated live changes if API fails (fallback)
        const mockStats: Record<string, { price: number, change: number }> = {};
        mockCoins.forEach(c => {
            const mockChange = (Math.random() - 0.5) * 1.5; // Random fluctuation
            const newPrice = c.price * (1 + mockChange / 100);
            const binanceSymbol = symbolMap[c.symbol] || `${c.symbol}USDT`;
            
            mockStats[binanceSymbol] = { price: newPrice, change: c.priceChange24h + mockChange };
            // Also allow access by raw symbol if needed
            mockStats[c.symbol] = { price: newPrice, change: c.priceChange24h + mockChange };
        });
        return mockStats;
    }
};

export const fetchCandlestickData = async (symbol: string, interval: string = '1h'): Promise<any[]> => {
    const binanceSymbol = symbolMap[symbol] || `${symbol}USDT`;
    try {
        // Pass the interval dynamically
        const response = await fetch(`https://api.binance.com/api/v3/klines?symbol=${binanceSymbol}&interval=${interval}&limit=100`);
        if (!response.ok) throw new Error('Binance Klines Error');
        const data = await response.json();
        
        // Binance returns [openTime, open, high, low, close, volume, closeTime, ...]
        return data.map((d: any) => ({
            x: d[0], // Timestamp
            y: [parseFloat(d[1]), parseFloat(d[2]), parseFloat(d[3]), parseFloat(d[4])] // [Open, High, Low, Close]
        }));
    } catch (e) {
        console.warn(`Failed to fetch candlestick data for ${symbol}, using fallback.`);
        const basePrice = mockCoins.find(c => c.symbol === symbol)?.price || 100;
        return getMockCandles(basePrice);
    }
};

export const fetchCoinNews = async (symbol: string): Promise<NewsItem[]> => {
    try {
        // Using CryptoCompare free API for news
        const response = await fetch(`https://min-api.cryptocompare.com/data/v2/news/?categories=${symbol}&lang=EN`);
        if (!response.ok) throw new Error('News API Error');
        const data = await response.json();
        return data.Data.slice(0, 5); // Return top 5 news items
    } catch (e) {
        console.warn(`Failed to fetch news for ${symbol}, using fallback.`);
        return getMockNews(symbol);
    }
}

// INITIAL BALANCES SET TO 0
let mockCoins: Coin[] = [
    {
        id: 'ethereum',
        name: 'Ethereum',
        symbol: 'ETH',
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/eth.svg',
        balance: 0,
        price: 3450.12,
        priceChange24h: 2.5,
        sparkline: [],
        transactions: [],
    },
    {
        id: 'solana',
        name: 'Solana',
        symbol: 'SOL',
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/sol.svg',
        balance: 0,
        price: 135.80,
        priceChange24h: -1.2,
        sparkline: [],
        transactions: [],
    },
    {
        id: 'binancecoin',
        name: 'Binance Coin',
        symbol: 'BNB',
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/bnb.svg',
        balance: 0,
        price: 578.45,
        priceChange24h: 0.8,
        sparkline: [],
        transactions: [],
    },
     {
        id: 'matic-network',
        name: 'Polygon',
        symbol: 'MATIC',
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/matic.svg',
        balance: 0,
        price: 0.57,
        priceChange24h: 3.1,
        sparkline: [],
        transactions: [],
    },
    {
        id: 'avalanche-2',
        name: 'Avalanche',
        symbol: 'AVAX',
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/avax.svg',
        balance: 0,
        price: 25.50,
        priceChange24h: -2.5,
        sparkline: [],
        transactions: [],
    },
    {
        id: 'sui',
        name: 'Sui',
        symbol: 'SUI',
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/sui.svg',
        balance: 0,
        price: 0.88,
        priceChange24h: 5.0,
        sparkline: [],
        transactions: [],
    },
     {
        id: 'aptos',
        name: 'Aptos',
        symbol: 'APT',
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/apt.svg',
        balance: 0,
        price: 6.90,
        priceChange24h: -0.5,
        sparkline: [],
        transactions: [],
    },
    {
        id: 'optimism',
        name: 'Optimism',
        symbol: 'OP',
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/op.svg',
        balance: 0,
        price: 1.77,
        priceChange24h: 1.8,
        sparkline: [],
        transactions: [],
    },
     {
        id: 'arbitrum',
        name: 'Arbitrum',
        symbol: 'ARB',
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/arb.svg',
        balance: 0,
        price: 0.83,
        priceChange24h: 2.1,
        sparkline: [],
        transactions: [],
    },
    {
        id: 'apecoin',
        name: 'ApeCoin',
        symbol: 'APE',
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/ape.svg',
        balance: 0,
        price: 0.95,
        priceChange24h: -3.3,
        sparkline: [],
        transactions: [],
    },
    {
        id: 'ripple',
        name: 'XRP',
        symbol: 'XRP',
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/xrp.svg',
        balance: 0,
        price: 0.47,
        priceChange24h: -0.8,
        sparkline: [],
        transactions: [],
    },
    {
        id: 'stellar',
        name: 'Stellar',
        symbol: 'XLM',
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/xlm.svg',
        balance: 0,
        price: 0.09,
        priceChange24h: 1.1,
        sparkline: [],
        transactions: [],
    },
    {
        id: 'base',
        name: 'Base',
        symbol: 'BASE',
        logoUrl: 'https://raw.githubusercontent.com/base-org/brand-kit/main/logo/symbol/Base_Symbol_Blue.svg',
        balance: 0,
        price: 22.45,
        priceChange24h: 4.5,
        sparkline: [],
        transactions: [],
    }
];

// Initialize sparklines for the first load
mockCoins.forEach(coin => {
    coin.sparkline = generateSparkline(coin.price, coin.priceChange24h);
    // No transactions initially
    coin.transactions = [];
});

// FIX: Add missing properties to NFT objects to satisfy the NFT type.
const mockNfts: NFT[] = [
    {
        id: '1',
        name: 'FitSocial Genesis Runner',
        collection: 'FitSocial Originals',
        imageUrl: 'https://placehold.co/500x500/1E1E1E/A78BFA?text=NFT%20%231',
        owner: { username: 'FitSocial', avatar: 'https://placehold.co/100x100/10B981/FFFFFF?text=FS' },
        price: 1.5,
        currency: 'ETH',
        bestOffer: 1.2,
        description: 'A special NFT awarded to early adopters of the FitSocial platform.',
        bids: [],
        priceHistory: [],
    },
    {
        id: '2',
        name: 'Quantum Quads #345',
        collection: 'AI Body Art',
        imageUrl: 'https://placehold.co/500x500/111827/34D399?text=Q-Quads',
        owner: { username: 'Zeynep', avatar: 'https://placehold.co/100x100/E91E63/white?text=Z' },
        price: 2.1,
        currency: 'ETH',
        bestOffer: 1.9,
        description: 'A generative art piece based on the muscle data from your 100th workout.',
        bids: [],
        priceHistory: [],
    },
];

const validContracts: { [address: string]: Omit<Coin, 'balance' | 'sparkline' | 'transactions'> } = {
    "0x1f9840a85d5af5bf1d1762f925bdaddc4201f984": {
        id: 'uniswap',
        name: 'Uniswap',
        symbol: 'UNI',
        price: 9.50,
        priceChange24h: 1.5,
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/uni.svg'
    },
    "0x6b175474e89094c44da98b954eedeac495271d0f": {
        id: 'dai',
        name: 'Dai',
        symbol: 'DAI',
        price: 1.00,
        priceChange24h: 0.0,
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/dai.svg'
    },
    "0x514910771af9ca656af840dff83e8264ecf986ca": {
        id: 'chainlink',
        name: 'Chainlink',
        symbol: 'LINK',
        price: 14.25,
        priceChange24h: 4.2,
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/link.svg'
    },
    "0x95ad61b0a150d79219dcf64e1e6cc01f0b64c4ce": {
        id: 'shiba-inu',
        name: 'Shiba Inu',
        symbol: 'SHIB',
        price: 0.0000175,
        priceChange24h: -1.8,
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/shib.svg'
    }
};

export const getCoins = (): Coin[] => {
    return mockCoins;
};

export const getNFTs = (): NFT[] => {
    return mockNfts;
};

export const validateContract = (address: string): Omit<Coin, 'balance' | 'sparkline' | 'transactions'> | null => {
    return validContracts[address.toLowerCase()] || null;
};
